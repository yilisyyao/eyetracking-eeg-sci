from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE

OUT = r"C:\Users\PCI\Documents\论文分析\EEG_Results_3.3_双语工作稿_待学生溯源确认_20260906.docx"

doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.72)
sec.bottom_margin = Inches(0.72)
sec.left_margin = Inches(0.82)
sec.right_margin = Inches(0.82)

styles = doc.styles
styles['Normal'].font.name = 'Times New Roman'
styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
styles['Normal'].font.size = Pt(10.5)
styles['Normal'].paragraph_format.space_after = Pt(6)
styles['Normal'].paragraph_format.line_spacing = 1.12

for name, size, color in [('Title', 18, '000000'), ('Heading 1', 14, '1F4E79'), ('Heading 2', 12, '1F4E79'), ('Heading 3', 11, '000000')]:
    st = styles[name]
    st.font.name = 'Times New Roman'
    st._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    st.font.size = Pt(size)
    st.font.bold = True
    st.font.color.rgb = RGBColor.from_string(color)
    st.paragraph_format.space_before = Pt(10 if name != 'Title' else 0)
    st.paragraph_format.space_after = Pt(5)

def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)

def set_cell_border(cell, color='D9D9D9', sz='6'):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in('w:tcBorders')
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top','left','bottom','right','insideH','insideV'):
        tag = 'w:' + edge
        el = tcBorders.find(qn(tag))
        if el is None:
            el = OxmlElement(tag)
            tcBorders.append(el)
        el.set(qn('w:val'), 'single')
        el.set(qn('w:sz'), sz)
        el.set(qn('w:space'), '0')
        el.set(qn('w:color'), color)

def add_status(text, kind='confirmed'):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = True
    if kind == 'confirmed':
        r.font.color.rgb = RGBColor(31, 78, 121)
    elif kind == 'wait':
        r.font.color.rgb = RGBColor(192, 80, 77)
    else:
        r.font.color.rgb = RGBColor(128, 96, 0)
    p.paragraph_format.space_after = Pt(4)
    return p

def add_bilingual(en, zh=None):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(5)
    r = p.add_run(en)
    r.font.name = 'Times New Roman'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    if zh:
        p2 = doc.add_paragraph()
        p2.paragraph_format.space_after = Pt(7)
        r2 = p2.add_run(zh)
        r2.font.name = '宋体'
        r2._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

def add_note(label, text, kind='wait'):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.18)
    p.paragraph_format.space_after = Pt(5)
    r = p.add_run(label + ' ')
    r.bold = True
    r.font.color.rgb = RGBColor(192,80,77) if kind=='wait' else RGBColor(128,96,0)
    p.add_run(text)

title = doc.add_paragraph(style='Title')
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
title.add_run('EEG Results 3.3 Bilingual Working Draft')
sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
sub.add_run('基于0805正式输出与2026年8月18日补充复核的双语工作稿').italic = True

doc.add_paragraph('用途说明 / Purpose', style='Heading 1')
add_bilingual(
    'This working draft consolidates the EEG findings that are currently traceable to the 0805 analysis package. It separates results that can be used now from statements that should remain qualified until the original analysis computer provides historical prespecification, executable-script, and preprocessing evidence.',
    '本工作稿整合目前能够追溯到0805分析包的EEG结果，并将“目前可以使用的结果”和“必须等原分析电脑补充证据后才能定稿的表述”分开。'
)
add_status('当前建议：可以先按本稿修改3.3主体；学生回复主要影响“primary / prespecified / equal-status”等历史与方法措辞，不太可能改变已核验的主要数值。', 'confirmed')

doc.add_paragraph('Evidence status legend / 证据状态说明', style='Heading 2')
tbl = doc.add_table(rows=1, cols=3)
tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
tbl.style = 'Table Grid'
hdr = tbl.rows[0].cells
for i, t in enumerate(['Status', 'Meaning', '中文含义']):
    hdr[i].text = t; set_cell_shading(hdr[i], '1F4E79')
    for run in hdr[i].paragraphs[0].runs: run.font.color.rgb = RGBColor(255,255,255); run.bold=True
rows = [
    ('Confirmed', 'Traceable to 0805 or reproducible from the supplied machine-readable audit output.', '已核验，可直接用于正文。'),
    ('Qualified', 'Numerically supported, but the inferential or historical status should be described conservatively.', '数值支持，但分析地位或历史预设需降级表述。'),
    ('Awaiting confirmation', 'Requires a response from the original analysis computer before final wording.', '需等学生回复后才能最终定稿。'),
]
for row in rows:
    cells = tbl.add_row().cells
    for i, t in enumerate(row):
        cells[i].text = t; cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_border(cells[i])
        if row[0] == 'Confirmed': set_cell_shading(cells[i], 'EAF2F8')
        elif row[0] == 'Awaiting confirmation': set_cell_shading(cells[i], 'FCE4D6')

doc.add_paragraph('3.3 EEG results', style='Heading 1')

doc.add_paragraph('3.3.1 Factor-level EEG contrasts', style='Heading 2')
add_status('状态：数值已核验；建议作为complementary factor-level reanalysis。是否可称为预设/primary，等待学生确认。', 'qualified')
add_bilingual(
    'A complementary factor-level reanalysis used the 0805 common-QC sample of 42 participants and 461 trials for each onset-trim variant. Across all four variants, occipital theta relative power was higher in the high-complexity condition (C1) than in the low-complexity condition (C0), after equal-weight averaging over WWR and exercise-frequency groups. The marginal contrast was β = 0.00436 at 0 s (95% CI, 0.00226–0.00646; CR2 p = 0.00018; joint BH-adjusted q = 0.00443), β = 0.00451 at 5 s (95% CI, 0.00248–0.00654; CR2 p = 7.81 × 10−5; joint q = 0.00371), β = 0.00503 at 10 s (95% CI, 0.00297–0.00708; CR2 p = 2.13 × 10−5; joint q = 0.00205), and β = 0.00488 at 15 s (95% CI, 0.00262–0.00714; CR2 p = 0.00012; joint q = 0.00371). The direction and corrected status were therefore consistent across the four onset-trim variants.',
    '一项补充性的factor-level复核使用0805 common-QC样本；每个onset-trim variant均为42名参与者、461个试次。在对WWR和exercise frequency进行等权平均后，四个variant中，high-complexity condition（C1）的occipital theta relative power均高于low-complexity condition（C0）。0 s、5 s、10 s和15 s的边际对比分别为β = 0.00436（95% CI，0.00226–0.00646；CR2 p = 0.00018；联合BH-adjusted q = 0.00443）、β = 0.00451（95% CI，0.00248–0.00654；CR2 p = 7.81 × 10−5；联合q = 0.00371）、β = 0.00503（95% CI，0.00297–0.00708；CR2 p = 2.13 × 10−5；联合q = 0.00205）和β = 0.00488（95% CI，0.00262–0.00714；CR2 p = 0.00012；联合q = 0.00371）。因此，该复杂度边际对比的方向和校正后证据在四个onset-trim variant中保持一致。'
)
add_note('待确认：', '学生需要确认这项factor-level分析是否在正式结果查看前已经确定。若不能证明，正文保留“complementary reanalysis / 补充性复核”，不要写成prospectively prespecified primary analysis。')

doc.add_paragraph('3.3.2 Condition-related EEG coefficients', style='Heading 2')
add_status('状态：已核验，可直接使用；当前四个系数是0805 common-QC Model 1 CR2输出的唯一可追溯数值。', 'confirmed')
add_bilingual(
    'For the four core EEG outcomes, 144 Model 1 condition-related coefficients were examined across the four onset-trim variants, with 36 coefficients per variant. Three coefficients had unadjusted CR2 p < 0.05, all for the WWR45 × high-complexity condition (C1) term in frontal theta relative power. At 0 s, β = 0.00757 and unadjusted CR2 p = 0.0288. At 5 s, β = 0.00856 and unadjusted CR2 p = 0.0132. At 10 s, β = 0.00750 and unadjusted CR2 p = 0.0334. At 15 s, the corresponding coefficient was β = 0.00475 and unadjusted CR2 p = 0.1704. No coefficient met the CR2 BH-FDR criterion within any onset-trim variant or jointly across all 144 coefficients.',
    '针对四个核心EEG outcome，在四个onset-trim variant中共检验144个Model 1条件相关系数，每个variant包含36个系数。其中3个系数的unadjusted CR2 p < 0.05，均对应frontal theta relative power中的WWR45 × high-complexity condition（C1）项。0 s时β = 0.00757，unadjusted CR2 p = 0.0288；5 s时β = 0.00856，p = 0.0132；10 s时β = 0.00750，p = 0.0334；15 s时β = 0.00475，p = 0.1704。没有任何系数在单个onset-trim variant内或在全部144个系数的联合检验中达到CR2 BH-FDR criterion。'
)
add_bilingual(
    'An expanded nine-outcome audit included 324 condition-related coefficients. Fourteen coefficients had unadjusted CR2 p < 0.05, but none met the CR2 BH-FDR criterion within a variant or jointly across variants.',
    '扩展到9个EEG outcome后，共包含324个条件相关系数。其中14个系数的unadjusted CR2 p < 0.05，但没有任何系数在单个variant内或跨variant联合检验中达到CR2 BH-FDR criterion。'
)
add_note('措辞边界：', '目前可以保留“144个核心系数”和“324个扩展审计系数”，但除非学生提供运行前计划或配置，不要写“144项是事先确定的primary multiplicity family”。')

doc.add_paragraph('3.3.3 Temporal adjustment coefficients', style='Heading 2')
add_status('状态：数值已核验；可报告为temporal adjustment-related associations，不应解释为fatigue、adaptation、learning或recovery。', 'qualified')
add_bilingual(
    'Temporal adjustment coefficients showed reproducible associations across onset-trim variants. In the relative-power family, viewing round was negatively associated with theta relative power in the frontal, parietal and occipital ROIs, with coefficients ranging from −0.00453 to −0.00682 and joint BH-adjusted q values ranging from 0.00461 to 0.02239. Viewing round and within-round presentation position showed positive coefficients for alpha relative power across these ROIs, with joint BH-adjusted q values no greater than 0.00461. The corresponding log10 absolute alpha-power analyses also showed positive coefficients for these temporal adjustment variables, with joint BH-adjusted q values below 0.05 for the reported associations. All 72 models in the broader 18-outcome reanalysis converged, and none was flagged as singular.',
    '时间调整系数在不同onset-trim variant中表现出可重复的统计关联。在relative-power检验中，viewing round与frontal、parietal和occipital ROI的theta relative power均呈负向关联，系数范围为−0.00453至−0.00682，联合BH-adjusted q范围为0.00461至0.02239。viewing round和within-round presentation position与上述ROI的alpha relative power呈正向系数，联合BH-adjusted q均不高于0.00461。相应的log10 absolute alpha-power分析也显示这些时间调整变量的正向系数，报告的关联均具有低于0.05的联合BH-adjusted q。扩展的18个outcome × 4个variant共72个模型均收敛，未发现singular fit。'
)
add_note('解释边界：', '这些结果应保留为时间调整相关的统计关联，不应在Results中解释为疲劳、适应、学习、恢复或其他机制。')

doc.add_paragraph('3.3.4 Supplementary and sensitivity analyses', style='Heading 2')
add_status('状态：大部分数值已核验；previous-scene样本量和分析定位已修正。', 'confirmed')
add_bilingual(
    'Previous-scene terms did not provide corrected evidence of systematic previous-scene effects. The common-QC input comprised 42 participants and 461 trials, but 75 first-position trials lacked a defined previous-scene WWR value. The previous-scene models therefore used 42 participants and 386 complete trials. Among the 48 previous-scene tests, two had unadjusted CR2 p < 0.05. At 10 s, the previous-scene WWR75 coefficient for occipital theta relative power was β = 0.00309 (unadjusted CR2 p = 0.04435; BH-adjusted q = 0.53219). At 15 s, the corresponding coefficient was β = 0.00425 (unadjusted CR2 p = 0.00986; BH-adjusted q = 0.11835). Neither result met the CR2 BH-FDR criterion.',
    'previous-scene项没有提供系统性previous-scene效应的校正后证据。common-QC输入包括42名参与者和461个试次，但其中75个首场景试次没有定义的previous-scene WWR值。因此，previous-scene模型实际使用42名参与者和386个完整试次。在48项previous-scene检验中，有2项unadjusted CR2 p < 0.05。10 s时，occipital theta relative power的previous-scene WWR75系数为β = 0.00309（unadjusted CR2 p = 0.04435；BH-adjusted q = 0.53219）；15 s时相应系数为β = 0.00425（unadjusted CR2 p = 0.00986；BH-adjusted q = 0.11835）。两项结果均未达到CR2 BH-FDR criterion。'
)
add_bilingual(
    'In the broader factor-level audit, the WWR omnibus test for parietal beta relative power met the joint CR2 BH-FDR criterion only for the 15-s variant, F(2, 30.45) = 9.42471, CR2 p = 0.00065, within-variant BH-adjusted q = 0.01760 and joint BH-adjusted q = 0.02816. The corresponding joint q values for the 0-, 5- and 10-s variants were 0.11715, 0.13744 and 0.11715, respectively. Because this result was limited to one onset-trim variant, it was treated as a hypothesis-generating supplementary finding.',
    '在更广泛的factor-level审计中，parietal beta relative power的WWR总体检验仅在15-s variant达到联合CR2 BH-FDR criterion：F(2, 30.45) = 9.42471，CR2 p = 0.00065，variant内BH-adjusted q = 0.01760，联合BH-adjusted q = 0.02816。0 s、5 s和10 s的联合q分别为0.11715、0.13744和0.11715。由于该结果仅出现在一个onset-trim variant中，因此应作为hypothesis-generating supplementary finding报告。'
)
add_bilingual(
    'The direct onset-trim comparison comprised 756 descriptive pairwise coefficient contrasts across the four variants. Every 95% confidence interval included zero. These comparisons did not identify a preferred onset-trim variant, but they were descriptive sensitivity analyses and were not equivalence tests.',
    '直接onset-trim比较包括四个variant之间756项描述性成对系数对比。所有95% confidence interval均包含零。这些比较没有识别出一个优先的onset-trim variant；它们属于描述性敏感性分析，不是等效性检验。'
)
add_note('必须保持：', '不要恢复任何previous-scene WWR = 30的文字；正式实验WWR水平只有15%、45%和75%。也不要使用旧的β = −0.00864、p = 0.0473那组未经当前源表支持的表述。')

doc.add_paragraph('修改说明 / Revision notes', style='Heading 1')
notes = [
    ('补入遗漏结果', '将四个onset-trim variant中均通过联合CR2 BH-FDR criterion的occipital theta relative power C1−C0 factor-level finding补入3.3.1。'),
    ('保留核心结论', '3.3.2保留0805 common-QC Model 1的四个唯一可追溯系数，结论仍为无条件相关系数达到CR2 BH-FDR criterion。'),
    ('修正样本量', 'previous-scene分析从“42 participants / 461 trials”改为“42 participants / 386 complete trials”；461仅表示common-QC输入，75个首场景试次为结构性缺失。'),
    ('修正3.3.4', '删除WWR = 30及旧previous-scene数字；将15-s parietal beta WWR结果降级为hypothesis-generating supplementary finding。'),
    ('限定756项比较', '明确756项是描述性成对系数对比，不是等效性检验，也不是选择最佳onset-trim variant的依据。'),
    ('术语统一', '使用viewing round、within-round presentation position、onset-trim variant、common-QC sample、exercise frequency等锁定术语。'),
    ('解释收紧', '删除或暂不恢复fatigue、recovery、neural efficiency、sport experience、WWR45 peak或inverted-U等超出Results证据边界的表述。'),
]
t2 = doc.add_table(rows=1, cols=2); t2.alignment = WD_TABLE_ALIGNMENT.CENTER; t2.style='Table Grid'
for i, h in enumerate(['修改点', '具体处理']):
    t2.rows[0].cells[i].text = h; set_cell_shading(t2.rows[0].cells[i], '1F4E79')
    for run in t2.rows[0].cells[i].paragraphs[0].runs: run.font.color.rgb=RGBColor(255,255,255); run.bold=True
for a,b in notes:
    cells=t2.add_row().cells; cells[0].text=a; cells[1].text=b
    for c in cells: set_cell_border(c); c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

doc.add_paragraph('待学生回复后再决定 / Items to finalize after the student responds', style='Heading 1')
items = [
    '四个0-, 5-, 10- and 15-s onset-trim variants是在最终管线中并行运行，还是查看结果后才补充其他variant。若无运行前证据，正文只写“analysed in parallel in the final analysis pipeline”。',
    '144项是否在运行前被明确指定为primary multiplicity family，还是后续从324项扩展审计中提取的核心子集。',
    '0805运行时的实际工作区是否等同于GitHub commit 5174929，或是该commit之前的未提交版本。',
    'relative power计算代码是否实际使用1–45 Hz作为分母，并确认Methods与Results全文一致。',
    'filtering、50-Hz notch、average re-reference和ICA是否有可归档的EEGLAB history、脚本或处理日志，以便Methods保留完整上游预处理描述。',
]
for x in items:
    p=doc.add_paragraph(style='List Bullet'); p.add_run(x)

doc.add_paragraph('当前不应写入最终稿 / Do not restore before verification', style='Heading 1')
for x in ['previous-scene WWR = 30', 'gray-screen occipital-alpha recovery analysis', 'WWR45 theta peak, inverted-U or optimal WWR', 'neural efficiency, fatigue, recovery or sport-experience interpretations', 'the untraceable older coefficient set β = 0.00995, 0.00935, 0.00841 and 0.00549']:
    p=doc.add_paragraph(style='List Bullet'); p.add_run(x)

doc.add_paragraph('Source boundary / 来源边界', style='Heading 1')
add_bilingual(
    'The numerical basis of this draft is the 0805 aligned eye-tracking–EEG package, supplemented by the reproducible 18-August factor-level and temporal audit outputs. The 0803 package is treated as a historical/compatibility version rather than a competing final source.',
    '本稿数值基础为0805对齐眼动–EEG分析包，并辅以可复核的8月18日factor-level和temporal审计输出。0803作为历史/兼容版本保留，不与0805混合作为另一套正式最终结果。'
)

doc.save(OUT)
print(OUT)
