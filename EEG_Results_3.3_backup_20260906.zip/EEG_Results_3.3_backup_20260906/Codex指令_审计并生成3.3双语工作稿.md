# Codex 指令：审计并生成 EEG Results 3.3 双语工作稿

## 任务目标

请基于指定的 0805 正式 EEG 分析输出，以及已经完成的 2026-08-18 补充审计，生成一份可供作者审阅的 `Results 3.3` 中英文双语工作稿。

本任务的核心不是重新发明新的 EEG 结论，而是：

1. 核对 0805 输出中的可追溯数值；
2. 将遗漏但有数据支持的 EEG 结果补入 3.3；
3. 修正 previous-scene 的样本量和统计表述；
4. 删除没有源数据支持的旧表述；
5. 明确哪些结论可以直接采用，哪些必须等原分析电脑的溯源回复。

## 数据和证据来源

正式 EEG 结果优先使用：

```text
D:\投稿desk\2026sci\260419投稿材料\260722\数据分析结果包-0805（对齐眼动eeg）
```

历史/兼容版本：

```text
D:\投稿desk\2026sci\260419投稿材料\260722\数据分析结果包-0803-（剔除eeg0 5 10 15）
```

2026-08-18 补充审计输出：

```text
D:\投稿desk\2026sci\260419投稿材料\260722\EEG再发现\reanalysis_out
```

当前审计矩阵和差异报告：

```text
C:\Users\PCI\Documents\论文分析\审计输出_260906_3.2_3.3
```

其中优先检查：

- `FINAL_SOURCE_OF_TRUTH_MATRIX.md`
- `DISCREPANCY_AUDIT.md`
- `AUDIT_EXECUTIVE_SUMMARY.md`
- `EEG_CORE_COEFFICIENT_144_AUDIT.csv`
- `EEG_BROADER_COEFFICIENT_324_AUDIT.csv`
- `EEG_PREVIOUS_SCENE_48_SOURCE_COPY.csv`
- `EEG_ONSET_WINDOW_PAIRWISE_756_SOURCE_COPY.csv`

## 当前已核验、可用于正文的事实

### 1. 0、5、10、15 s onset-trim variants

0805 最终管线将 0、5、10、15 s 作为并行分析 variant，并使用 common-QC 输入进行比较。

在没有运行前统计计划、带日期配置或早期日志以前，只能写：

```text
The 0-, 5-, 10-, and 15-s onset-trim variants were analysed in parallel in the final analysis pipeline.
```

不要擅自写：

```text
prospectively prespecified equal-status variants
```

### 2. 3.3.1 factor-level complementary finding

2026-08-18 基于 0805 common-QC 输入的补充 factor-level reanalysis 显示：

occipital theta relative power 在 high-complexity condition (C1) 高于 low-complexity condition (C0)，且四个 variant 均达到联合 CR2 BH-FDR criterion：

- 0 s: β = 0.00436, 95% CI [0.00226, 0.00646], CR2 p = 0.00018, joint q = 0.00443
- 5 s: β = 0.00451, 95% CI [0.00248, 0.00654], CR2 p = 7.81 × 10−5, joint q = 0.00371
- 10 s: β = 0.00503, 95% CI [0.00297, 0.00708], CR2 p = 2.13 × 10−5, joint q = 0.00205
- 15 s: β = 0.00488, 95% CI [0.00262, 0.00714], CR2 p = 0.00012, joint q = 0.00371

默认写作：

```text
complementary factor-level reanalysis
```

只有学生提供运行前证据后，才可考虑提高其分析地位。

### 3. 3.3.2 core condition-related coefficients

四个核心 EEG outcomes × 9 个条件相关系数 × 4 个 variant = 144 项。

目前唯一可追溯的四个 frontal theta relative power `WWR45 × C1` 数值为：

- 0 s: β = 0.00757, unadjusted CR2 p = 0.0288
- 5 s: β = 0.00856, unadjusted CR2 p = 0.0132
- 10 s: β = 0.00750, unadjusted CR2 p = 0.0334
- 15 s: β = 0.00475, unadjusted CR2 p = 0.1704

前三个 unadjusted CR2 p < 0.05，但没有任何系数达到 CR2 BH-FDR criterion。

扩展的 9 outcomes 审计共 324 项；14 项 unadjusted CR2 p < 0.05，但没有任何系数达到 CR2 BH-FDR criterion。

### 4. 3.3.3 temporal adjustment coefficients

可报告为 temporal adjustment-related associations：

- viewing round 与 frontal、parietal、occipital theta relative power呈负向系数；
- viewing round 和 within-round presentation position 与 alpha relative power 多数呈正向系数；
- log10 absolute alpha-power 审计中也观察到正向 temporal adjustment coefficients；
- 72 个 broader reanalysis models 全部收敛，singular fit = 0。

不要解释为 fatigue、adaptation、learning 或 recovery。

### 5. 3.3.4 previous-scene

common-QC 输入为 42 participants / 461 trials，但 75 个首场景试次没有 PreviousWWR，因此 previous-scene 模型实际为 42 participants / 386 complete trials。

48 项 previous-scene tests 中有两个 unadjusted hits：

- 10 s: occipital theta relative power, previous-scene WWR75, β = 0.00309, unadjusted CR2 p = 0.04435, q = 0.53219
- 15 s: occipital theta relative power, previous-scene WWR75, β = 0.00425, unadjusted CR2 p = 0.00986, q = 0.11835

两者均未达到 CR2 BH-FDR criterion。

### 6. 3.3.4 parietal beta WWR omnibus

只有 15-s variant 达到联合 CR2 BH-FDR criterion：

- 15 s: F(2, 30.45) = 9.42471, CR2 p = 0.00065, within-variant q = 0.01760, joint q = 0.02816
- 0 s joint q = 0.11715
- 5 s joint q = 0.13744
- 10 s joint q = 0.11715

只能写为：

```text
hypothesis-generating supplementary finding
```

不能写成稳定的 WWR effect、WWR45 peak、optimal WWR 或 inverted-U pattern。

### 7. 756 项窗口比较

756 项 onset-trim pairwise coefficient contrasts 的全部 95% confidence intervals 均包含零。

必须说明：

- 是 descriptive sensitivity analysis；
- 不是 equivalence test；
- 不是选择最佳 onset-trim variant 的依据。

## 必须删除或暂不恢复的旧内容

不要使用以下表述：

- `previous-scene WWR = 30`
- 旧的 previous-scene β = −0.00864, p = 0.0473
- gray-screen occipital-alpha recovery analysis
- WWR45 theta peak
- inverted-U 或 optimal WWR
- neural efficiency
- fatigue、recovery、sport experience 等超出当前 Results 证据的解释
- 旧的无法追溯系数集合 β = 0.00995、0.00935、0.00841、0.00549

正式实验 WWR 只有 15%、45%、75%。

## 学生必须回答的问题

在最终定稿前，请向原分析学生确认：

1. 0、5、10、15 s 是否在最终管线中并行分析，还是查看结果后才增加其他 variant？
2. 144 项是否在运行前正式定义为 primary multiplicity family，还是从 324 项扩展审计中提取的核心子集？
3. 0805 运行时实际工作区是否等同于 GitHub commit `5174929f189fda0f2945488575f04792a41a7ed2`，还是该 commit 之前的未提交工作区？
4. 实际运行使用的 `teacher_analysis.parallel.json` 位于何处？
5. relative power 分母是否由代码明确设为 1–45 Hz？
6. filtering、50-Hz notch、average re-reference、ICA 是否有 EEGLAB history、MATLAB脚本或处理日志可以归档？

## 输出要求

请生成：

1. 一份中英文双语的 `Results 3.3` 工作稿；
2. 每一节标注证据状态：Confirmed / Qualified / Awaiting confirmation；
3. 正文中同时给出样本量、β、95% CI、CR2 p、BH-adjusted q以及校正标准；
4. 在文末附：
   - 修改说明；
   - 待学生回复后再决定的事项；
   - 当前不应恢复的旧表述；
5. 不要把待确认事项写成已经证实的事实；
6. 不要重新计算或改动已经核验的数值，除非明确找到新的机器可读源表。

## 术语锁定

全文使用以下固定术语：

- CR2 BH-FDR criterion
- BH-adjusted q
- unadjusted CR2 p
- onset-trim variant
- 0-, 5-, 10-, and 15-s onset-trim variants
- common-QC sample
- viewing round
- within-round presentation position
- exercise frequency
- occipital theta relative power
- frontal theta relative power
- parietal beta relative power
- log10 absolute power

Results 中不要加入机制性解释。

