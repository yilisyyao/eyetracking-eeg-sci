# EEG 0906审计、Results 3.3与Methods修订代码备份

归档日期：2026-09-07

## 目的

本目录保存两类材料：

1. 生成本轮中英文Methods、Results 3.3及逐题回应Word文件的代码；
2. 2026-08-18事后EEG factor-level与temporal复核的脚本和已经核验的机器输出。

本包不包含原始参与者级EEG数据、`.set/.fdt`文件或四个common-QC模型输入。上传公开GitHub仓库前，仍应检查机构的数据共享规定。

## 目录

### `document_generation/`

- `build_eeg_0906_revision_docx.py`：生成中英文Methods与Results 3.3替换稿。
- `build_eeg_revision_response_docx.py`：生成修改说明及对0906两份疑问文件的逐题回应。
- `qa_eeg_0906_revision_docx.py`：第一份Word的关键内容核验脚本。
- `qa_docx_structure.py`：通用DOCX结构、ZIP完整性及必需文本检查。

两份生成脚本顶部的`OUT`为本次实际运行时使用的绝对输出路径。换电脑后请修改`OUT`，或将其改成命令行参数。

Python依赖：

```bash
python -m pip install python-docx pandas
```

### `eeg_posthoc_reanalysis/`

- `reanalyse_factor_tests.R`：2026-08-18实际保存的LMM、CR2、factor-level和temporal系数复核脚本。
- `summarize_temporal.py`：把temporal CR2结果整理为core/broader、relative/log10 absolute校正家族。

`reanalyse_factor_tests.R`第一行包含当时Codex工作目录的本地R library路径。这一行属于历史运行环境记录，换电脑时应删除或替换；不得把该绝对路径当成分析参数。

R依赖：

```r
install.packages(c("lme4", "emmeans", "clubSandwich", "readr"))
```

R脚本调用方式：

```bash
Rscript reanalyse_factor_tests.R <input_dir> <output_dir>
```

`input_dir`必须包含：

```text
input0.csv
input5.csv
input10.csv
input15.csv
```

四个文件应分别对应0805 common-QC的0、5、10、15 s模型输入，且每个文件均为42名参与者、461个试次。正式复现前必须记录其SHA-256。

temporal BH整理：

```bash
python summarize_temporal.py <coefficient_CR2_crosscheck.csv> <temporal_CR2_tests.csv>
```

### `verified_outputs/`

- `coefficient_CR2_crosscheck.csv`：18 outcomes × 4 variants的系数和CR2结果汇总。
- `factor_level_CR2_tests.csv`：factor-level完整结果。
- `factor_level_CR2_signals.csv`：达到窗口内或跨variant校正标准的factor-level结果摘录。
- `temporal_CR2_tests.csv`：temporal adjustment variable的core/broader校正结果。
- `model_diagnostics.csv`：72个模型的样本、收敛和singular状态。

这些文件来自本机`EEG再发现/reanalysis_out`，不属于0805原始teacher pipeline输出。论文中如引用，必须标记为`post hoc complementary reanalysis conducted on 18 August 2026`。

## 统计边界

- 0805原始核心四窗口CR2表只保存unadjusted CR2 p，没有专属36/144项BH输出。
- 144表示4个核心结局×9个条件/组别系数×4种onset-trim variant，不能自动称为预设primary multiplicity family。
- post hoc factor-level家族分别为96项core relative、216项broader relative和216项broader log10 absolute。
- temporal分析拟合72个模型；relative与log10 absolute各有独立72-test BH family。
- 756行onset-trim窗口对比是描述性系数对比，不是756项正式检验或等效性分析。

## 未收入的旧脚本

旧`build_revised_33.py`曾硬编码`previous-scene WWR = 30`及未经源表读取的数字，因此未作为有效修订代码收入本包。保留历史副本时应明确标记为deprecated/invalid，不得再次用于生成正文。

## 推荐Git提交说明

```text
archive: add EEG 0906 audit response, post-hoc reanalysis scripts, and verified outputs
```

## 完整性

`SHA256SUMS.txt`记录本包内各文件的SHA-256。上传后可重新计算并与之比较。ZIP文件本身不列入其内部清单。
