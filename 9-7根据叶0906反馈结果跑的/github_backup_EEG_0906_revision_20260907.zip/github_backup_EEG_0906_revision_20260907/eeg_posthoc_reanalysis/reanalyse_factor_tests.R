.libPaths(c("C:/Users/PCI/.codex/visualizations/2026/08/18/01a01449-100b-7952-b2cc-b69006f7157e/Rlib", .libPaths()))

suppressPackageStartupMessages({
  library(lme4)
  library(emmeans)
  library(clubSandwich)
  library(readr)
})
emm_options(lmer.df = "asymptotic")

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("Usage: reanalyse_factor_tests.R <input_dir> <output_dir>")
input_dir <- args[[1]]
output_dir <- args[[2]]
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

inputs <- c(
  `0` = "input0.csv",
  `5` = "input5.csv",
  `10` = "input10.csv",
  `15` = "input15.csv"
)

core_relative <- c(
  "O_theta_relative", "F_theta_relative",
  "O_alpha_relative", "O_beta_relative"
)
broader_relative <- c(
  core_relative,
  "P_theta_relative", "P_alpha_relative", "F_alpha_relative",
  "F_beta_relative", "P_beta_relative"
)
core_absolute <- c(
  "log10_O_theta_absolute", "log10_F_theta_absolute",
  "log10_O_alpha_absolute", "log10_O_beta_absolute"
)
broader_absolute <- c(
  core_absolute,
  "log10_P_theta_absolute", "log10_P_alpha_absolute", "log10_F_alpha_absolute",
  "log10_F_beta_absolute", "log10_P_beta_absolute"
)

condition_effects <- c(
  "WWR", "Complexity", "ExerciseFrequency",
  "WWR:Complexity", "WWR:ExerciseFrequency",
  "Complexity:ExerciseFrequency"
)

prepare_data <- function(path) {
  d <- as.data.frame(read_csv(
    path, na = c("", "NA"), show_col_types = FALSE,
    locale = locale(encoding = "UTF-8")
  ))
  d$Complexity <- ifelse(is.na(d$Complexity), "C0", d$Complexity)
  d$WWR <- factor(d$WWR, levels = c("WWR15", "WWR45", "WWR75"))
  d$Complexity <- factor(d$Complexity, levels = c("C0", "C1"))
  d$ExperienceGroup <- factor(d$ExperienceGroup, levels = c("High", "Low"))
  d$Gender <- factor(d$Gender)
  d$OrderGroup <- factor(d$OrderGroup)
  d$Participant <- factor(d$Participant)
  abs_map <- c(
    log10_O_theta_absolute = "O_theta_absolute",
    log10_F_theta_absolute = "F_theta_absolute",
    log10_O_alpha_absolute = "O_alpha_absolute",
    log10_O_beta_absolute = "O_beta_absolute",
    log10_P_theta_absolute = "P_theta_absolute",
    log10_P_alpha_absolute = "P_alpha_absolute",
    log10_F_alpha_absolute = "F_alpha_absolute",
    log10_F_beta_absolute = "F_beta_absolute",
    log10_P_beta_absolute = "P_beta_absolute"
  )
  for (target in names(abs_map)) {
    source <- abs_map[[target]]
    if (!target %in% names(d) && source %in% names(d)) {
      d[[target]] <- ifelse(d[[source]] > 0, log10(d[[source]]), NA_real_)
    }
  }
  d
}

fit_outcome <- function(d, outcome) {
  rhs <- paste(
    "WWR * Complexity + WWR * ExperienceGroup +",
    "Complexity * ExperienceGroup + Gender + Block +",
    "PositionWithinBlockCentered + OrderGroup + (1 | Participant)"
  )
  form <- as.formula(paste(outcome, "~", rhs))
  lmer(form, data = d, REML = TRUE)
}

raw_interaction_L <- function(mod, patterns) {
  nm <- names(fixef(mod))
  keep <- Reduce(`|`, lapply(patterns, function(p) grepl(p, nm)))
  idx <- which(keep)
  L <- matrix(0, nrow = length(idx), ncol = length(nm),
              dimnames = list(nm[idx], nm))
  for (i in seq_along(idx)) L[i, idx[i]] <- 1
  L
}

main_effect_L <- function(mod, variable) {
  emm <- emmeans(mod, specs = as.formula(paste("~", variable)), weights = "equal")
  ctr <- contrast(emm, method = "trt.vs.ctrl", ref = 1, adjust = "none")
  ctr@linfct
}

effect_L <- function(mod, effect) {
  if (effect == "WWR") return(main_effect_L(mod, "WWR"))
  if (effect == "Complexity") return(main_effect_L(mod, "Complexity"))
  if (effect == "ExerciseFrequency") return(main_effect_L(mod, "ExperienceGroup"))
  if (effect == "WWR:Complexity") {
    return(raw_interaction_L(mod, c(
      "^WWRWWR45:ComplexityC1$", "^WWRWWR75:ComplexityC1$"
    )))
  }
  if (effect == "WWR:ExerciseFrequency") {
    return(raw_interaction_L(mod, c(
      "^WWRWWR45:ExperienceGroupLow$", "^WWRWWR75:ExperienceGroupLow$"
    )))
  }
  if (effect == "Complexity:ExerciseFrequency") {
    return(raw_interaction_L(mod, c("^ComplexityC1:ExperienceGroupLow$")))
  }
  stop("Unknown effect: ", effect)
}

test_L <- function(mod, V, L) {
  wt <- as.data.frame(Wald_test(mod, constraints = L, vcov = V, test = "HTZ"))
  beta <- fixef(mod)
  estimates <- as.numeric(L %*% beta)
  cov_L <- L %*% V %*% t(L)
  ses <- sqrt(diag(cov_L))
  list(
    F = wt$Fstat[[1]],
    df_num = wt$df_num[[1]],
    df_denom = wt$df_denom[[1]],
    p = wt$p_val[[1]],
    estimates = estimates,
    ses = ses
  )
}

contrast_rows <- function(mod, V, grid_formula, contrast_family, window, outcome) {
  emm <- emmeans(mod, specs = grid_formula, weights = "equal")
  out <- list()
  add_contrast <- function(ctr, label, adjustment_family) {
    L <- ctr@linfct
    for (i in seq_len(nrow(L))) {
      tst <- test_L(mod, V, L[i, , drop = FALSE])
      df <- tst$df_denom
      ci_mult <- qt(0.975, df = df)
      out[[length(out) + 1]] <<- data.frame(
        onset_trim_s = window,
        outcome = outcome,
        contrast_family = contrast_family,
        adjustment_family = adjustment_family,
        contrast = paste0(label, rownames(L)[i] %||% i),
        estimate = tst$estimates[[1]],
        cr2_se = tst$ses[[1]],
        df = df,
        ci_low = tst$estimates[[1]] - ci_mult * tst$ses[[1]],
        ci_high = tst$estimates[[1]] + ci_mult * tst$ses[[1]],
        p_cr2 = tst$p,
        stringsAsFactors = FALSE
      )
    }
  }
  if (contrast_family == "complexity_within_wwr") {
    for (w in levels(emm@grid$WWR)) {
      sub_emm <- emm[emm@grid$WWR == w]
      ctr <- contrast(sub_emm, method = "trt.vs.ctrl", ref = 1, adjust = "none")
      rownames(ctr@linfct) <- paste0("C1-C0|", w)
      add_contrast(ctr, "", paste0("complexity_within_wwr|", window, "|", outcome))
    }
  } else if (contrast_family == "wwr_within_complexity") {
    for (cplx in levels(emm@grid$Complexity)) {
      sub_emm <- emm[emm@grid$Complexity == cplx]
      ctr <- contrast(sub_emm, method = "pairwise", adjust = "none")
      rownames(ctr@linfct) <- paste0(as.character(ctr@grid$contrast), "|", cplx)
      add_contrast(ctr, "", paste0("wwr_within_complexity|", window, "|", outcome, "|", cplx))
    }
  }
  do.call(rbind, out)
}

`%||%` <- function(x, y) if (is.null(x)) y else x

test_rows <- list()
simple_rows <- list()
diag_rows <- list()
coef_rows <- list()

for (window in names(inputs)) {
  d <- prepare_data(file.path(input_dir, inputs[[window]]))
  outcomes <- unique(c(broader_relative, broader_absolute))
  for (outcome in outcomes) {
    mod <- fit_outcome(d, outcome)
    V <- vcovCR(mod, cluster = d$Participant, type = "CR2")
    diag_rows[[length(diag_rows) + 1]] <- data.frame(
      onset_trim_s = as.numeric(window), outcome = outcome,
      n_obs = nobs(mod), n_participants = nlevels(d$Participant),
      singular = isSingular(mod, tol = 1e-4),
      converged = is.null(mod@optinfo$conv$lme4$messages),
      stringsAsFactors = FALSE
    )
    ct <- as.data.frame(coef_test(mod, vcov = V, test = "Satterthwaite"))
    ct$term <- rownames(ct)
    rownames(ct) <- NULL
    coef_rows[[length(coef_rows) + 1]] <- data.frame(
      onset_trim_s = as.numeric(window), outcome = outcome,
      term = ct$term, estimate = ct$beta, cr2_se = ct$SE,
      df = ct$df_Satt, p_cr2 = ct$p_Satt,
      stringsAsFactors = FALSE
    )
    for (effect in condition_effects) {
      L <- effect_L(mod, effect)
      tst <- test_L(mod, V, L)
      single_est <- if (length(tst$estimates) == 1) tst$estimates[[1]] else NA_real_
      single_se <- if (length(tst$ses) == 1) tst$ses[[1]] else NA_real_
      ci_mult <- if (length(tst$estimates) == 1) qt(0.975, df = tst$df_denom) else NA_real_
      test_rows[[length(test_rows) + 1]] <- data.frame(
        onset_trim_s = as.numeric(window), outcome = outcome,
        effect = effect, F_CR2 = tst$F, df_num = tst$df_num,
        df_denom = tst$df_denom, p_CR2 = tst$p,
        effect_estimate = single_est, cr2_se = single_se,
        ci_low = single_est - ci_mult * single_se,
        ci_high = single_est + ci_mult * single_se,
        stringsAsFactors = FALSE
      )
    }
    if (outcome %in% broader_relative) {
      simple_rows[[length(simple_rows) + 1]] <- contrast_rows(
        mod, V, ~ WWR * Complexity, "complexity_within_wwr",
        as.numeric(window), outcome
      )
      simple_rows[[length(simple_rows) + 1]] <- contrast_rows(
        mod, V, ~ WWR * Complexity, "wwr_within_complexity",
        as.numeric(window), outcome
      )
    }
  }
}

tests_base <- do.call(rbind, test_rows)

make_family <- function(df, family_name, outcomes) {
  x <- df[df$outcome %in% outcomes, , drop = FALSE]
  x$family <- family_name
  x$p_BH_within_window <- ave(x$p_CR2, x$onset_trim_s, FUN = function(z) p.adjust(z, method = "BH"))
  x$p_BH_parallel <- p.adjust(x$p_CR2, method = "BH")
  x
}

factor_tests <- rbind(
  make_family(tests_base, "core_relative_factor_tests", core_relative),
  make_family(tests_base, "broader_relative_factor_tests", broader_relative),
  make_family(tests_base, "core_log10_absolute_factor_tests", core_absolute),
  make_family(tests_base, "broader_log10_absolute_factor_tests", broader_absolute)
)

simple_contrasts <- do.call(rbind, simple_rows)
simple_contrasts$p_Holm <- ave(
  simple_contrasts$p_cr2, simple_contrasts$adjustment_family,
  FUN = function(z) p.adjust(z, method = "holm")
)

write_csv(factor_tests, file.path(output_dir, "factor_level_CR2_tests.csv"), na = "")
write_csv(simple_contrasts, file.path(output_dir, "relative_power_simple_CR2_contrasts.csv"), na = "")
write_csv(do.call(rbind, diag_rows), file.path(output_dir, "model_diagnostics.csv"), na = "")
write_csv(do.call(rbind, coef_rows), file.path(output_dir, "coefficient_CR2_crosscheck.csv"), na = "")

sig <- factor_tests[factor_tests$p_BH_parallel < 0.05 | factor_tests$p_BH_within_window < 0.05, ]
write_csv(sig, file.path(output_dir, "factor_level_CR2_signals.csv"), na = "")
