from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def bh_adjust(values: pd.Series) -> pd.Series:
    p = values.astype(float)
    order = p.sort_values().index
    ranked = p.loc[order]
    n = len(ranked)
    adjusted = ranked * n / pd.Series(range(1, n + 1), index=order)
    adjusted = adjusted.iloc[::-1].cummin().iloc[::-1].clip(upper=1.0)
    return adjusted.reindex(values.index)


CORE = [
    "O_theta_relative",
    "F_theta_relative",
    "O_alpha_relative",
    "O_beta_relative",
]
BROADER = CORE + [
    "P_theta_relative",
    "P_alpha_relative",
    "F_alpha_relative",
    "F_beta_relative",
    "P_beta_relative",
]
ABS_CORE = [
    "log10_O_theta_absolute",
    "log10_F_theta_absolute",
    "log10_O_alpha_absolute",
    "log10_O_beta_absolute",
]
ABS_BROADER = ABS_CORE + [
    "log10_P_theta_absolute",
    "log10_P_alpha_absolute",
    "log10_F_alpha_absolute",
    "log10_F_beta_absolute",
    "log10_P_beta_absolute",
]
TERMS = ["Block", "PositionWithinBlockCentered"]


def add_family(df: pd.DataFrame, family: str, outcomes: list[str]) -> pd.DataFrame:
    out = df[df["outcome"].isin(outcomes) & df["term"].isin(TERMS)].copy()
    out["family"] = family
    out["p_BH_within_window"] = out.groupby("onset_trim_s", group_keys=False)["p_cr2"].apply(bh_adjust)
    out["p_BH_parallel"] = bh_adjust(out["p_cr2"])
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    df = pd.read_csv(args.input)
    out = pd.concat(
        [
            add_family(df, "core_temporal_32", CORE),
            add_family(df, "broader_temporal_72", BROADER),
            add_family(df, "core_log10_absolute_temporal_32", ABS_CORE),
            add_family(df, "broader_log10_absolute_temporal_72", ABS_BROADER),
        ],
        ignore_index=True,
    )
    out.to_csv(args.output, index=False)


if __name__ == "__main__":
    main()
