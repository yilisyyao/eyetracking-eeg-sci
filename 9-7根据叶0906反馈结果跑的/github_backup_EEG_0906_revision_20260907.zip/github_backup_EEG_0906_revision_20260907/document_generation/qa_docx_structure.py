import hashlib
import sys
import zipfile
from pathlib import Path

from docx import Document


p = Path(sys.argv[1])
d = Document(p)
with zipfile.ZipFile(p) as archive:
    bad = archive.testzip()
    xml = archive.read("word/document.xml").decode("utf-8")
text = "\n".join(x.text for x in d.paragraphs)
text += "\n" + "\n".join(
    cell.text for table in d.tables for row in table.rows for cell in row.cells
)
required = sys.argv[2:]
print({
    "exists": p.exists(),
    "bytes": p.stat().st_size,
    "paragraphs": len(d.paragraphs),
    "headings": sum(x.style.name.startswith("Heading") for x in d.paragraphs),
    "tables": [(len(t.rows), len(t.columns)) for t in d.tables],
    "page_breaks": xml.count('w:type="page"'),
    "zip_error": bad,
    "missing_required": [x for x in required if x not in text],
    "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
})
