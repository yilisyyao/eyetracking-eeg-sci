from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


OUT = Path(r"C:\Users\PCI\Documents\论文分析\EEG_Methods与Results3.3_整合0906回应_中英文_20260907.docx")


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=90, start=100, bottom=90, end=100):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_keep_with_next(paragraph):
    p_pr = paragraph._p.get_or_add_pPr()
    keep_next = OxmlElement("w:keepNext")
    p_pr.append(keep_next)


def add_body(doc, text, *, italic=False, bold_lead=None, space_after=5, first_line=True):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.15
    if first_line:
        p.paragraph_format.first_line_indent = Cm(0.74)
    if bold_lead and text.startswith(bold_lead):
        r1 = p.add_run(bold_lead)
        r1.bold = True
        r2 = p.add_run(text[len(bold_lead):])
        r2.italic = italic
    else:
        r = p.add_run(text)
        r.italic = italic
    return p


def add_bullet(doc, text, level=0):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.line_spacing = 1.1
    p.add_run(text)
    return p


def add_table(doc, headers, rows, widths=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    for i, h in enumerate(headers):
        cell = hdr.cells[i]
        set_cell_shading(cell, "D9EAF7")
        set_cell_margins(cell)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(h)
        r.bold = True
    for row_data in rows:
        row = table.add_row()
        for i, val in enumerate(row_data):
            cell = row.cells[i]
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            p.add_run(str(val))
    if widths:
        for row in table.rows:
            for i, width in enumerate(widths):
                row.cells[i].width = Cm(width)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


doc = Document()
section = doc.sections[0]
section.top_margin = Cm(2.2)
section.bottom_margin = Cm(2.0)
section.left_margin = Cm(2.4)
section.right_margin = Cm(2.2)

styles = doc.styles
normal = styles["Normal"]
normal.font.name = "Times New Roman"
normal.font.size = Pt(10.5)
normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

for style_name, size, color in [
    ("Title", 20, "1F4E79"),
    ("Heading 1", 15, "1F4E79"),
    ("Heading 2", 12.5, "2F5597"),
    ("Heading 3", 11.5, "365F91"),
]:
    s = styles[style_name]
    s.font.name = "Arial"
    s.font.size = Pt(size)
    s.font.color.rgb = RGBColor.from_string(color)
    s._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")

styles["Title"].paragraph_format.space_after = Pt(10)
styles["Heading 1"].paragraph_format.space_before = Pt(12)
styles["Heading 1"].paragraph_format.space_after = Pt(6)
styles["Heading 2"].paragraph_format.space_before = Pt(9)
styles["Heading 2"].paragraph_format.space_after = Pt(4)
styles["Heading 3"].paragraph_format.space_before = Pt(7)
styles["Heading 3"].paragraph_format.space_after = Pt(3)

p = doc.add_paragraph(style="Title")
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run("EEG Methods与Results 3.3修订稿\n")
r = p.add_run("Bilingual revision integrating the 0906 audit responses")
r.font.size = Pt(12)
r.font.color.rgb = RGBColor.from_string("5B6573")

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_after = Pt(12)
r = p.add_run("版本：2026-09-07｜建议替换稿＋修改说明＋待确认事项")
r.italic = True
r.font.color.rgb = RGBColor.from_string("666666")

doc.add_heading("使用说明与结论等级", level=1)
add_body(doc, "本稿以0805正式parallel管线为原始结果来源，并结合学生于0906提交的溯源报告。8月18日本机保留的factor-level与18-outcome temporal输出可被读取，但学生原分析电脑未找到这些输出；因此，本稿仅将其作为事后补充复核（post hoc complementary reanalysis），不将其描述为0805预设主分析。", first_line=False)
add_body(doc, "当前可直接锁定的改动包括：relative power分母由1–30 Hz改为1–45 Hz；四个onset-trim variant只描述为最终管线中的平行分析；previous-scene实际建模样本改为42名参与者、386个完整试次；删除gray-screen occipital-alpha recovery的正式推断性表述；将144项从“primary multiplicity family”改为客观的系数计数；把72个模型与每种功率尺度各72项temporal检验区分开。", first_line=False)
add_body(doc, "本稿保留的新发现均采用审慎措辞：visual complexity与occipital theta relative power的关系、viewing round相关的alpha/theta时序模式，以及within-round presentation position与parietal alpha relative power的关系。它们都明确标为8月18日事后复核结果，不用于支持疲劳、适应、学习、恢复、认知负荷或神经效率等机制解释。", first_line=False)

doc.add_heading("Part I. English manuscript-ready replacement text", level=1)

doc.add_heading("Methods: EEG preprocessing and frequency-domain measures", level=2)
add_body(doc, "EEG recordings were manually preprocessed in EEGLAB. The archived EEGLAB histories document 0.5–40 Hz band-pass filtering, 49–51 Hz band-stop filtering, average re-referencing, and independent component analysis using runica with the extended Infomax option. ICA decomposition was used to support manual artifact inspection. Participant-level component-rejection records were not retained in the archived analysis materials; therefore, the number and identity of excluded components are not reported.")
add_body(doc, "For frequency-domain extraction, scene epochs were defined from event marker 7 to event marker 8. To assess sensitivity to activity near scene onset, the first 0, 5, 10, or 15 s of each scene epoch were removed. The 0-, 5-, 10-, and 15-s onset-trim variants were analysed in parallel in the final analysis pipeline, with the 10-s variant retained as a compatibility reference. This wording describes the final pipeline and does not imply that the four variants had prospectively prespecified equal status from the outset.")
add_body(doc, "Signals were averaged within frontal, parietal and occipital regions of interest before spectral estimation. Power spectral density was estimated using Welch’s method with 2-s windows, 50% overlap and a fast Fourier transform length equal to the next power of two. Band power was obtained by trapezoidal integration. Theta, alpha and beta relative power was calculated as band-specific Welch power divided by total Welch power integrated over 1–45 Hz within the same region of interest. The same denominator was used for all three bands. Absolute band power was log10-transformed for complementary analyses. Low- and high-beta features were extracted by the upstream pipeline but were not included among the 18 outcomes in the post hoc temporal reanalysis.")
add_body(doc, "The four core EEG outcomes were occipital theta relative power, frontal theta relative power, occipital alpha relative power and occipital beta relative power. The broader post hoc outcome set comprised theta, alpha and beta power from the frontal, parietal and occipital regions on both the relative-power and log10 absolute-power scales. Resting-state recordings were used for descriptive context only. No formal inferential gray-screen occipital-alpha recovery analysis was retained because the archived code generated paired scene/gray rows and a descriptive alpha difference but did not implement or save a corresponding inferential model.")

doc.add_heading("Methods: EEG statistical analysis", level=2)
add_body(doc, "The four onset-trim variants used a common-QC sample of 42 participants and 461 trials. For each EEG outcome and onset-trim variant, a linear mixed-effects model included WWR, visual complexity and exercise frequency and their pairwise interactions, together with gender, viewing round, centred within-round presentation position and sequence group; participant was included as a random intercept. Inference for fixed effects used CR2 small-sample robust standard errors clustered by participant with Satterthwaite degrees of freedom.")
add_body(doc, "For the four core EEG outcomes, 144 condition- and group-related Model 1 coefficients were examined across the four onset-trim variants (4 outcomes × 9 coefficients × 4 variants). The archived 0805 CR2 source tables contain unadjusted CR2 p values but do not contain a dedicated 36-test within-variant or 144-test joint BH-adjustment output. Accordingly, 144 is reported as the number of examined coefficients rather than as a verified prespecified primary multiplicity family, and isolated unadjusted coefficient-level findings were not treated as multiplicity-corrected evidence.")
add_body(doc, "A post hoc complementary reanalysis conducted on 18 August used the same common-QC inputs and model structure to test factor-level and temporal effects. Factor-level CR2 p values were adjusted using the Benjamini–Hochberg procedure within each onset-trim variant and jointly across variants, separately for a 96-test core relative-power family (4 outcomes × 6 factor-level effects × 4 variants), a 216-test broader relative-power family (9 × 6 × 4) and a 216-test broader log10 absolute-power family (9 × 6 × 4). Temporal CR2 p values were adjusted separately for a 72-test relative-power family and a 72-test log10 absolute-power family (9 outcomes × 4 variants × 2 temporal adjustment variables per scale). These analyses fitted 72 models in total (18 outcomes × 4 variants); the number of fitted models and the size of each temporal BH family are therefore distinct quantities.")
add_body(doc, "Previous-scene models were fitted to the four core relative-power outcomes. Previous-scene WWR, visual complexity and their interaction were evaluated after excluding trials in the first within-round presentation position, for which the previous scene was structurally undefined. This left 42 participants and 386 complete trials in each onset-trim variant. BH adjustment was applied within each variant across 12 coefficients and jointly across the 48 coefficients from all four variants.")
add_body(doc, "A separate Gaussian generalized estimating-equation compatibility analysis generated 756 descriptive pairwise coefficient contrasts across onset-trim variants (6 variant pairs × 9 absolute-power outcomes × 14 coefficients, including the intercept). These contrasts were used only to describe sensitivity to onset trimming. They did not incorporate cross-window covariance and were neither formal paired tests nor equivalence tests.")

doc.add_heading("3.3 EEG results", level=2)
add_body(doc, "EEG results are reported in two explicitly separated layers. Original results are drawn from the 0805 final parallel pipeline. Factor-level and temporal findings are drawn from the post hoc complementary reanalysis conducted on 18 August using the 0805 common-QC inputs. The latter are presented as exploratory evidence and not as prospectively prespecified primary analyses.")

doc.add_heading("3.3.1 Analytical sample and final parallel framework", level=3)
add_body(doc, "Before common-sample restriction, the 0-, 5-, 10- and 15-s onset-trim variants retained 42 participants/471 trials, 42/469, 43/484 and 43/486, respectively. Their common-QC intersection comprised 42 participants and 461 trials and was used for the four-window Model 1 comparisons. The four variants were analysed in parallel in the final pipeline, with the 10-s variant retained as a compatibility reference. The four core outcomes were occipital theta relative power, frontal theta relative power, occipital alpha relative power and occipital beta relative power.")

doc.add_heading("3.3.2 Original core coefficient-level results", level=3)
add_body(doc, "Across the four core outcomes, 144 condition- and group-related Model 1 coefficients were examined across the four onset-trim variants. Three coefficients had unadjusted CR2 p < 0.05, all for the WWR45 × high-complexity condition (C1) in frontal theta relative power. At 0 s, β = 0.00757 and unadjusted CR2 p = 0.0288; at 5 s, β = 0.00856 and unadjusted CR2 p = 0.0132; and at 10 s, β = 0.00750 and unadjusted CR2 p = 0.0334. At 15 s, the corresponding coefficient was β = 0.00475 (unadjusted CR2 p = 0.1704). Because the archived 0805 CR2 tables did not retain a dedicated 36-test within-variant or 144-test joint BH-adjustment output, these isolated unadjusted coefficients were not interpreted as multiplicity-corrected evidence.")

doc.add_heading("3.3.3 Post hoc complementary factor-level and temporal results", level=3)
add_body(doc, "The post hoc factor-level CR2 analysis identified a visual-complexity marginal contrast for occipital theta relative power that was consistent across all four onset-trim variants. The estimated high- versus low-complexity difference, averaged with equal weights over WWR and exercise frequency, ranged from β = 0.00436 to 0.00503; the corresponding joint cross-variant BH-adjusted q values in the 96-test core relative-power family ranged from 0.00205 to 0.00443. This finding indicates a reproducible association between visual complexity and occipital theta relative power within the final common-QC sample, without identifying a preferred onset-trim variant.")
add_body(doc, "In the separate 72-test relative-power temporal family, viewing round had positive coefficients for alpha relative power in the frontal, parietal and occipital regions across all four onset-trim variants (β = 0.02199–0.02958; joint BH-adjusted q = 0.000065–0.00461). Viewing round also had negative coefficients for theta relative power in all three regions and all four variants (β = −0.00682 to −0.00453; joint BH-adjusted q = 0.00447–0.02239). Within-round presentation position was positively associated with parietal alpha relative power across the four variants (β = 0.00349–0.00428; joint BH-adjusted q = 0.02239–0.04391), whereas the corresponding frontal and occipital alpha relative-power coefficients did not meet the joint CR2 BH-FDR criterion.")
add_body(doc, "On the log10 absolute-power scale, viewing round was positively associated with alpha power across all three regions and all four variants (β = 0.10177–0.12120; joint BH-adjusted q = 0.000009–0.000180). Within-round presentation position showed the same positive direction for log10 absolute alpha power across all regions and variants (β = 0.01707–0.01998; joint BH-adjusted q = 0.00132–0.01297). These coefficients describe temporal adjustment variables and do not, by themselves, establish fatigue, adaptation, learning or recovery. All 72 models in this post hoc 18-outcome analysis converged, and none was flagged as singular.")

doc.add_heading("3.3.4 Supplementary and sensitivity analyses", level=3)
add_body(doc, "The post hoc factor-level log10 absolute-power analysis did not identify additional effects that met the joint cross-variant CR2 BH-FDR criterion. In the broader 216-test relative-power factor family, the parietal beta relative-power WWR factor met the joint criterion only for the 15-s variant (F(2, 30.45) = 9.42, CR2 p = 0.000652, joint BH-adjusted q = 0.0282); the corresponding 0-, 5- and 10-s tests did not (joint q = 0.117–0.137). Because this pattern was confined to one onset-trim variant and was not accompanied by a corrected WWR × visual complexity interaction, it was treated as hypothesis-generating.")
add_body(doc, "Previous-scene terms provided no corrected evidence of carry-over effects. These models used 42 participants and 386 complete trials after the 75 structurally undefined first-position trials had been excluded. For previous-scene WWR75 in occipital theta relative power, the 10-s estimate was β = 0.00309 (unadjusted CR2 p = 0.0443, within-variant BH-adjusted q = 0.5322, joint four-variant q = 0.8072), and the 15-s estimate was β = 0.00425 (unadjusted CR2 p = 0.00986, within-variant q = 0.1183, joint q = 0.4734). Neither met the CR2 BH-FDR criterion. The 0- and 5-s estimates were also not supported after correction.")
add_body(doc, "The direct onset-trim comparison comprised 756 descriptive pairwise coefficient contrasts. Every reported interval included zero. These contrasts did not identify a preferred onset-trim variant; however, because they ignored cross-window covariance and were not equivalence tests, they cannot establish that the variants were statistically equivalent.")

doc.add_page_break()
doc.add_heading("Part II. 中文对照替换稿", level=1)

doc.add_heading("Methods：EEG预处理与频域指标", level=2)
add_body(doc, "EEG数据在EEGLAB中进行手动预处理。现有EEGLAB history可确认0.5–40 Hz带通滤波、49–51 Hz带阻滤波、平均重参考，以及采用runica extended Infomax算法进行独立成分分析。ICA分解用于辅助人工伪迹检查。由于归档材料未保留参与者层面的成分剔除记录，正文不报告被剔除成分的数量或编号。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "频域提取时，以事件标记7至事件标记8界定场景epoch。为检验场景开始阶段活动对结果的敏感性，分别剔除每个场景epoch起始0、5、10或15 s。0、5、10和15 s四种onset-trim variant在最终分析管线中平行分析，其中10 s variant保留为兼容性参考。该表述仅描述最终管线，不意味着四种variant从一开始即被前瞻性预设为同等地位。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "在频谱估计前，先对额叶、顶叶和枕叶ROI内的信号取平均。功率谱密度采用Welch方法估计，窗口长度为2 s、重叠率为50%，FFT长度取下一2的幂。各频带功率通过梯形积分获得。theta、alpha和beta relative power定义为同一ROI内相应频带Welch功率除以1–45 Hz总Welch功率，三个频带使用同一分母。absolute power取log10后用于补充分析。上游管线虽提取了low beta和high beta特征，但二者未进入事后temporal复核的18个结局指标。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "四个核心EEG结局为occipital theta relative power、frontal theta relative power、occipital alpha relative power和occipital beta relative power。事后补充分析的较宽结局集合包括额叶、顶叶和枕叶ROI的theta、alpha和beta，并分别采用relative power和log10 absolute power尺度。静息态记录仅用于描述性背景。由于归档代码只生成了场景/灰屏配对行和描述性alpha差值，而未实施或保存相应推断模型，因此不保留正式的gray-screen occipital-alpha recovery推断分析。").paragraph_format.first_line_indent = Cm(0.74)

doc.add_heading("Methods：EEG统计分析", level=2)
add_body(doc, "四种onset-trim variant采用相同的common-QC sample，共42名参与者、461个试次。每个EEG结局和onset-trim variant分别拟合linear mixed-effects model。固定效应包括WWR、visual complexity、exercise frequency及其两两交互，同时纳入gender、viewing round、中心化的within-round presentation position和sequence group；participant作为随机截距。固定效应推断采用按participant聚类的CR2小样本稳健标准误和Satterthwaite自由度。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "四个核心EEG结局在四种onset-trim variant中共考察144个与条件或组别有关的Model 1系数（4个结局×9个系数×4种variant）。归档的0805 CR2源表仅包含unadjusted CR2 p，未保存专门的窗口内36项或跨窗口144项BH校正输出。因此，144仅作为已考察系数的数量报告，不称为已经证实的预设primary multiplicity family；孤立的未校正系数结果不作为多重校正后证据解释。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "2026年8月18日另行完成了一次事后补充复核，使用相同common-QC输入和模型结构检验factor-level与temporal效应。factor-level CR2 p分别在每个onset-trim variant内及四种variant联合进行Benjamini–Hochberg校正，校正家族包括：96项核心relative-power family（4个结局×6个factor-level效应×4种variant）、216项较宽relative-power family（9×6×4）和216项较宽log10 absolute-power family（9×6×4）。temporal CR2 p则分别在72项relative-power family和72项log10 absolute-power family内校正（每种尺度9个结局×4种variant×2个temporal adjustment variables）。该复核共拟合72个模型（18个结局×4种variant）；“72个模型”与“每种尺度72项temporal检验”是两个不同计数。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "previous-scene模型以四个核心relative-power结局为因变量。由于每个viewing round的首个within-round presentation position不存在previous scene，分析在明确排除这些试次后检验previous-scene WWR、visual complexity及其交互。每种onset-trim variant均包含42名参与者和386个完整试次。BH校正在每种variant的12个系数内进行，并进一步对四种variant合计48个系数进行联合校正。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "另一个Gaussian GEE兼容性分析生成了756行onset-trim variant两两系数对比（6组variant配对×9个absolute-power结局×14个系数，含截距）。这些对比仅用于描述结果对起始剔除长度的敏感性；其计算未纳入跨窗口协方差，因此既不是正式的配对检验，也不是等效性检验。").paragraph_format.first_line_indent = Cm(0.74)

doc.add_heading("3.3 EEG结果", level=2)
add_body(doc, "EEG结果明确分为两个层次：原始结果来自0805最终parallel管线；factor-level与temporal发现来自2026年8月18日基于0805 common-QC输入完成的事后补充复核。后者作为探索性证据报告，不描述为前瞻性预设的主分析。").paragraph_format.first_line_indent = Cm(0.74)

doc.add_heading("3.3.1 分析样本与最终平行框架", level=3)
add_body(doc, "在限制为共同样本前，0、5、10和15 s onset-trim variant分别保留42名参与者/471个试次、42/469、43/484和43/486。四种variant的common-QC交集为42名参与者、461个试次，用于四窗口Model 1比较。四种variant在最终管线中平行分析，其中10 s variant保留为兼容性参考。四个核心结局为occipital theta relative power、frontal theta relative power、occipital alpha relative power和occipital beta relative power。").paragraph_format.first_line_indent = Cm(0.74)

doc.add_heading("3.3.2 原始核心系数层面结果", level=3)
add_body(doc, "四个核心结局在四种onset-trim variant中共考察144个与条件或组别有关的Model 1系数。其中3个系数的unadjusted CR2 p < 0.05，均对应frontal theta relative power中的WWR45 × high-complexity condition（C1）。0 s时，β = 0.00757，unadjusted CR2 p = 0.0288；5 s时，β = 0.00856，p = 0.0132；10 s时，β = 0.00750，p = 0.0334。15 s时，相应系数为β = 0.00475（unadjusted CR2 p = 0.1704）。由于归档的0805 CR2表未保留专门的窗口内36项或跨窗口144项BH校正输出，这些孤立的未校正系数不解释为多重校正后证据。").paragraph_format.first_line_indent = Cm(0.74)

doc.add_heading("3.3.3 事后补充的factor-level与temporal结果", level=3)
add_body(doc, "事后factor-level CR2分析显示，visual complexity与occipital theta relative power的边际对比在四种onset-trim variant中方向一致。以相等权重对WWR和exercise frequency取平均后，high-相对于low-complexity的估计差异为β = 0.00436–0.00503；在96项核心relative-power family中，跨variant联合BH-adjusted q = 0.00205–0.00443。该结果支持visual complexity与occipital theta relative power在最终common-QC sample中的稳定关联，但未显示哪一种onset-trim variant更优。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "在独立的72项relative-power temporal family中，viewing round与三个ROI的alpha relative power均呈正向关系，且在四种onset-trim variant中均达到联合校正标准（β = 0.02199–0.02958；joint BH-adjusted q = 0.000065–0.00461）。viewing round与三个ROI的theta relative power均呈负向关系（β = −0.00682至−0.00453；joint BH-adjusted q = 0.00447–0.02239）。within-round presentation position仅与parietal alpha relative power在四种variant中呈校正后正向关系（β = 0.00349–0.00428；joint BH-adjusted q = 0.02239–0.04391）；相应的frontal和occipital alpha relative-power系数未达到联合CR2 BH-FDR判据。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "在log10 absolute-power尺度上，viewing round与三个ROI的alpha power在四种variant中均呈正向关系（β = 0.10177–0.12120；joint BH-adjusted q = 0.000009–0.000180）。within-round presentation position与三个ROI的log10 absolute alpha power也均呈正向关系（β = 0.01707–0.01998；joint BH-adjusted q = 0.00132–0.01297）。这些系数描述temporal adjustment variables本身，不能据此建立疲劳、适应、学习或恢复等机制解释。该事后18-outcome分析的72个模型均收敛，且无模型被标记为singular。").paragraph_format.first_line_indent = Cm(0.74)

doc.add_heading("3.3.4 补充与敏感性分析", level=3)
add_body(doc, "事后factor-level log10 absolute-power分析未发现达到跨variant联合CR2 BH-FDR判据的额外效应。在较宽的216项relative-power factor family中，parietal beta relative power的WWR factor仅在15 s variant达到联合标准（F(2, 30.45) = 9.42，CR2 p = 0.000652，joint BH-adjusted q = 0.0282）；0、5和10 s相应检验未达到标准（joint q = 0.117–0.137）。由于该模式仅出现在一种onset-trim variant，且没有校正后的WWR × visual complexity interaction支持，因此仅作为假设生成性结果。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "previous-scene项未提供校正后的carry-over效应证据。排除75个previous scene结构性未定义的首位置试次后，模型包含42名参与者、386个完整试次。对于occipital theta relative power中的previous-scene WWR75，10 s估计为β = 0.00309（unadjusted CR2 p = 0.0443，within-variant BH-adjusted q = 0.5322，四variant联合q = 0.8072）；15 s估计为β = 0.00425（unadjusted CR2 p = 0.00986，within-variant q = 0.1183，联合q = 0.4734）。二者均未达到CR2 BH-FDR判据；0和5 s估计经校正后同样不受支持。").paragraph_format.first_line_indent = Cm(0.74)
add_body(doc, "直接onset-trim比较包括756行描述性两两系数对比，所有报告区间均包含0。这些对比未显示优选的onset-trim variant；但由于其未纳入跨窗口协方差，且并非等效性检验，因此不能据此断言四种variant在统计上等效。").paragraph_format.first_line_indent = Cm(0.74)

doc.add_page_break()
doc.add_heading("Part III. 修改说明（相对于当前260905工作稿）", level=1)
mod_rows = [
    ("Relative power定义", "1–30 Hz", "改为同一ROI内1–45 Hz总Welch功率", "代码级证据已确认；属于必须修改"),
    ("滤波表述", "50 Hz notch", "改为49–51 Hz band-stop filtering", "与EEGLAB history一致"),
    ("ICA", "完整声称成分识别并剔除", "保留runica extended Infomax分解；不报告缺乏记录的剔除数量/编号", "participant-level component-rejection log仍缺失"),
    ("四窗口地位", "从一开始equal-status / prespecified", "仅写最终管线平行分析，10 s为兼容性参考", "8月2日10 s曾为主方案；8月4日才确定最终平行报告"),
    ("144项", "primary multiplicity family", "改为144个被考察的核心Model 1系数", "0805源表无专属36/144项BH输出"),
    ("324项", "与144项混作同一结果集", "明确其为9个裸absolute-power结局的GEE子集，使用不同模型与校正范围", "不得用其q替代relative-power CR2结果"),
    ("Previous-scene样本", "42/461", "改为输入42/461；排除75个结构性首位置后实际建模42/386", "不是读取错误"),
    ("Previous-scene q", "只写q但不说明family", "同时标明within-variant 12项q与joint 48项q", "10 s与15 s均未通过联合校正"),
    ("Gray-screen recovery", "正式occipital-alpha recovery分析", "从Methods和Results删除推断性声称", "代码只生成描述性差值，无正式模型/输出"),
    ("Position与relative alpha", "三个ROI均有校正后正向证据", "收窄为仅parietal alpha relative power", "本机8月18日post hoc表支持；F/O不通过联合校正"),
    ("Theta temporal q", "0.00461–0.02239等不一致范围", "采用本机post hoc源表的0.00447–0.02239", "须同时标为8月18日事后复核，不冒充0805原始输出"),
    ("72的含义", "72 models与72 tests混用", "72个模型为18×4；每种尺度另有72项temporal检验", "两个72不是同一计数对象"),
    ("Low/high beta", "可能暗示进入18-outcome temporal audit", "注明仅由上游提取，未进入18个temporal结局", "18个结局为3 ROI×3 bands×2 scales"),
    ("756项比较", "756项正式检验或等效性证据", "改为756行描述性系数对比", "未纳入跨窗口协方差；不是等效性检验"),
    ("结果结构", "重复的“再发现/新旧图/待重画图”正文", "删除重复占位段，仅保留3.3.1–3.3.4", "避免工作痕迹进入投稿稿"),
]
add_table(doc, ["项目", "当前风险表述", "建议修改", "依据/状态"], mod_rows, [2.8, 3.7, 5.7, 4.2])

doc.add_heading("Part IV. 暂不确定或仍需作者决定的事项", level=1)
pending = [
    ("8月18日post hoc结果放置位置", "数值和脚本在本机可读，但学生原分析电脑未找到", "建议保留3.3.3并明确post hoc；若期刊强调预设分析，可移至Supplementary Results"),
    ("8月18日复核的可复现归档", "输出和脚本存在；原输入副本与运行环境尚未形成最终归档包", "投稿前固定4个common-QC输入、脚本、R/package版本、输出与SHA-256"),
    ("ICA成分剔除", "现有history支持ICA运行，但无pop_subcomp或人工判定表", "若学生能提供每名参与者的剔除记录，再补充剔除标准和数量；否则沿用保守Methods措辞"),
    ("0805精确历史工作区", "5174929是最接近归档版本，但无法证明与8月4日工作区逐字节一致", "Code Availability中不要写成exact run snapshot；最终重跑时记录新的固定commit"),
    ("历史EEG输入快照", "当前两份.set修改时间晚于原运行，56份历史输入哈希不完整", "不影响已保存0805结果的数值引用，但目前不能声称端到端完全复现"),
    ("软件版本", "EEGLAB、MATLAB、R及关键package精确版本未在现有正文中锁定", "有日志则补齐；无证据不要推测版本号"),
    ("144项系数层面的BH结论", "0805未保存专属36/144项BH输出", "当前正文只报告unadjusted CR2 p并声明不作校正后解释；若必须给q，需另行、透明地定义并执行post hoc校正"),
]
add_table(doc, ["事项", "当前状态", "正文/投稿处理建议"], pending, [3.8, 5.5, 7.1])

doc.add_heading("Part V. 来源与审计边界", level=1)
source_rows = [
    ("0805正式parallel结果", r"D:\投稿desk\2026sci\260419投稿材料\260722\数据分析结果包-0805（对齐眼动eeg）", "原始EEG结果主来源"),
    ("学生0906总报告", r"D:\投稿desk\2026sci\260419投稿材料\260722\EEG再发现\0906\EEG核查总报告_0906.md", "代码、配置、样本与历史溯源"),
    ("学生新增技术核查", r"...\0906\01_专题说明\NEW_EEG_TECHNICAL_CHECKS_20260906.md", "分母、previous-scene及缺失temporal审计状态"),
    ("8月18日post hoc输出", r"D:\投稿desk\2026sci\260419投稿材料\260722\EEG再发现\reanalysis_out", "factor-level与18-outcome temporal结果；非0805原始输出"),
    ("8月18日post hoc脚本", r"C:\Users\PCI\Documents\论文分析\work\eeg_audit\reanalyse_factor_tests.R；summarize_temporal.py", "本机保存的生成与汇总脚本"),
]
add_table(doc, ["来源", "位置", "用途"], source_rows, [3.4, 9.2, 3.8])

add_body(doc, "统计与写作审计：本稿区分了unadjusted CR2 p与BH-adjusted q，区分了within-variant与joint correction，未把描述性窗口对比写成正式显著性或等效性检验，未把temporal adjustment variable解释为疲劳、适应、学习或恢复，也未恢复previous-scene WWR = 30或gray-screen recovery等无充分来源的表述。", italic=True, first_line=False, space_after=0)

# Header/footer and page numbering.
for sec in doc.sections:
    header = sec.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    rr = header.add_run("EEG Methods & Results 3.3 revision | 2026-09-07")
    rr.font.name = "Arial"
    rr.font.size = Pt(8)
    rr.font.color.rgb = RGBColor.from_string("777777")

    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run("Page ")
    run.font.size = Pt(8)
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr_text)
    run._r.append(fld_char2)

doc.core_properties.title = "EEG Methods与Results 3.3修订稿（中英文）"
doc.core_properties.subject = "Integrated revision based on the 0906 EEG audit responses"
doc.core_properties.author = "Codex"
doc.core_properties.keywords = "EEG, Methods, Results 3.3, CR2, BH-FDR, onset-trim"

doc.save(OUT)
print(OUT)
