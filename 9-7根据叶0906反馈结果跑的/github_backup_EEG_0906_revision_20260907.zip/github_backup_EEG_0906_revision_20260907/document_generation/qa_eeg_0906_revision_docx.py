from pathlib import Path
import hashlib
import re
import zipfile

from docx import Document


p = Path(r"C:\Users\PCI\Documents\论文分析\EEG_Methods与Results3.3_整合0906回应_中英文_20260907.docx")
d = Document(p)
text = "\n".join(x.text for x in d.paragraphs)
text += "\n" + "\n".join(
    cell.text for table in d.tables for row in table.rows for cell in row.cells
)
with zipfile.ZipFile(p) as archive:
    xml = archive.read("word/document.xml").decode("utf-8")

required = [
    "1–45 Hz",
    "42 participants and 386 complete trials",
    "β = 0.00757",
    "joint BH-adjusted q = 0.00447–0.02239",
    "within-variant BH-adjusted q = 0.5322",
    "事后补充复核",
]

print("required_missing", [item for item in required if item not in text])
print("page_breaks", len(re.findall(r'<w:br[^>]*w:type="page"', xml)))
print("tables", [(len(t.rows), len(t.columns)) for t in d.tables])
print("empty_paragraphs", sum(not para.text.strip() for para in d.paragraphs))
print("sha256", hashlib.sha256(p.read_bytes()).hexdigest())
