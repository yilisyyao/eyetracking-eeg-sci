from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


OUT = Path(r"C:\Users\PCI\Documents\论文分析\EEG_修改说明与0906两份疑问文件逐题回应_20260907.docx")


def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def margins(cell):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = OxmlElement("w:tcMar")
    for name, value in (("top", 90), ("start", 100), ("bottom", 90), ("end", 100)):
        node = OxmlElement(f"w:{name}")
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")
        tc_mar.append(node)
    tc_pr.append(tc_mar)


def repeat_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    tr_pr.append(el)


def body(doc, text, *, no_indent=False, italic=False):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_after = Pt(5)
    if not no_indent:
        p.paragraph_format.first_line_indent = Cm(0.74)
    r = p.add_run(text)
    r.italic = italic
    return p


def bullet(doc, text, level=0):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.line_spacing = 1.08
    p.add_run(text)
    return p


def table(doc, headers, rows, widths):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    repeat_header(t.rows[0])
    for i, text in enumerate(headers):
        c = t.rows[0].cells[i]
        shade(c, "D9EAF7")
        margins(c)
        c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(text)
        r.bold = True
    for row_data in rows:
        row = t.add_row()
        for i, value in enumerate(row_data):
            c = row.cells[i]
            margins(c)
            c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
            p = c.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            p.add_run(str(value))
    for row in t.rows:
        for i, width in enumerate(widths):
            row.cells[i].width = Cm(width)
    doc.add_paragraph()
    return t


doc = Document()
sec = doc.sections[0]
sec.top_margin = Cm(2.1)
sec.bottom_margin = Cm(2.0)
sec.left_margin = Cm(2.3)
sec.right_margin = Cm(2.3)

normal = doc.styles["Normal"]
normal.font.name = "Times New Roman"
normal.font.size = Pt(10.5)
normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

for name, size, color in [
    ("Title", 19, "1F4E79"),
    ("Heading 1", 15, "1F4E79"),
    ("Heading 2", 12.5, "2F5597"),
    ("Heading 3", 11.5, "365F91"),
]:
    s = doc.styles[name]
    s.font.name = "Arial"
    s.font.size = Pt(size)
    s.font.color.rgb = RGBColor.from_string(color)
    s._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")

p = doc.add_paragraph(style="Title")
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run("EEG修改说明与0906两份疑问文件逐题回应")
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_after = Pt(12)
r = p.add_run("对应2026-09-07版Methods与Results 3.3中英文替换稿")
r.italic = True
r.font.color.rgb = RGBColor.from_string("666666")

doc.add_heading("一、总体回应", level=1)
body(doc, "学生提交的《EEG核查总报告_0906.md》和《Codex_EEG_新增技术疑点核对_20260906.md》有效解决了大部分原始管线、样本和方法定义问题。其最重要的贡献是确认：0805为正式parallel结果来源；四种onset-trim variant是在最终管线中平行报告，但并非从一开始就具有前瞻性预设的同等地位；144项不能称为已证实的primary multiplicity family；previous-scene实际建模样本为42人/386试次；relative power分母为1–45 Hz；756行为描述性窗口系数对比。")
body(doc, "两份报告对18-outcome temporal audit所作的“NOT FOUND/UNRESOLVED”判断，仅表示学生原分析电脑和0906检索范围内没有找到相应脚本与输出，并不证明该分析不存在。本机仍保存2026年8月18日生成的reanalysis_out及其R/Python脚本。经直接核对，这些文件可以回答新增技术疑点中的Q2、Q3、Q5和Q6，但其身份必须限定为8月18日事后补充复核，不能回写成0805原始分析或预设主分析。")
body(doc, "因此，修订稿采用“双层证据结构”：0805原始输出负责样本、核心系数、previous-scene和窗口敏感性结果；8月18日本机输出负责factor-level和temporal新发现，并明确标注post hoc complementary reanalysis。")

doc.add_heading("二、Methods修改说明", level=1)
method_rows = [
    ("频谱定义", "relative power分母由1–30 Hz改为1–45 Hz。theta、alpha和beta均使用同一ROI内1–45 Hz总Welch功率作为分母。", "0906代码审计已确认；原Methods属于METHODS DEFINITION MISMATCH。"),
    ("滤波", "将笼统的50 Hz notch改为0.5–40 Hz band-pass及49–51 Hz band-stop。", "与现有EEGLAB history一致。"),
    ("重参考与ICA", "保留average re-referencing及runica extended Infomax ICA；删除或收窄无法由记录支持的具体成分剔除数量、编号和判定标准。", "history中未找到pop_subcomp或参与者层面的剔除表。"),
    ("频域提取", "补充marker 7→8分段、ROI内平均、Welch 2-s窗口、50%重叠、FFT取下一2的幂和梯形积分。", "来自实际MATLAB导出实现。"),
    ("四窗口表述", "改为：0、5、10和15 s在最终管线中平行分析，10 s保留为兼容性参考。", "不得再写prospectively prespecified equal-status variants。"),
    ("Gray-screen", "删除正式gray-screen occipital-alpha recovery推断分析。", "代码只生成描述性配对行/差值，没有相应推断模型和统计输出。"),
    ("核心模型", "明确LMM、participant随机截距、CR2聚类稳健推断及Satterthwaite自由度；统一使用viewing round与within-round presentation position。", "符合0805 R模型和术语锁定。"),
    ("144项", "改称四个核心结局跨四种variant考察的144个Model 1系数，不称primary multiplicity family。", "0805表只有unadjusted CR2 p，未保存专属36/144项BH输出。"),
    ("事后复核", "新增post hoc factor-level与temporal分析方法，并写清96、216和每种尺度72项BH family。", "来源为8月18日本机脚本和reanalysis_out；不得称为0805预设分析。"),
    ("Previous-scene", "说明461个输入试次中75个首位置试次的previous scene结构性未定义；实际模型为42人/386试次。", "并明确每窗口12项及跨窗口48项BH。"),
    ("756行比较", "改称描述性系数对比；明确未纳入跨窗口协方差，不是配对检验或等效性检验。", "避免从CI包含0推导统计等效。"),
    ("18个结局", "限定为3个ROI×theta/alpha/beta×relative/log10 absolute两种尺度；low/high beta不在其中。", "本机temporal输出已锁定18个变量名。"),
]
table(doc, ["修改点", "正文如何修改", "原因/证据"], method_rows, [3.2, 8.2, 5.0])

doc.add_heading("三、Results 3.3修改说明", level=1)
result_rows = [
    ("3.3开头", "增加证据层级说明", "区分0805原始结果与8月18日post hoc结果。"),
    ("3.3.1", "保留四窗口样本流；common-QC为42人/461试次", "四窗口只描述为最终平行管线，10 s为兼容性参考。"),
    ("3.3.2", "保留frontal theta的三个unadjusted CR2 p < 0.05系数", "0 s β=0.00757；5 s β=0.00856；10 s β=0.00750；15 s不显著。因无原始144项BH表，不声称通过校正。"),
    ("3.3.3 factor-level", "新增visual complexity与occipital theta relative power的稳定关系", "四种variant均通过96项核心family的跨variant BH：β=0.00436–0.00503，q=0.00205–0.00443；明确为post hoc。"),
    ("3.3.3 temporal", "新增viewing round相关alpha上升、theta下降模式", "三个ROI×四种variant均通过各自72项relative temporal family的联合校正。"),
    ("Position→relative alpha", "由“三个ROI”收窄为“仅parietal ROI”", "P_alpha_relative四种variant的joint q=0.02239–0.04391；F/O未通过联合CR2 BH-FDR。"),
    ("Absolute alpha", "保留viewing round和within-round presentation position的正向关系", "三个ROI×四种variant均通过72项log10 absolute temporal family的联合校正。"),
    ("机制解释", "删除fatigue、adaptation、learning、recovery等解释", "temporal adjustment variable只能报告统计方向。"),
    ("3.3.4 WWR", "parietal beta的WWR factor仅15 s通过", "joint q=0.0282；其他variant q=0.117–0.137，作为hypothesis-generating。"),
    ("3.3.4 Previous-scene", "更正样本并同时报告within/joint q", "10 s qwithin=0.5322、qjoint=0.8072；15 s qwithin=0.1183、qjoint=0.4734；无校正证据。"),
    ("3.3.4 Window contrasts", "756行全部区间含0，但不宣称等效", "仅能说未确定优选onset-trim variant。"),
    ("工作稿痕迹", "删除重复“再发现”、新旧图和待重画占位段", "避免内部审稿痕迹进入投稿正文。"),
]
table(doc, ["位置", "修改内容", "最终统计定位"], result_rows, [3.0, 7.4, 6.0])

doc.add_page_break()
doc.add_heading("四、对《EEG核查总报告_0906.md》的逐项回应", level=1)
audit_rows = [
    ("问题1 实际代码版本", "接受PARTIALLY CONFIRMED", "5174929是目前最接近的归档版本，但不能声称与8月4日运行工作区逐字节相同。该问题影响Code Availability和复现归档，不改变已保存结果数值。"),
    ("问题2 实际运行配置", "接受CONFIRMED", "teacher_analysis.parallel.json支持四种variant、10 s兼容参考、核心/次要/补充指标、1–45 Hz元数据和不同随机种子。"),
    ("问题3 四窗口何时确定", "接受CONFIRMED", "四种长度8月2日已列出，但10 s当时为主分析；8月4日才形成最终同等平行报告。正文采用final parallel pipeline措辞，不采用prospectively equal-status。"),
    ("问题4 144与324", "接受PARTIALLY CONFIRMED", "144是核心relative-power LMM/CR2系数计数；已定位的324是bare absolute-power Gaussian GEE子集。模型、尺度与校正family不同，不可互换q。"),
    ("问题5 脚本—输出映射", "接受并补充", "原始previous-scene与756行窗口对比映射成立。学生电脑未找到18-outcome temporal输出；本机另找到8月18日脚本和输出，故将其归类为post hoc，而非0805原始结果。"),
    ("问题6 Previous-scene样本", "接受CONFIRMED", "461个输入试次中75个为每个viewing round首位置，previous scene结构性未定义；显式过滤后为42人/386试次，不是读取错误。"),
    ("问题7 Relative power分母", "接受CONFIRMED", "实际算法使用1–45 Hz。即使上游为0.5–40 Hz滤波，也不能将已运行算法的积分上限静默改写为40 Hz。"),
    ("问题8 0803与0805关系", "接受CONFIRMED", "0805为正式parallel结果入口；0803保留为历史/兼容来源。不能按同名文件或日期机械混选。"),
    ("问题9 EEG输入边界", "接受PARTIALLY CONFIRMED", "可确认当前.set history和下游功率导出路径，但历史输入哈希不完整、两份.set后来更新。该限制不推翻0805已保存结果，但阻止声称端到端完全复现。"),
]
table(doc, ["审计问题", "回应", "在论文中的处理"], audit_rows, [3.4, 3.2, 9.8])

doc.add_heading("五、对《Codex_EEG_新增技术疑点核对_20260906.md》的逐项回应", level=1)
tech_rows = [
    ("Q1 Relative-power分母", "已解决", "1–45 Hz；三个频带使用同一ROI内总Welch功率分母。Methods必须由1–30 Hz改为1–45 Hz。"),
    ("Q2 Position→relative alpha", "已由本机post hoc输出解决", "不是三个ROI均成立。仅P_alpha_relative在0/5/10/15 s均通过joint BH：β=0.00349–0.00428，q=0.02239–0.04391；F/O不通过。"),
    ("Q3 Viewing round→theta q范围", "已由本机post hoc输出解决", "采用broader_temporal_72的p_BH_parallel：q=0.0044660–0.0223872，正文四舍五入为0.00447–0.02239。该值属于8月18日post hoc输出，不属于0805原始CR2表。"),
    ("Q4 Previous-scene q", "已解决", "10 s：β=0.00308956，p=0.04435，qwithin=0.53219，qjoint=0.80719；15 s：β=0.00425375，p=0.009862，qwithin=0.11835，qjoint=0.47338。均无校正后证据。"),
    ("Q5 72 models与72-test family", "已由本机post hoc输出解决", "72 models=18 outcomes×4 variants；relative scale有72项temporal tests，log10 absolute scale另有72项。两个72含义不同。72个模型均converged且none singular。"),
    ("Q6 9个EEG outcomes", "已由本机post hoc输出解决", "relative outcomes为F/P/O×theta/alpha/beta共9个；对应9个log10 absolute outcomes，共18个。low beta和high beta未进入该temporal audit。"),
]
table(doc, ["技术问题", "当前状态", "最终回应"], tech_rows, [3.5, 4.0, 8.9])

doc.add_heading("六、为什么学生报告写“未找到”，本稿仍可报告temporal结果", level=1)
body(doc, "两者的检索范围不同。学生报告核查的是原分析电脑、0803/0805交付包和指定Git历史，因此正确地把最终18-outcome temporal audit标为NOT FOUND/UNRESOLVED。本机目录D:\\投稿desk\\2026sci\\260419投稿材料\\260722\\EEG再发现\\reanalysis_out中仍保存temporal_CR2_tests.csv、factor_level_CR2_tests.csv和model_diagnostics.csv；生成脚本保存在C:\\Users\\PCI\\Documents\\论文分析\\work\\eeg_audit\\reanalyse_factor_tests.R及summarize_temporal.py。")
body(doc, "这些本机文件可以支持数值层面的复核，但不能反向证明该分析属于8月4日正式管线。因此，最合规的处理是：可以报告，但必须标为2026年8月18日post hoc complementary reanalysis；在投稿前把四个输入文件、脚本、运行环境、输出及哈希统一归档。若作者不希望把post hoc发现放在主Results，可将3.3.3移至Supplementary Results，同时在主文只保留一句概述。")

doc.add_heading("七、仍未完全解决的事项", level=1)
for item in [
    "尚不能证明Git commit 5174929与8月4日实际工作区逐字节一致。",
    "尚缺参与者层面的ICA成分剔除记录；目前只能确认ICA分解和人工处理流程。",
    "尚缺覆盖8月2日全部56份.set/.fdt输入状态的历史哈希快照。",
    "8月18日post hoc复核需建立最终可复现归档包；在完成前，应始终保留post hoc标签。",
    "EEGLAB、MATLAB、R及关键package的精确版本如无日志证据，不应自行填写。",
    "如果期刊要求144个核心系数的正式联合q，需要重新定义并透明执行post hoc BH校正；不能伪称0805已保存该校正。",
]:
    bullet(doc, item)

doc.add_heading("八、最终建议", level=1)
body(doc, "当前最稳妥的投稿结构是：3.3.2报告0805核心系数并明确其为未校正结果；3.3.3单列post hoc factor-level与temporal新发现；3.3.4报告previous-scene、单窗口parietal beta和描述性窗口敏感性。这样既保留目前最有价值的EEG发现，也不掩盖分析时间线和多重比较边界。", no_indent=True)

for section in doc.sections:
    hp = section.header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    rr = hp.add_run("EEG revision response | 2026-09-07")
    rr.font.size = Pt(8)
    rr.font.color.rgb = RGBColor.from_string("777777")
    fp = section.footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run("Page ")
    run.font.size = Pt(8)
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instr, end])

doc.core_properties.title = "EEG修改说明与0906两份疑问文件逐题回应"
doc.core_properties.author = "Codex"
doc.core_properties.subject = "Methods and Results 3.3 revision audit response"
doc.save(OUT)
print(OUT)
