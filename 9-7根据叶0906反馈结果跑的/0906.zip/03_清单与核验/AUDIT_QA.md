# AUDIT_QA

检查时间UTC：2026-09-06T17:45:02.291488+00:00

本轮15项交付完整性/来源校验，通过15项。这些检查不代表原分析端到端复现。

| 检查 | 状态 | 说明 |
| --- | --- | --- |
| Two request documents: all 10 requested output files exist | PASS |  |
| Original critical source hashes unchanged during audit | PASS | [] |
| Evidence copies byte-identical to sources | PASS | [] |
| Repository status unchanged and clean | PASS |  |
| 5174929 code ZIP CRC integrity | PASS |  |
| Code ZIP contains complete tracked tree at 5174929 | PASS | ZIP=192, Git=192 |
| Temporal extraction has 32 original core coefficients, not a fabricated 144-row audit | PASS |  |
| Unavailable CR2 CI and temporal q remain blank | PASS |  |
| Every temporal beta/CR2 SE/raw p copied exactly from recorded source | PASS |  |
| 144 core rows have correct 4 x 9 x 4 structure and no newly computed q | PASS |  |
| 324 GEE extraction keeps actual model and scale boundary | PASS |  |
| All 48 previous-scene rows preserve original values and both q columns | PASS |  |
| Original R read semantics and Python sample audit agree on 42/461 and 42/386 | PASS |  |
| Model-table catalog has no read errors | PASS | 857 model tables; 6493 files inventoried |
| No .set/.fdt waveform source copies in delivery | PASS |  |

## 仍未确认的研究事实

- 144项统一primary BH family及其36/144专属校正输出。
- 核查问题所述18-outcome/72-model最终temporal分析：当前保存产物结构不支持这一已运行描述。
- 两组theta最终q范围及F/P/O relative-alpha跨四窗口最终校正结论。
- 完整运行瞬间代码快照及全部EEG历史输入文件哈希。

未用新计算填补以上缺口；报告已明确状态。

关键来源清单：512项，包含112个未复制的现存.set/.fdt以及2个原始交付ZIP。历史文件的mtime与本次SHA不被当作预注册证据。

## 目录与报告归并核验

- 顶层仅1份MD总报告：PASS。
- 原9项问题、增补Q1–Q6及两项关键专题附录已合并：PASS。
- 416个原证据、数据摘录及非编辑文件哈希与整理前一致：PASS。
- 总报告64处本地链接均可定位：PASS。
- 原分析数据和仓库未变动；本次只调整0906交付目录。

整理前清单保留为“整理前文件清单.csv”；新清单为本目录DELIVERABLE_MANIFEST.csv。审计脚本是执行时版本归档，保留整理前路径约定。


## 交付可移植性更新

- 主报告及专题说明已移除本机绝对路径，证据链接改为包内相对链接。
- 已验证135个文档链接；5553个数字字段保持原字符串精度。
- 494份原始证据文件SHA-256保持不变；本次未重新运行统计模型。
- 修正18结局/72模型的措辞：尚未对应具体输出，不据此判断相关表述有误。
- 数据表和来源清单中的证据路径以交付包根目录为基准；仅有来源标识的条目不表示已附完整原文件。


## 审阅措辞统一

交付副本说明：本包已统一审阅称呼，部分历史记录及代码副本仅作文字替换。原件和修改前副本保留在交付目录外；历史逐字节比较与原件哈希仅适用于修改前材料，当前文件哈希以交付清单为准。统计数据未重新计算。
