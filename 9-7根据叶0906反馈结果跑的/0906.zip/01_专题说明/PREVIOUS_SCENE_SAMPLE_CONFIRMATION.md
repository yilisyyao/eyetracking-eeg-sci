# PREVIOUS_SCENE_SAMPLE_CONFIRMATION

**CONFIRMED：四窗口共同QC输入均为42人/461试次；75条PreviousWWR空记录全部是每轮第一个场景（轮1为37条、轮2为38条）；按原代码PositionWithinBlock > 1筛选后，四窗口均为42人/386个完整案例。**

| 窗口/s | 共同QC参与者/试次 | 前序未定义 | 轮1 / 轮2首场景 | 排除后完整案例 |
| --- | --- | --- | --- | --- |
| 0 | 42 / 461 | 75 | 37 / 38 | 42 / 386 |
| 5 | 42 / 461 | 75 | 37 / 38 | 42 / 386 |
| 10 | 42 / 461 | 75 | 37 / 38 | 42 / 386 |
| 15 | 42 / 461 | 75 | 37 / 38 | 42 / 386 |

这是前序场景在每轮首位置上结构性未定义及其排除后的完整案例建模，不是75条试次读取失败。四窗口Participant×GlobalTrialOrder集合完全相同，保留行的前序模型所需预测量与4个核心结局完整。

但要精确说明读取语义：CSV的字符空值在R `read.csv` 中保留为空字符串；当前Complexity的C0参考类别也被存成空字符串。Python默认读取会把这些字符空值视为NaN，直接dropna会误报大量缺失。已用原R读取方式独立复核，见 `../evidence/R_READ_SAMPLE_CONFIRMATION.csv`。75条first-position记录是由显式位置过滤排除；不能描述为R自动 `na.omit(PreviousWWR)` 删除75条。

当前与前序复杂度的空字符串编码属于复现说明应补充的细节；不应把所有PreviousComplexity空值都当成首场景缺失。当前导出的模型表未逐模型保存nobs，386是由实际输入和原筛选/complete-case逻辑确认的可用模型样本，而非本次读取重新拟合的模型对象。

## O_theta_relative × PreviousWWR75

| 窗口/s | β | raw CR2 p | within-window q（12项） | joint q（48项） |
| --- | --- | --- | --- | --- |
| 0.0 | 0.0011252291688327 | 0.401937048770663 | 0.926017658926172 | 0.8936963689298898 |
| 5.0 | 0.0013565153235864 | 0.347641711383351 | 0.933688611422054 | 0.8936963689298898 |
| 10.0 | 0.0030895568935248 | 0.0443488001313611 | 0.5321856015763332 | 0.8071868110799679 |
| 15.0 | 0.0042537453873621 | 0.0098621366093805 | 0.118345639312566 | 0.473382557250264 |

10秒0.53219、15秒0.11835确为窗口内q；对应联合q分别约0.80719和0.47338。48项=4个核心结局×3个前序系数（WWR45、WWR75、复杂度）×4窗口。所有这些目标行均未达到joint q<0.05。**正文若只写q，必须注明within-variant或joint q。**

## 证据

- **E0136** [eeg_onset_order_model_input.csv](../evidence/run_parallel/06_eeg_primary/onset_window_models/trim_10s/eeg_onset_order_model_input.csv)；定位：Participant、PositionWithinBlock、PreviousWWR、Block；另三个窗口见清单。
- **E0488** [contracts.py](../evidence/code_HEAD/src/paper_analysis/teacher/contracts.py)；定位：221–260：同Participant/Block内shift；首场景置空。
- **E0005** [eeg_order_analysis.R](../evidence/code_HEAD/analysis/r/eeg_order_analysis.R)；定位：10–17、33–48：原读取、因子与PositionWithinBlock > 1。
- **E0011** [complete.py](../evidence/code_HEAD/src/paper_analysis/teacher/complete.py)；定位：419–459：_parallel_order_carryover_audit；703–706写出联合表。
- **E0042** [Reviewer1_parallel_previous_scene_FDR.csv](../evidence/run_parallel/07_reviewer_analysis/Reviewer1_parallel_previous_scene_FDR.csv)；定位：48行；p_fdr_bh_window与p_fdr_bh_parallel。
