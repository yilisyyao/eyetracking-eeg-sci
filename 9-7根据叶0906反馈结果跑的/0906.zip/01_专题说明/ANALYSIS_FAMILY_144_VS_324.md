# ANALYSIS_FAMILY_144_VS_324

**结论：四个core outcomes的配置早已存在；但未找到“144项在8月4日被明确规定为统一primary multiplicity family”以及36/144项BH结果的证据。也不能断言它后来必然从核查问题所指324项审计中提取，因为该审计原表/脚本尚未找到。**

## 已查明的三个不同层次

| 层次 | 实际来源与模型 | 计数 | 已保存的校正规则 |
| --- | --- | --- | --- |
| 核心相对功率四窗口 | onset_window_models/trim_*s/eeg_cr2_robust_results.csv；R lmer Model1 + CR2 | 4 outcomes × 9条件/经验相关系数 × 4窗口 = 144 | 源表无BH列；本次仅提取已有β/SE/df/raw p，不生成新q |
| 10秒兼容主分析 | 06_eeg_primary/12_eeg_cr2_results.csv；R核心relative模型；场景QC474试次 | 并非共同QC461试次下的四窗口144项 | eeg_primary_analysis.R按频带×term分组；secondary/supplemental另加家族标签 |
| 本地可定位的324行GEE子集 | 00_eeg_onset_statistics/onset_variant_model_results.csv中parallel_common_qc | 9个裸绝对功率变量 × 9条件/经验项 × 4窗口 = 324 | 源表按全部非截距项校正：每窗口117项、跨窗口468项；不是324项重新BH |

9个核心条件/经验相关项（注意包含ExperienceGroup主效应，不能仅凭名称把它们都当成实验条件主效应）：

- `ComplexityC1`
- `ComplexityC1:ExperienceGroupLow`
- `ExperienceGroupLow`
- `WWRWWR45`
- `WWRWWR45:ComplexityC1`
- `WWRWWR45:ExperienceGroupLow`
- `WWRWWR75`
- `WWRWWR75:ComplexityC1`
- `WWRWWR75:ExperienceGroupLow`

## 逐题回答问题4

1. **UNRESOLVED（primary-family地位未证实）**。配置中 `core_metrics` 的存在支持“核心指标事先已指定”，不支持“跨四窗口144项作为一个统一BH family事先已指定”。
2. **UNRESOLVED（后续提取历史未证实）**。这次可以直接从四个R/CR2源表提取144条已有系数，不必先有324条表。未找到核查问题中提及的后来审计的生成脚本，不能补写提取时间。
3. **NOT FOUND**。没有找到对上述R/CR2 144项执行联合BH的原脚本。`eeg_order_analysis.R`只写CR2 raw p；`eeg_primary_analysis.R`的BH是另一分组口径；`complete.py`的联合BH处理的是PreviousScene的48项。
4. **NOT FOUND**。每窗口36项及跨窗口144项的专属BH文件未找到。[CORE_144_EXISTING_CR2_COEFFICIENTS.csv](../02_数据表/CORE_144_EXISTING_CR2_COEFFICIENTS.csv)是本次只读整理出的已有系数，不能称为历史BH输出。
5. **PARTIALLY CONFIRMED**。9×9×4=324可在上述GEE输出中精确提取，已保存为 [BROADER_324_EXISTING_GEE_COEFFICIENTS.csv](../02_数据表/BROADER_324_EXISTING_GEE_COEFFICIENTS.csv)。但是该管线把 `F_theta` 等裸字段映射到 `eeg_F_theta`，裸字段与 `*_absolute` 数值逐列相同，**不是9个relative outcomes的Model1 CR2审计**。核查问题所指324是否是另一个后续产物仍未确认。
6. **不能说相同**。本地GEE子集继承117/468项校正；144项专属校正无证据；10秒兼容R主分析又采用频带×term校正。这些来源、量纲、模型及family不能混用。

## 对3.3措辞的影响

可写：

> For the four core EEG outcomes, 144 Model 1 condition-related coefficients were examined across the four onset-trim variants.

暂不能写：`The primary multiplicity family comprised 144 coefficients.`

不能把本次“144行提取表”或“324行提取表”称为当时保存的独立family，也不能拿GEE子集的q填进R/CR2结果。若正文要报告144项联合q，需要提供当时已经生成的校正脚本/表；本次不重新计算以替代历史证据。

## 证据

- **E0021** [teacher_analysis.parallel.json](../evidence/run_parallel/teacher_analysis.parallel.json)；定位：eeg.core_metrics / secondary_metrics / supplemental_metrics / primary_measure。
- **E0005** [eeg_order_analysis.R](../evidence/code_HEAD/analysis/r/eeg_order_analysis.R)；定位：23–48、111–112：Model1及CR2输出，无BH。
- **E0006** [eeg_primary_analysis.R](../evidence/code_HEAD/analysis/r/eeg_primary_analysis.R)；定位：132–170：band×term correction_family；267：独立bootstrap种子。
- **E0007** [common.R](../evidence/code_HEAD/analysis/r/common.R)；定位：49–66：CR2；90–95：bh_within_family。
- **E0009** [onset_sensitivity.py](../evidence/code_HEAD/src/paper_analysis/stats/onset_sensitivity.py)；定位：186–200：校正分组；436–441：裸字段映射。
- **E0012** [run_eeg_bandpower_pipeline.m](../evidence/code_HEAD/matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m)；定位：331–340：裸字段为absolute，relative另存。
- **E0025** [onset_variant_model_results.csv](../evidence/run_parallel/00_eeg_onset_statistics/onset_variant_model_results.csv)；定位：sample_strategy=parallel_common_qc；model_type=gee_gaussian_participant_clustered_robust。
- **E0514** [ANALYSIS_DECISIONS.md](../evidence/code_HEAD/docs/ANALYSIS_DECISIONS.md)；定位：23–25、40–42、57–60：正式R与兼容GEE、核心指标分层。
