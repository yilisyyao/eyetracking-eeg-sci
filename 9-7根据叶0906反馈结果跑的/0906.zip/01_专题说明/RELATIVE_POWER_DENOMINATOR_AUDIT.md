# RELATIVE_POWER_DENOMINATOR_AUDIT

**CONFIRMED（算法定义及可追溯导出链）；历史运行瞬间的整个工作区仍为PARTIALLY CONFIRMED。实际分母为1–45 Hz，theta/alpha/beta各ROI均使用同一频率范围的总功率，分别在各自ROI信号上计算。**

| 项目 | 结论 | 精确定位 | 可信度 |
| --- | --- | --- | --- |
| 分母范围 | 1–45 Hz | MATLAB default_bands：totalBand40=[1 45]；名称中的40不代表实际上限40 | 高：ce80f1f、5174929及当前文件定义一致 |
| 相对功率计算 | bandpower / total_1_45 | append_bandpower_columns第328、338–340行 | 高 |
| PSD与积分 | pwelch；在f>=band(1)且f<=band(2)的离散频率点trapz积分 | bandpower_welch第401–417行 | 高 |
| 1–30 Hz定义 | 存在totalBand30=[1 30]，不用于上述relative字段 | default_bands；与实际totalBand40调用区分 | 高 |
| teacher配置分母字段是否控制计算 | 没有发现relative_power_denominator_hz传入计算函数的路径；它是预处理说明字段 | MATLAB apply_config读取bands，未读取这个teacher嵌套描述字段 | 高 |
| 可修改实际分母的参数 | MATLAB opts.Bands.totalBand40；ConfigPath中的bands可覆盖 | addParameter Bands、apply_config merge_struct | 高 |
| 0805输入来源 | 重用teacher_onset_20260802的eeg_trial_long及四窗口长表 | 实际teacher_analysis.parallel.json eeg.trial_file与onset_sensitivity_trial_file | 高；已记录输入哈希全部匹配 |
| 上游0.5–40 Hz与积分1–45 Hz是否并存 | 是。当前56份.set history均记录0.5–40 Hz滤波，而频谱代码积分范围至45 Hz | current_set_history.json；MATLAB代码 | 高（当前文件）；2份.set后来修改，不能当作8月2日原件 |
| 是否能证明40–45 Hz完全无功率 | 不能据滤波上限推断为精确零；本次未计算频谱 | 仅确认定义和处理链 | 不作数值推断 |

**METHODS DEFINITION MISMATCH（针对核查文件所引Methods“1–30 Hz”措辞）**：这与已查明算法不一致，应在定稿时以1–45 Hz描述原结果。尚未收到本轮完整Methods稿，不能声称已逐行核对当前全文。

实际运行配置的 `relative_power_denominator_hz` 写为1–45，但仅改这段文字不会改变MATLAB算法；可重复性说明应同时给出真实计算函数和bands参数，而不能只引用配置注释。

当前56份.set history均有band-pass、49–51 Hz band-stop、average re-reference与runica。未发现pop_subcomp记录；本次不推测ICA成分剔除标准。两份.set的mtime晚于8月4日，既有8月18日审计也记录了更新；当前文件哈希是本次快照，不是8月2日原始输入哈希。

## 证据

- **E0012** [run_eeg_bandpower_pipeline.m](../evidence/code_HEAD/matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m)；定位：4–7、29、76、309–340、401–417、539–570。
- **E0003** [run_eeg_from_raw.py](../evidence/code_HEAD/scripts/run_eeg_from_raw.py)；定位：53–62、102–130：ConfigPath与MATLAB调用。
- **E0021** [teacher_analysis.parallel.json](../evidence/run_parallel/teacher_analysis.parallel.json)；定位：eeg.preprocessing_parameters.relative_power_denominator_hz；输入路径。
- **E0162** [eeg_onset_export_stdout_02.log](../evidence/run_onset/eeg_onset_export_stdout_02.log)；定位：56个数据集导出；validation_status: pass。
- **E0066** [input_hashes.json](../evidence/run_parallel/06_eeg_primary/input_hashes.json)；定位：主trial输入SHA256；本次读回匹配。

当前.set/.fdt文件标识、大小、mtime与SHA-256见 [CRITICAL_FILE_MANIFEST.csv](../03_清单与核验/CRITICAL_FILE_MANIFEST.csv)（112项，只记录不复制）；history摘录和逐文件检查见 `../evidence/current_set_history.json` 与 `CURRENT_SET_HISTORY_CHECKS.csv`。
