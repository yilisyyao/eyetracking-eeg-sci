# 实际运行配置与仓库示例对照

实际配置已找到并原样复制至 `../evidence/run_parallel/teacher_analysis.parallel.json`。没有使用示例生成替代配置。

| 实际字段 | 值 |
| --- | --- |
| eeg.onset_trim_strategy | "parallel" |
| eeg.reference_onset_trim_s | 10 |
| eeg.onset_trim_variants_s | [0, 5, 10, 15] |
| eeg.core_metrics | ["O_theta", "F_theta", "O_alpha", "O_beta"] |
| eeg.secondary_metrics | ["P_theta", "P_alpha", "F_alpha"] |
| eeg.supplemental_metrics | ["F_beta", "P_beta"] |
| eeg.bootstrap_iterations | 5000 |
| eeg.onset_random_seed | 20260802 |
| eeg.primary_measure | "relative_power" |
| eeg.trial_file（文件标识） | "teacher_onset_20260802/00_eeg_trial_qc/eeg_trial_long.csv" |
| eeg.onset_sensitivity_trial_file（文件标识） | "teacher_onset_20260802/00_eeg_trial_qc/eeg_onset_sensitivity_trial_long.csv" |
| eeg.onset_analysis_dir（目录标识） | "teacher_parallel_20260804/00_eeg_onset_statistics" |
| eeg.preprocessing_parameters.relative_power_denominator_hz | 1-45 |
| 顶层random_seed | 字段不存在；onset_random_seed=20260802 |
| R primary bootstrap实际种子 | set.seed(20260726)，analysis/r/eeg_primary_analysis.R:267 |
| run_id | teacher_parallel_20260804 |

与5174929的 `configs/eeg_analysis.json` 相比：parallel、reference=10、四窗口、5000次及onset种子20260802一致；该通用配置不含core/secondary/supplemental或实际输入路径。与5174929的teacher示例相比：核心/次要/补充指标、relative主度量、parallel窗口配置一致；实际文件还填写了本机输入/输出、已确认预处理标志及运行ID。ce80f1f的两个示例仍使用primary_onset_trim_s=10。

**不能把随机种子笼统写成全管线20260802**：R核心cluster bootstrap实际硬编码20260726；onset等价性流程使用20260802。两者作用于不同过程。

- **E0021** [teacher_analysis.parallel.json](../evidence/run_parallel/teacher_analysis.parallel.json)；定位：完整JSON。
- **E0006** [eeg_primary_analysis.R](../evidence/code_HEAD/analysis/r/eeg_primary_analysis.R)；定位：267：set.seed(20260726)。
