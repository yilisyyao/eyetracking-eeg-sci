# NEW_EEG_TECHNICAL_CHECKS_20260906

**已确认分母、previous-scene q口径与样本；最终18-outcome temporal audit缺失，Q2、Q3及Q5/Q6的最终运行事实无法完全确认。没有重新跑模型填补缺失。**

本次只读取代码、已有CSV/JSON/日志/ZIP、Git历史和EEGLAB `.set` 中的history/元数据，并计算文件哈希、已有表的行数及集合对应关系。未重新拟合模型，未重算p值、BH q值、置信区间或频谱，未修改原工程、0803/0805交付包或论文。R仅用于复核原 `read.csv` 的缺失值语义；MATLAB仅用于读取56份 `.set` 的history。所有新文件都写入本目录。

结论优先依据原始配置、机器结果及执行代码；旧报告和本地任务对话仅用于定位及决策时间溯源。本文所列时间统一明确标注UTC或北京时间。文件mtime及本次SHA-256不能单独证明历史时刻的文件内容。状态 `NOT FOUND/UNRESOLVED` 表示在列明范围内缺少证据，并不等于证明相关分析从未发生。

## Q1 Relative-power分母 — CONFIRMED / 历史工作区整体PARTIALLY CONFIRMED

实际1–45 Hz；theta/alpha/beta均以各ROI的该范围总Welch功率为分母。代码路径与精确行见 [RELATIVE_POWER_DENOMINATOR_AUDIT.md](RELATIVE_POWER_DENOMINATOR_AUDIT.md)。来源为实际MATLAB导出实现、8月2日成功日志、8月4日运行配置及输入哈希；样本边界为56份导出源、正式共同QC42人/461试次。此项为算法定义，不涉及BH family。

**METHODS DEFINITION MISMATCH**：核查文件所引1–30 Hz与算法不一致，定稿需修正；未拿当前全文反推代码。`relative_power_denominator_hz`只是teacher元数据说明，实际计算由 `opts.Bands.totalBand40` 控制。

## Q2 Position → relative alpha — UNRESOLVED

找到的0805四窗口R模型只覆盖核心4个relative outcomes，因此只有O_alpha_relative的position系数可直接摘录，F/P alpha不在这组四窗口原始R输出中。单独10秒secondary输出不是最终四窗口18-outcome temporal audit。

| Outcome | 窗口/s | β | CR2 SE | 95% CR2 CI | raw CR2 p | within q | joint q | 状态 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| F_alpha_relative | 0 | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | 最终temporal audit未找到 |
| F_alpha_relative | 5 | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | 最终temporal audit未找到 |
| F_alpha_relative | 10 | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | 最终temporal audit未找到 |
| F_alpha_relative | 15 | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | 最终temporal audit未找到 |
| P_alpha_relative | 0 | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | 最终temporal audit未找到 |
| P_alpha_relative | 5 | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | 最终temporal audit未找到 |
| P_alpha_relative | 10 | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | 最终temporal audit未找到 |
| P_alpha_relative | 15 | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | NOT FOUND | 最终temporal audit未找到 |
| O_alpha_relative | 0 | 0.00346250142754266 | 0.00200193593676201 | 未导出 | 0.0923152961453719 | NOT FOUND | NOT FOUND | 无法判断最终校正标准 |
| O_alpha_relative | 5 | 0.00380678594671566 | 0.00205847527349822 | 未导出 | 0.0726760187262308 | NOT FOUND | NOT FOUND | 无法判断最终校正标准 |
| O_alpha_relative | 10 | 0.00412271925657735 | 0.00215983883725354 | 未导出 | 0.0643236068599201 | NOT FOUND | NOT FOUND | 无法判断最终校正标准 |
| O_alpha_relative | 15 | 0.0041604556107707 | 0.00222908511202979 | 未导出 | 0.0701823527562613 | NOT FOUND | NOT FOUND | 无法判断最终校正标准 |

数值来源：`06_eeg_primary/onset_window_models/trim_*s/eeg_cr2_robust_results.csv`；脚本 `eeg_order_analysis.R:29–32,111–112`；样本42/461。CR2源表不含CI或temporal BH q，本次不重新计算，也不把普通mixed-model CI伪称CR2 CI。

A. 三个ROI均有校正后证据？**无法确认**。B. 四窗口是否都成立？**无法确认**。C. 最新那句话准确吗？**现有证据不足以支持，不能判定为已核验准确**。D. 应暂缓/收窄的是“within-round presentation position在F/P/O三个ROI的relative alpha均有校正后正向证据”这一扩展；不直接修改正文，不把未找到证据写成效应不存在。

## Q3 Viewing round → theta q范围 — UNRESOLVED

未找到两组范围 `0.00447–0.0224` 与 `0.00461–0.02239` 对应的temporal audit原表及生成脚本。不能判断它们是否同family、同共同QC样本、同temporal predictors，或是否分别为within/joint q。文件日期差一天并不能证明两者相同。

已能摘录的原始核心结果如下，仅作为定位材料，不能当作最终temporal audit：

| ROI | 窗口/s | β | raw CR2 p | final q | 来源 |
| --- | --- | --- | --- | --- | --- |
| O_theta_relative | 0 | -0.00453266258958565 | 0.0037901759747261 | UNRESOLVED | 原始0805核心CR2表 |
| F_theta_relative | 0 | -0.00577223921644177 | 0.00126816880715911 | UNRESOLVED | 原始0805核心CR2表 |
| O_theta_relative | 5 | -0.00478296024006086 | 0.00299297319924894 | UNRESOLVED | 原始0805核心CR2表 |
| F_theta_relative | 5 | -0.00616104947923164 | 0.000875826789942023 | UNRESOLVED | 原始0805核心CR2表 |
| O_theta_relative | 10 | -0.00541250704346294 | 0.00178777466852072 | UNRESOLVED | 原始0805核心CR2表 |
| F_theta_relative | 10 | -0.00669413919945041 | 0.000319994256425997 | UNRESOLVED | 原始0805核心CR2表 |
| O_theta_relative | 15 | -0.00548233613763037 | 0.0027682052089089 | UNRESOLVED | 原始0805核心CR2表 |
| F_theta_relative | 15 | -0.00642463184023535 | 0.0012308895561266 | UNRESOLVED | 原始0805核心CR2表 |

**Recommended final q range = UNRESOLVED — source audit and correction-family definition required.**

未把差异归为四舍五入：没有原始未舍入q支持这种判断；本次也没有重新BH以制造一组“唯一数值”。Confidence：对原始β/p摘录为高；对最终q范围无可确认依据。正文最终q范围暂不能锁定。

## Q4 Previous-scene within / joint q — CONFIRMED

| 窗口/s | β | raw CR2 p | within-window q（12项） | joint q（48项） |
| --- | --- | --- | --- | --- |
| 0.0 | 0.0011252291688327 | 0.401937048770663 | 0.926017658926172 | 0.8936963689298898 |
| 5.0 | 0.0013565153235864 | 0.347641711383351 | 0.933688611422054 | 0.8936963689298898 |
| 10.0 | 0.0030895568935248 | 0.0443488001313611 | 0.5321856015763332 | 0.8071868110799679 |
| 15.0 | 0.0042537453873621 | 0.0098621366093805 | 0.118345639312566 | 0.473382557250264 |

0.53219和0.11835是窗口内12项BH；对应联合48项q完整精度见表。48=4个核心relative outcomes×3个previous系数×4窗口。源表 `Reviewer1_parallel_previous_scene_FDR.csv`，生成模块 `teacher/complete.py:_parallel_order_carryover_audit`；四窗口均42人/386个完整案例，75条首位置试次为结构性前序未定义。样本及字符空值读取细节见 [PREVIOUS_SCENE_SAMPLE_CONFIRMATION.md](PREVIOUS_SCENE_SAMPLE_CONFIRMATION.md)。

Confidence：高。**正文若只写q，必须注明within-variant或joint q。**

## Q5 72 models与72-test family — PARTIALLY CONFIRMED（算式；运行事实未确认）

若核查问题所述新temporal audit确实为每个scale 9个outcomes、4窗口、每模型2个temporal coefficients，则结构如下。这是对问题中设计的算术拆解，不是声明本地已找到/重跑这些模型。

| Layer | Outcomes | Variants | Temporal predictors | Models | Tests in BH family |
| --- | --- | --- | --- | --- | --- |
| Relative power | 9 | 4 | 2 | 36 | 72 |
| Log10 absolute power | 9 | 4 | 2 | 36 | 72 |
| Combined total | 18 | 4 | 2 | 72 | 144项总计；分成两个72项family，非自动联合144项BH |

因此“72 models”是两个scale合计；“72-test family”是每个scale各一组，两者不是同一计数对象。**72个模型是否全部收敛、最终BH是否确实按两个72项family执行：NOT FOUND/UNRESOLVED**。当前未收到完整Results/Methods，不能确认全文是否混淆；报告应分开写清计数与校正单位。

## Q6 9个EEG outcomes — PARTIALLY CONFIRMED

下列9个relative字段可由实际配置的core/secondary/supplemental及原始模型输入锁定；但这不等于已经证明全部进入了最终18-outcome temporal audit。

| ROI×band | 实际配置/原始输入中的relative字段 | 对应log10 absolute名称的证据边界 |
| --- | --- | --- |
| F_theta | F_theta_relative | log10_F_theta_absolute（核心4指标R日志实际列出） |
| F_alpha | F_alpha_relative | log10_F_alpha_absolute（按目标结构期待；最终temporal变量清单未找到） |
| F_beta | F_beta_relative | log10_F_beta_absolute（按目标结构期待；最终temporal变量清单未找到） |
| P_theta | P_theta_relative | log10_P_theta_absolute（按目标结构期待；最终temporal变量清单未找到） |
| P_alpha | P_alpha_relative | log10_P_alpha_absolute（按目标结构期待；最终temporal变量清单未找到） |
| P_beta | P_beta_relative | log10_P_beta_absolute（按目标结构期待；最终temporal变量清单未找到） |
| O_theta | O_theta_relative | log10_O_theta_absolute（核心4指标R日志实际列出） |
| O_alpha | O_alpha_relative | log10_O_alpha_absolute（核心4指标R日志实际列出） |
| O_beta | O_beta_relative | log10_O_beta_absolute（核心4指标R日志实际列出） |

实际R日志仅列出4个核心log10 absolute指标：`log10_O_theta_absolute`、`log10_F_theta_absolute`、`log10_O_alpha_absolute`、`log10_O_beta_absolute`。其余5个log10名称在上表明确标为待核的目标对应名，不冒充实际最终变量清单。

Low beta/high beta未进入实际core/secondary/supplemental这9个ROI×band清单；MATLAB确实另外提取它们作为特征。Methods中有频带定义，只能证明这些特征被定义或提取，不能证明进入了这组temporal模型。最终18项变量清单与是否排除low/high beta：仍需原temporal audit脚本/表锁定。

Confidence：对实际配置9个relative字段和日志4个absolute字段为高；对最终temporal18变量表未确认。

## 历史问题状态更新

| 问题 | 状态 | 简要依据 |
| --- | --- | --- |
| 四窗口从开始即equal-status | Not confirmed；存在相反历史 | 8月2日10秒主分析；8月4日才改同等并行 |
| 144项运行前primary multiplicity family | Not confirmed | core指标预先指定，不等于144项联合BH已指定 |
| factor-level visual-complexity reanalysis预设时间 | Evidence unavailable | 原R脚本因子化已存在；未找到核查问题所指后续reanalysis计划/脚本 |
| 0805工作区完整等于5174929 | Not confirmed | 存在ce80f1f上的未提交改动，运行后又改过索引；部分R脚本逐字节一致 |
| 上游预处理记录 | Confirmed for current .set history; historical input snapshot incomplete | 56份history可读，2份后来修改；不据此补推ICA成分删除 |

## 数值表使用说明与证据

[TEMPORAL_EEG_SOURCE_OF_TRUTH.csv](../02_数据表/TEMPORAL_EEG_SOURCE_OF_TRUTH.csv)包含**32条已找到的原始核心temporal系数**（4 outcomes×4窗口×2 predictors）；其source_status明确标记“ORIGINAL_0805_CORE_ONLY_NOT_FINAL_18_OUTCOME_TEMPORAL_AUDIT”。CI/within_q/joint_q留空并注明原因。它是本次能证实的来源摘录，**不是已完成的144项最终temporal审计表**。

- **E0146** [eeg_cr2_robust_results.csv](../evidence/run_parallel/06_eeg_primary/onset_window_models/trim_10s/eeg_cr2_robust_results.csv)；定位：Model1、Block、PositionWithinBlockCentered。
- **E0106** [26_eeg_analysis_log.txt](../evidence/run_parallel/06_eeg_primary/26_eeg_analysis_log.txt)；定位：core/secondary/supplemental relative与4个log10 absolute列表。
- **E0042** [Reviewer1_parallel_previous_scene_FDR.csv](../evidence/run_parallel/07_reviewer_analysis/Reviewer1_parallel_previous_scene_FDR.csv)；定位：完整48行，within/joint两列。
- **E0007** [common.R](../evidence/code_HEAD/analysis/r/common.R)；定位：49–66：仅导出CR2 estimate、SE、df、p，无CI。

本轮完成标准检查：分母有代码证据=通过；position逐ROI/窗口最终校正证据=缺失；theta最终q唯一来源=缺失；previous-scene两种q区分=通过；72的算术含义=通过、实际运行=缺失；最终temporal18个变量名单=缺失。因此这是**已完成现有材料核查、仍有外部证据缺口**的审计交付，不能宣称全部六项完成或端到端复现。

## 对两个主要结果目录的扩展核查

已扩展检查两处主要分析结果与交付归档，追查核查问题所述分析对应的实际产物。排除本次0906交付目录后，共登记6493个文件，包括3187个CSV、1825个XLSX；识别857张模型表（含不同版本/副本，不是独立分析次数），对有配套CSV的工作簿检查CSV，其余工作簿按内容去重检查了327份。没有读取错误。模型表均无晚于8月9日的mtime；mtime只作辅助，不据此排除另处分析。

实际保存的结构是：

| 实际产物 | 结局/窗口/模型结构 | 来源 |
| --- | --- | --- |
| 四窗口核心R Model1 | 4个relative outcomes×4窗口=16个Model1；另有Model0/PreviousScene/Block1，不能混算为新temporal模型 | onset_window_models下四个eeg_temporal_main_model.csv |
| 10秒R主分析及敏感性诊断 | 9个relative outcomes＋4个核心log10 absolute outcomes=13个已保存诊断；n=474 | 18_eeg_model_diagnostics.csv |
| 四窗口共同QC GEE | 9个裸absolute outcomes×4窗口=36个模型；n=461；不是18-outcome relative/log10重分析 | onset_variant_model_results.csv |

在本次已识别模型表的outcome字段中，尚未找到另外5个log10 absolute outcomes。因此，**目前尚未把核查问题中提及的18个结局、72个模型对应到具体原始输出；这不证明该分析不存在，也不足以判断相关表述有误。** 上表仅列出了已定位的几类产物，不能据此排除另有汇总表、补充分析或生成报告的步骤。

**该计数有明确的分析结构依据：3个ROI（额、顶、枕）×3个频段（theta、alpha、beta）×2种尺度=18个结局；18×4个窗口=72个模型。** 已有输入含9个relative和9个absolute指标，但输入具备这些字段，不等于18个结局均完成了指定模型和校正。该说法可能依据已有结果或汇总，具体出处仍待对应；两个72项检验族、全部模型收敛及新增alpha校正结论，需以相应输出核实。是否补跑应由最终分析范围和现有输出覆盖情况决定。

逐表检索清单：`../evidence/MODEL_TABLE_CATALOG.csv`；全文件范围：`../evidence/RESULT_SCOPE_INVENTORY.csv`；汇总：`../evidence/RESULT_SCOPE_SUMMARY.json`。

针对theta×Block/round校正值，进一步扫描676份包含theta/alpha结局的CSV模型表，未在对应q/BH/FDR/adjusted字段找到0.00447、0.00461或0.02239前缀的目标值。这里只是来源核查，不重新计算q；记录见 `../evidence/THETA_Q_VALUE_SOURCE_SEARCH.json`。
