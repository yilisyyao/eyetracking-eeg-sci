# EEG_METHOD_DISCREPANCIES_20260906

仅列本次已确认的方法/报告口径差异；不检查旧Title、Introduction、Discussion、Conclusion。

| 项目 | 已确认事实 | 需如何说明 | 证据 |
| --- | --- | --- | --- |
| METHODS DEFINITION MISMATCH：relative分母 | 核查文件所引1–30 Hz与运行算法1–45 Hz不一致 | 按原算法说明1–45 Hz；完整当前稿未提供，不声称已定位全文段落 | MATLAB328、338–340、547；RELATIVE_POWER_DENOMINATOR_AUDIT.md |
| previous-scene q标签歧义 | 10秒0.5321856016及15秒0.1183456393是within；joint为0.8071868111及0.4733825573 | 给q明确加within-window或joint four-window标签 | 原48行FDR表 |
| 运行manifest与工作区版本不等价 | manifest记录ce80f1f，但运行用了未提交parallel改动，8月9日才归档5174929 | 区分HEAD记录、工作区修改及后来归档提交 | Git+任务补丁+run_manifest |
| 分母配置文字不是算法控制项 | relative_power_denominator_hz未直接传入计算；实际使用opts.Bands.totalBand40 | 复现说明给出实际计算参数及函数；不能只引用teacher描述字段 | MATLAB apply_config、append_bandpower_columns |
| 随机种子有不同作用范围 | onset为20260802；R core bootstrap为20260726 | 按各自分析过程分别报告，避免统称全流程同一种子 | teacher配置；eeg_primary_analysis.R267 |
| 字符空值读取差异 | R把当前C0空字符串当参考因子；Python默认读为NaN | 说明编码和原读取方式；75条首位置由显式位置过滤排除 | R_READ_SAMPLE_CONFIRMATION.csv；contracts.py221–260 |
| 756行不是756项正式假设检验 | inference_role=parallel_descriptive_pairwise，含截距，6×9×14行 | 称描述性跨窗口比较；不把其CI当正式配对推断 | onset_sensitivity.py368–393 |
| 不可将本地144/324直接作同一结果集比较 | 144为核心relative R/CR2；本地可定位324为absolute GEE子集 | 报告中同时注明模型、尺度、family；核查问题中另一324原件仍待核 | ANALYSIS_FAMILY_144_VS_324.md |
| 当前原始输入与历史快照不同 | 当前2份.set的mtime晚于原运行，既有审计记录更新 | 不得将当前112文件哈希当作8月2日输入锁定证据 | CURRENT_SET_HISTORY_CHECKS.csv；原审计材料 |

不列为“已确认错误”的项目：position→relative alpha是否显著、theta两组q哪组正确、72模型是否确实全部收敛、144项是否后来另有正式校正、最终18个temporal变量名单。这些属于证据缺口，详见增补报告。72模型和每scale 72项检验的计数含义已拆清，但未收到完整当前稿，不能断言稿中已混淆。
