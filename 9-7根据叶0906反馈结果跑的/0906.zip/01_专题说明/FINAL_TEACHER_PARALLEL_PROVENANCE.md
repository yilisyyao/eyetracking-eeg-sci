# FINAL_TEACHER_PARALLEL_PROVENANCE

审计日期：2026-09-06。

**最影响3.3的结论：四种窗口长度8月2日已共同列出，但同等平行地位于已检视10秒结果后的8月4日调整；144条核心系数可定位，144项统一primary BH family未获证实，不能把它与本地324条absolute GEE子集混为一谈。**

**本次状态：现有材料的只读核查已完成；核查问题所指最终18-outcome temporal audit、两组theta q原表及144项专属BH仍未找到，相关结论未锁定。**

本次只读取代码、已有CSV/JSON/日志/ZIP、Git历史和EEGLAB `.set` 中的history/元数据，并计算文件哈希、已有表的行数及集合对应关系。未重新拟合模型，未重算p值、BH q值、置信区间或频谱，未修改原工程、0803/0805交付包或论文。R仅用于复核原 `read.csv` 的缺失值语义；MATLAB仅用于读取56份 `.set` 的history。所有新文件都写入本目录。

结论优先依据原始配置、机器结果及执行代码；旧报告和本地任务对话仅用于定位及决策时间溯源。本文所列时间统一明确标注UTC或北京时间。文件mtime及本次SHA-256不能单独证明历史时刻的文件内容。状态 `NOT FOUND/UNRESOLVED` 表示在列明范围内缺少证据，并不等于证明相关分析从未发生。

## 证据与阅读入口

- [EEG_WINDOW_HISTORY.md](EEG_WINDOW_HISTORY.md)：问题3的时间线与可用措辞。
- [ANALYSIS_FAMILY_144_VS_324.md](ANALYSIS_FAMILY_144_VS_324.md)：问题4六个子问及模型/尺度/family区别。
- [NEW_EEG_TECHNICAL_CHECKS_20260906.md](NEW_EEG_TECHNICAL_CHECKS_20260906.md)：增补Q1–Q6逐项结果与缺口。
- [CRITICAL_FILE_MANIFEST.csv](../03_清单与核验/CRITICAL_FILE_MANIFEST.csv)：每项来源标识、mtime UTC、SHA-256、包内证据副本及已知Git版本。历史CSV若没有独立代码归档，其Git字段保留UNRESOLVED，不以manifest的HEAD冒充完整工作区。
- `../evidence/code_5174929.zip`：指定提交的完整代码；`code_ce80f1f`、`code_5174929`、`code_HEAD`为关键脚本/配置副本。

## 问题1 实际代码版本 — PARTIALLY CONFIRMED

最终交付采用固定的最新仓库提交运行并归档；以下版本差异仅说明历史溯源，不再将证明8月4日工作区与5174929完全一致作为最终交付的前提。本报告仍为已有材料核查，尚未执行最新版本重跑。

1. **确认使用ce80f1f基础上的未提交平行代码**：运行manifest记ce80f1f；8月4日本地工具补丁记录和实际配置/四窗口结果表证明运行包含尚未进入该提交的修改。8月9日实施计划也记录尚未提交的0805平行改动。
2. 5174929在8月9日归档该批平行功能：确认；但“所有字节与8月4日实际工作区完全相同”：未确认。
3. 运行后至提交前代码确有修改。8月4日14:40:30 UTC为报告来源映射增加48项FDR文件；15:16:23 UTC（正式完成后）修改 `_all_files_index`，排除索引文件自身。后者及对应测试有完整补丁事件，不能说运行后代码完全没变。这些已查明修改属于来源索引/报告支持，不据此推断模型被重新拟合。
4. `27_eeg_primary_analysis.R`、`28_eeg_robustness_analysis.R`（实际为同一primary脚本副本）、`29_eeg_crossmodal_analysis.R`分别与ce80f1f及5174929对应源码逐字节匹配（6次比较全部相同）。但没有完整运行工作区快照/hash清单覆盖全部Python与R文件。

**无法确认5174929与8月4日实际工作区完全一致；5174929是目前最接近的已归档平行分析代码版本。**

已保存Git log/reflog、两个版本diff、完整5174929代码ZIP、相关本地任务消息与成功补丁事件。默认VS Code/Cursor History路径未发现可用历史，未把它们作为证据。当前Git工作区干净。

对论文：最终软件版本应填写实际生成最终结果的固定提交，并与运行记录一致。5174929仅用于本次历史核查，不能替代尚未完成的最终运行版本记录。

- **E0110** [run_manifest.json](../evidence/run_parallel/06_eeg_primary/run_manifest.json)；定位：git_commit、created_at_utc、config_path。
- **E0111** [run_manifest.json](../evidence/run_parallel/99_completion/run_manifest.json)；定位：2026-08-04T14:45:15.566013Z；status=complete。
- **E0483** [历史代码补丁记录](../evidence/historical_repo_patch_events.json)；定位：第1820、2428行成功补丁；historical_repo_patch_events.json。
- **E0484** [历史任务记录摘录](../evidence/history_excerpts.json)；定位：第703行记录未提交0805改动。
- **E0107** [27_eeg_primary_analysis.R](../evidence/run_parallel/06_eeg_primary/27_eeg_primary_analysis.R)；定位：完整归档脚本；ARCHIVED_R_CODE_COMPARISON.csv。


## 问题2 实际运行配置 — CONFIRMED

已找到 `teacher_parallel_20260804/teacher_analysis.parallel.json`，原样副本在 `../evidence/run_parallel/teacher_analysis.parallel.json`，哈希与源文件一致。字段详表和与两个仓库示例的比较见 [ACTUAL_CONFIG_COMPARISON.md](ACTUAL_CONFIG_COMPARISON.md)。

| 实际字段 | 值 |
| --- | --- |
| eeg.onset_trim_strategy | "parallel" |
| eeg.reference_onset_trim_s | 10 |
| eeg.onset_trim_variants_s | [0, 5, 10, 15] |
| eeg.core_metrics | ["O_theta", "F_theta", "O_alpha", "O_beta"] |
| eeg.secondary_metrics | ["P_theta", "P_alpha", "F_alpha"] |
| eeg.supplemental_metrics | ["F_beta", "P_beta"] |
| eeg.bootstrap_iterations | 5000 |
| eeg.onset_random_seed | 20260802 |
| eeg.primary_measure | "relative_power" |
| eeg.trial_file（文件标识） | "teacher_onset_20260802/00_eeg_trial_qc/eeg_trial_long.csv" |
| eeg.onset_sensitivity_trial_file（文件标识） | "teacher_onset_20260802/00_eeg_trial_qc/eeg_onset_sensitivity_trial_long.csv" |
| eeg.onset_analysis_dir（目录标识） | "teacher_parallel_20260804/00_eeg_onset_statistics" |
| eeg.preprocessing_parameters.relative_power_denominator_hz | 1-45 |
| 顶层random_seed | 字段不存在；onset_random_seed=20260802 |
| R primary bootstrap实际种子 | set.seed(20260726)，analysis/r/eeg_primary_analysis.R:267 |
| run_id | teacher_parallel_20260804 |

对Methods：要分别报告onset seed=20260802与R主分析cluster-bootstrap seed=20260726，不可统称同一个种子。实际配置与示例已分开归档，没有重建或冒充运行配置。

- **E0021** [teacher_analysis.parallel.json](../evidence/run_parallel/teacher_analysis.parallel.json)；定位：完整文件；各字段如表。
- **E0006** [eeg_primary_analysis.R](../evidence/code_HEAD/analysis/r/eeg_primary_analysis.R)；定位：267：bootstrap随机种子。


## 问题3 四窗口何时确定 — CONFIRMED（历史时间线）；prospective equal-status不成立

四种长度8月2日已共同列入新截断实施方案，当时10秒为主分析。8月3日已有10秒/15秒结果讨论；8月4日21:19北京时间才形成明确同等并行计划，并在当晚完成平行管线。Git于8月9日归档。详见 [EEG_WINDOW_HISTORY.md](EEG_WINDOW_HISTORY.md)，其中附原文、时间、来源行、哈希与代码证据。

对3.3：可以描述最终平行分析，不能把最终地位写成从一开始就预先规定的同等分析。四种长度本身不是在8月4日才新增。共同QC/模型一致已验证；144项统一BH尚未证实。
- **E0482** [历史任务记录摘录](../evidence/history_excerpts.json)；定位：第350行。
- **E0483** [历史任务记录摘录](../evidence/history_excerpts.json)；定位：第128、665行。

## 问题4 144项与324项 — PARTIALLY CONFIRMED / primary-family地位UNRESOLVED

4个核心relative outcomes确为早先配置定义，四个R/CR2 Model1文件可提取144项已有系数；未找到其36/144项BH脚本或输出。不能据此称144为当时primary multiplicity family，也不能断言其一定是在后来从核查问题所指324项中提取。

本地能够定位并提取的324行来自9个裸absolute-power outcomes的Gaussian GEE，继承117/468项校正，而非relative-power CR2。核查问题是否指另一份后续324项审计，尚未找到原表确认。六个子问的逐项答案见 [ANALYSIS_FAMILY_144_VS_324.md](ANALYSIS_FAMILY_144_VS_324.md)。

对3.3：仅客观描述核心4指标跨4窗口考察144项Model1系数；不称预先定义primary family，不混用GEE的q。
- **E0006** [eeg_primary_analysis.R](../evidence/code_HEAD/analysis/r/eeg_primary_analysis.R)；定位：132–170。
- **E0009** [onset_sensitivity.py](../evidence/code_HEAD/src/paper_analysis/stats/onset_sensitivity.py)；定位：186–200、436–441。

## 问题5 脚本—输出映射 — PARTIALLY CONFIRMED

详见 [SCRIPT_OUTPUT_MAP.csv](../03_清单与核验/SCRIPT_OUTPUT_MAP.csv)，覆盖全部指定分析项；找不到的最终temporal audit及144项专属BH明确标为NOT FOUND。

- `eeg_cr2_robust_results.csv`：`analysis/r/eeg_order_analysis.R`第112行；CR2计算在common.R。
- `Reviewer1_parallel_previous_scene_FDR.csv`：`src/paper_analysis/teacher/complete.py`的 `_parallel_order_carryover_audit` 合并，各窗口12项BH及联合48项BH，703–706行写出。
- `onset_window_comparisons.csv`：`src/paper_analysis/stats/onset_sensitivity.py`的 `descriptive_window_comparisons`；6个窗口对×9 outcomes×14个系数（含截距）=756行。

**756是描述性系数比较行数，不是756项正式显著性检验。** 代码明确写 `parallel_descriptive_pairwise`，其差值区间用两SE平方和，不包含跨窗口配对协方差；不应把它们当成正式配对窗口差异证据。本次不改代码或重算区间。

对Methods：明确R/CR2主路径与GEE兼容/补充路径；分别列窗口、样本、尺度、校正范围。
- **E0005** [eeg_order_analysis.R](../evidence/code_HEAD/analysis/r/eeg_order_analysis.R)；定位：111–112。
- **E0011** [complete.py](../evidence/code_HEAD/src/paper_analysis/teacher/complete.py)；定位：419–459、703–706。
- **E0009** [onset_sensitivity.py](../evidence/code_HEAD/src/paper_analysis/stats/onset_sensitivity.py)；定位：368–393。

## 问题6 Previous-scene实际样本 — CONFIRMED

四窗口均为42/461，前序未定义75条全部是首位置，轮1/轮2分别37/38；筛选后42/386。原R读取方式与Python保留空字符串读取得到一致结果；并非默认Python dropna的结果。详表及数值见 [PREVIOUS_SCENE_SAMPLE_CONFIRMATION.md](PREVIOUS_SCENE_SAMPLE_CONFIRMATION.md) 与 `../evidence/R_READ_SAMPLE_CONFIRMATION.csv`。

对Methods：写明“首位置前序条件结构性未定义，按PositionWithinBlock>1排除”，其余模型完整案例386；不要写成75条数据读入失败或自动na.omit。当前复杂度C0的字符空值编码也应记录，以便复现。
- **E0005** [eeg_order_analysis.R](../evidence/code_HEAD/analysis/r/eeg_order_analysis.R)；定位：42。
- **E0136** [eeg_onset_order_model_input.csv](../evidence/run_parallel/06_eeg_primary/onset_window_models/trim_10s/eeg_onset_order_model_input.csv)；定位：461行；PreviousWWR/PositionWithinBlock/Block。

## 问题7 Relative power分母 — CONFIRMED（算法）

实际1–45 Hz；由MATLAB `append_bandpower_columns`调用 `bandpower_welch`，默认 `totalBand40=[1 45]`。teacher配置中的文字字段不是实际传参入口。0.5–40 Hz上游滤波与1–45 Hz积分范围同时存在，本次未改变或重算结果。详见 [RELATIVE_POWER_DENOMINATOR_AUDIT.md](RELATIVE_POWER_DENOMINATOR_AUDIT.md)。

对Methods：核查文件所引1–30 Hz定义需修正为原算法1–45 Hz，并说明源数据已有上游滤波；不能把积分上限静默改成40 Hz。
- **E0012** [run_eeg_bandpower_pipeline.m](../evidence/code_HEAD/matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m)；定位：328、338–340、401–417、547、554–570。
- **E0162** [eeg_onset_export_stdout_02.log](../evidence/run_onset/eeg_onset_export_stdout_02.log)；定位：成功导出及validation_status: pass。

## 问题8 0803与0805的版本关系 — CONFIRMED（正式入口）；全部文件无错误不作保证

1. 0803交付对应teacher_onset_20260802及10秒主方案；0805交付说明明确对应teacher_parallel_20260804及四窗口最终并行。
2. 当前根目录README和realdata_run_summary均把parallel运行标为正式，promoted=true；因此论文EEG结果应以0805所对应正式parallel源表为基准，不再与0803旧结果混选。
3. 已直接读取两个原始ZIP逐文件比较：按去除SourceID后的同名路径比较，0805中219项与0803逐字节相同、179项改变、13项新增；这是整个ZIP文件比较，不把它与408个数据源文件计数混淆。眼动Stage2/3合计98个文件全部相同（46+52），支持统一阅读0805而非拼接两个版本。
4. 0803的10秒主结果、旧样本窗口结果以及10/15等价性材料保留为历史/兼容参考。原onset运行中被实际配置引用的频带功率输入仍是有效上游来源，不能因为目录较旧就视为废弃。
5. 0805仍保留10秒兼容R主分析（42/474）和四窗口共同QC（42/461），以及GEE兼容输出；不能把所有同名文件等同。当前知道的风险包括：144项BH未找到、最终18-outcome temporal audit未找到、756行只是描述比较、历史工作区不完整归档、两份当前.set曾后改。未发现理由要求推翻已核对的48项previous结果，但未承诺0805每个文件都无错误。
6. 同名结果值不同应按正式parallel的具体source path、模型、样本与尺度取值；**不能机械地按文件名或日期选最新**。原始EEG四窗口结果优先0805，而后续temporal新审计若要替代某些值，需先提供其源表与版本说明。

对论文：明确用0805正式管线和具体表；不要在Results里混用474与461样本，或混用relative CR2与absolute GEE。

- **E0485** [README_当前有效结果.md](../evidence/handoff_docs/README_当前有效结果.md)；定位：当前正式运行。
- **E0311** [realdata_run_summary.json](../evidence/realdata_run_summary.json)；定位：run_id、promoted、completed_at_utc。
- **E0486** [数据来源交接说明-0805.md](../evidence/handoff_docs/数据来源交接说明-0805.md)；定位：正式运行批次与四窗口口径。

逐文件比较：`../evidence/PACKAGE_0803_0805_COMPARISON.csv`；两个ZIP的读取清单：`../evidence/PACKAGE_EEG_TABLE_INVENTORY.csv`。


## 问题9 EEG输入边界 — PARTIALLY CONFIRMED

1. MATLAB直接 `pop_loadset` 读取已预处理 `.set`及关联`.fdt`，下游teacher分析直接读取其频带功率CSV。实际teacher配置复用了onset运行的 `00_eeg_trial_qc/eeg_trial_long.csv` 和 `eeg_onset_sensitivity_trial_long.csv`。
2. exporter源码没有再次执行filtering、notch、re-reference或ICA的调用；它做marker7→8分段、起始剔除、Welch功率和QC特征提取。
3. 56份.set及56份.fdt的本次路径/大小/mtime/SHA均已登记（未复制大文件）；原导出subject methods snapshots及summary CSV已复制。原下游input_hashes中已记录的5项依赖全部与现存文件哈希匹配。
4. **没有找到覆盖56份.set/.fdt在8月2日输入时状态的完整历史哈希清单**。本次当前原件哈希不能冒充当时输入哈希。当前两份.set mtime在8月4日之后，既有8月18日审计也记载了更新；无法把它们直接视为当时输入原件。
5. `.set`内history可归档读到上游0.5–40、49–51、平均参考和runica记录；但这些是当前文件状态，不是全部旧输入的独立快照。未找到pop_subcomp历史，不替作者推测ICA成分剔除标准。
6. 预处理到功率CSV：`scripts/run_eeg_from_raw.py` → `matlab/run_eeg_bandpower_from_set.m` → `matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m`；随后Python EEG/QC生成teacher输入。

对Methods：区分作者EEGLAB预处理、MATLAB功率导出、Python QC/编排与R统计。可报告有证据的算法和输入；不能声称当前全部输入已与原运行按哈希锁定，也不能声称端到端复现。

- **E0012** [run_eeg_bandpower_pipeline.m](../evidence/code_HEAD/matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m)；定位：4–7、76、254、286、309–340。
- **E0003** [run_eeg_from_raw.py](../evidence/code_HEAD/scripts/run_eeg_from_raw.py)；定位：53–62、102–130。
- **E0021** [teacher_analysis.parallel.json](../evidence/run_parallel/teacher_analysis.parallel.json)；定位：eeg.trial_file及onset_sensitivity_trial_file。
- **E0066** [input_hashes.json](../evidence/run_parallel/06_eeg_primary/input_hashes.json)；定位：历史下游输入哈希。


## 检索范围与尚缺证据

主要完整核查：本Git仓库、两个指定结果根目录、teacher_onset/teacher_parallel运行目录、0803/0805 ZIP及0805交付副本、相关8月2/3/9日本地任务记录、56份现存EEGLAB元数据。另对D盘、E盘及用户目录进行了目标文件名检索；部分系统/临时目录拒绝访问，错误日志已保存，不宣称全盘无遗漏。后续内容检索只针对代码、配置、分析日志与结果，未把无关相近数字当作q值来源。

未找到：最终18-outcome temporal audit脚本/完整输出、260905 Results完整稿、两组theta q的未舍入原表、36/144专属BH脚本与输出、完整的运行时工作区快照及56份历史EEG输入哈希。

最小补证材料是：产生144项q及18-outcome temporal audit的原脚本、实际配置、机器可读结果表和生成时间记录。无需为了填本审计而重新运行模型；缺少原件时维持UNRESOLVED。

## 对两个主要结果目录的扩展核查

已扩展检查两处主要分析结果与交付归档，追查核查问题所述分析对应的实际产物。排除本次0906交付目录后，共登记6493个文件，包括3187个CSV、1825个XLSX；识别857张模型表（含不同版本/副本，不是独立分析次数），对有配套CSV的工作簿检查CSV，其余工作簿按内容去重检查了327份。没有读取错误。模型表均无晚于8月9日的mtime；mtime只作辅助，不据此排除另处分析。

实际保存的结构是：

| 实际产物 | 结局/窗口/模型结构 | 来源 |
| --- | --- | --- |
| 四窗口核心R Model1 | 4个relative outcomes×4窗口=16个Model1；另有Model0/PreviousScene/Block1，不能混算为新temporal模型 | onset_window_models下四个eeg_temporal_main_model.csv |
| 10秒R主分析及敏感性诊断 | 9个relative outcomes＋4个核心log10 absolute outcomes=13个已保存诊断；n=474 | 18_eeg_model_diagnostics.csv |
| 四窗口共同QC GEE | 9个裸absolute outcomes×4窗口=36个模型；n=461；不是18-outcome relative/log10重分析 | onset_variant_model_results.csv |

在本次已识别模型表的outcome字段中，尚未找到另外5个log10 absolute outcomes。因此，**目前尚未把核查问题中提及的18个结局、72个模型对应到具体原始输出；这不证明该分析不存在，也不足以判断相关表述有误。** 上表仅列出了已定位的几类产物，不能据此排除另有汇总表、补充分析或生成报告的步骤。

**该计数有明确的分析结构依据：3个ROI（额、顶、枕）×3个频段（theta、alpha、beta）×2种尺度=18个结局；18×4个窗口=72个模型。** 已有输入含9个relative和9个absolute指标，但输入具备这些字段，不等于18个结局均完成了指定模型和校正。该说法可能依据已有结果或汇总，具体出处仍待对应；两个72项检验族、全部模型收敛及新增alpha校正结论，需以相应输出核实。是否补跑应由最终分析范围和现有输出覆盖情况决定。

逐表检索清单：`../evidence/MODEL_TABLE_CATALOG.csv`；全文件范围：`../evidence/RESULT_SCOPE_INVENTORY.csv`；汇总：`../evidence/RESULT_SCOPE_SUMMARY.json`。
