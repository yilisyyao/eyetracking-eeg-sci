# EEG Bandpower Methods Snapshot

- Input: preprocessed EEGLAB .set files.
- Segmentation: marker state machine with 7->8 as scene viewing.
- Estimand: sustained-state activity after scene entry.
- Primary onset trim: 10.000 s before PSD and QC.
- Onset sensitivity trims (s): 0, 5, 10, 15.
- Bandpower: Welch PSD integrated within configured bands.
- QC metrics: HF ratio, RMS, peak-to-peak, NaN fraction, flat fraction, boundary flag, valid duration.
- Legacy HF threshold: 0.400, exported for audit/sensitivity only.
- Formal robust exclusion is applied downstream in Python, not by this exporter.
- Low-gamma and high-beta are exploratory because high-frequency EEG is sensitive to muscle artifacts.
