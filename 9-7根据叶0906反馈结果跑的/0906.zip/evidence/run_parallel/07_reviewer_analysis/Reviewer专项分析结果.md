# Reviewer专项分析

## Reviewer 1 意见11

并行报告0、5、10、15 s下的 Block、Position、三个OrderGroup、Model 0/Model 1、同Block前序条件、Block 1与CR2；不使用“完全排除顺序效应”。四窗口共同QC前序项共48个系数；raw p<0.05为2个，窗口内FDR后为0个，四窗口联合FDR后为0个。

## Reviewer 2 意见5

仅把 alpha/theta、眨眼、瞳孔和扫描路径视为时间变化代理。实验没有直接疲劳量表，因此不把代理变化直接表述为疲劳。
