# EEG时间与顺序效应分析

- 结构审核：42 人、504 试次。
- 场景级QC建模：42 人、474 试次。
- Model 0 与加入 Block、PositionWithinBlockCentered、三个 OrderGroup 的 Model 1 并列报告。
- PreviousWWR 与 PreviousComplexity 仅在同一 Block 的 Position 2–6 中定义。
- 结论依据方向、估计幅度、95% CI 与 CR2，不以是否跨过 p=0.05 作为唯一标准，也不声称完全排除顺序效应。
