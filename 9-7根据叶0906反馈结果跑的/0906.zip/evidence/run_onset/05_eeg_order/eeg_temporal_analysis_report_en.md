# EEG temporal and order analysis

The structural audit included 42 participants and 504 trials; scene-level QC retained 42 participants and 474 trials for modeling. Model 0 and the time/order-adjusted Model 1 are compared by direction, magnitude and confidence intervals. The analysis does not claim that order effects were completely excluded.
