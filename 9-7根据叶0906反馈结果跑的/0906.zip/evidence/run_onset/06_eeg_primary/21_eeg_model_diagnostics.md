# EEG Model Diagnostics

Failed mixed models and failed Bootstrap replicates are reported explicitly. No OLS or alternative model is used as a silent replacement.

## Diagnostics

```csv
outcome,model,status,singular,n
O_theta_relative,EEG_relative_primary,fit,False,474
F_theta_relative,EEG_relative_primary,fit,False,474
O_alpha_relative,EEG_relative_primary,fit,False,474
O_beta_relative,EEG_relative_primary,fit,False,474
log10_O_theta_absolute,EEG_absolute_sensitivity,fit,False,474
log10_F_theta_absolute,EEG_absolute_sensitivity,fit,False,474
log10_O_alpha_absolute,EEG_absolute_sensitivity,fit,False,474
log10_O_beta_absolute,EEG_absolute_sensitivity,fit,False,474
P_theta_relative,EEG_relative_secondary,fit,False,474
P_alpha_relative,EEG_relative_secondary,fit,False,474
F_alpha_relative,EEG_relative_secondary,fit,False,474
F_beta_relative,EEG_relative_supplemental,fit,False,474
P_beta_relative,EEG_relative_supplemental,fit,False,474
```
