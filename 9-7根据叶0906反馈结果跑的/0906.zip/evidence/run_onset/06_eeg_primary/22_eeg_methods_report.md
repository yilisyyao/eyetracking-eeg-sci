# EEG Analysis Methods

Relative power is primary; raw absolute power is descriptive and log10 absolute power is a fixed sensitivity analysis.

The structural audit cohort and scene-QC model cohort are reported separately.

The formal estimand is sustained-state EEG: the first 10 s of each scene are removed before PSD and QC; 15 s is the main robustness window, with 5 s and 0 s used for sensitivity audit.

A fixed onset trim mitigates transition influence but cannot demonstrate that residual carryover is eliminated.

## Preprocessing and extraction audit

```csv
Parameter,Value,Evidence
input_state,preprocessed EEGLAB .set,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
upstream_filter_and_reference,not recoverable from exporter; reported as unavailable,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
view_start_marker,7,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
view_end_marker,8,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
theta_hz,4-7,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
alpha_hz,8-12,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
beta_hz,13-30,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
relative_power_denominator_hz,1-45,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
frontal_roi,"F3,F4",matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
parietal_roi,"P3,PZ,P4",matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
occipital_roi,"O1,OZ,O2",matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
power_estimator,Welch PSD integrated over band,matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m and generated methods snapshot
primary_onset_trim_s,10,configs/eeg_analysis.json and MATLAB scene export
onset_trim_variants_s,"0,5,10,15",configs/eeg_analysis.json and MATLAB onset sensitivity export
onset_equivalence_bound_sd,0.20,configs/eeg_analysis.json
```

## Outcome registration

```csv
Metric,Family,PrimaryMeasure,AbsolutePowerRole,DefaultClaimGrade
O_theta,Core,relative_power,sensitivity,pending_robustness
F_theta,Core,relative_power,sensitivity,pending_robustness
O_alpha,Core,relative_power,sensitivity,pending_robustness
O_beta,Core,relative_power,sensitivity,pending_robustness
P_theta,Secondary,relative_power,sensitivity,Exploratory
P_alpha,Secondary,relative_power,sensitivity,Exploratory
F_alpha,Secondary,relative_power,sensitivity,Exploratory
F_beta,Supplemental,relative_power,sensitivity,Exploratory
P_beta,Supplemental,relative_power,sensitivity,Exploratory
```
