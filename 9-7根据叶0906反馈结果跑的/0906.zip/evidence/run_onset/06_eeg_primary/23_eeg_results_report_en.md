# Teacher-priority EEG Primary Analysis

Relative power is primary; log10 absolute power is sensitivity.

Core outcomes alone enter the primary BH-FDR families.

Bootstrap failures are retained and reported, never replaced.

## Outcome registration

```csv
Metric,Family,PrimaryMeasure,AbsolutePowerRole,DefaultClaimGrade
O_theta,Core,relative_power,sensitivity,pending_robustness
F_theta,Core,relative_power,sensitivity,pending_robustness
O_alpha,Core,relative_power,sensitivity,pending_robustness
O_beta,Core,relative_power,sensitivity,pending_robustness
P_theta,Secondary,relative_power,sensitivity,Exploratory
P_alpha,Secondary,relative_power,sensitivity,Exploratory
F_alpha,Secondary,relative_power,sensitivity,Exploratory
F_beta,Supplemental,relative_power,sensitivity,Exploratory
P_beta,Supplemental,relative_power,sensitivity,Exploratory
```

## Robustness classification

下表仅展示前 15 行和前 8 列；完整机器可读表随结果单独交付。

```csv
outcome,term,estimate,adjusted_p,sensitivity_estimate_count,sensitivity_direction_concordance,required_sensitivity_families_complete,bootstrap_ci_low
F_theta_relative,ComplexityC1,0.0006077947418945,0.782129339723156,48,0.875,True,-0.003681062912222
F_theta_relative,ComplexityC1:ExperienceGroupLow,0.0022559450806098,0.612966604635232,48,1.0,True,-0.001864758171564
F_theta_relative,ExperienceGroupLow,0.0016742356141591,0.847523692241257,48,0.833333333333333,True,-0.0149864018350323
F_theta_relative,WWRWWR45,0.0018592657821856,0.627612312248065,48,0.9375,True,-0.0056247418399616
F_theta_relative,WWRWWR45:ComplexityC1,0.0070010949692164,0.084553456967385,48,1.0,True,0.0008019823127218
F_theta_relative,WWRWWR45:ExperienceGroupLow,-0.0032353127275843,0.770000120470648,48,0.979166666666667,True,-0.0108336275180278
F_theta_relative,WWRWWR75,0.0046703754997021,0.106985387814912,48,1.0,True,0.0002820475264995
F_theta_relative,WWRWWR75:ComplexityC1,-0.0017113702241606,0.567331003568867,48,0.9375,True,-0.0071720443104554
F_theta_relative,WWRWWR75:ExperienceGroupLow,-0.0048203173293111,0.174031435188544,48,1.0,True,-0.0100414881386676
O_alpha_relative,ComplexityC1,-0.0113485533056165,0.23133341069745,48,1.0,True,-0.0315844866277156
O_alpha_relative,ComplexityC1:ExperienceGroupLow,0.0073347085812742,0.487969287732388,48,0.958333333333333,True,-0.0109908999976501
O_alpha_relative,ExperienceGroupLow,-0.0286605244241305,0.242880173952016,48,0.979166666666667,True,-0.079899776879857
O_alpha_relative,WWRWWR45,-0.0361108234339683,0.106370355278946,48,1.0,True,-0.0823994106181422
O_alpha_relative,WWRWWR45:ComplexityC1,0.0101227723248397,0.193851724985291,48,0.958333333333333,True,-0.0042306862068118
O_alpha_relative,WWRWWR45:ExperienceGroupLow,0.0337305241858429,0.100360943309361,48,1.0,True,0.0041452548820628
```
