# Reviewer专项分析

## Reviewer 1 意见11

报告 Block、Position、三个 OrderGroup、Model 0/Model 1、同 Block 前序条件、Block 1 与 CR2；不使用“完全排除顺序效应”。

## Reviewer 2 意见5

仅把 alpha/theta、眨眼、瞳孔和扫描路径视为时间变化代理。实验没有直接疲劳量表，因此不把代理变化直接表述为疲劳。
