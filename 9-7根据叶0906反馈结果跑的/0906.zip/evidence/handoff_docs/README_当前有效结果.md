# 当前有效数据分析结果

当前正式运行：`teacher_runs/teacher_parallel_20260804`。

主阅读入口为 `论文数据分析结果报告.md`；审阅方规范阶段结果位于 `12_teacher_analysis`；逐文件哈希见 `结果文件总索引.xlsx`。
