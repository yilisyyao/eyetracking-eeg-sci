# EEG上游预处理证据审计：最终报告

**审计日期：** 2026-08-18  
**只读检索范围：** `E:\26\补\脑电数据`及全部子目录；扩展核查`D:\Lucas\Desktop\More-is-not-always-better`代码仓库和`E:\26\补\数据分析结果`运行归档  
**当前交付状态：** filtering、notch、average re-referencing、extended Infomax ICA、scene分段代码、Welch PSD及relative-power denominator 1–45 Hz已验证；ICA成分识别/删除、bad-channel和bad-segment处理仍未验证。

## 0. 候选材料概览

在上游EEG文件夹中共发现117个文件，总大小1,527,021,765 bytes：56个EEGLAB `.set`、56个外部`.fdt`和5个CSV缓存文件。该文件夹内未发现`.edf`、`.bdf`、实际`.easy`、MATLAB `.m`脚本、MATLAB运行日志、独立EEGLAB日志、ICLabel导出或ICA component rejection表。扩展核查后，在代码仓库和运行归档中找到实际频谱分析脚本、配置、MATLAB成功运行日志、participant-level导出及下游输入哈希；这些材料验证了scene分段、Welch PSD和1–45 Hz relative-power denominator，但不补足上游artifact-handling记录。

全部participant文件的完整路径、大小、修改时间和用途判断见同目录Excel工作簿`EEG上游预处理证据审计_证据工作簿.xlsx`中的“候选文件清单”和“Participant核查”工作表。

关键缓存文件：

- `E:\26\补\脑电数据\eeg_clock_cache\eeg_recording_clock.csv`：52人采集时钟、样本数、外部`.easy`路径、大小和SHA-256。
- `E:\26\补\脑电数据\eeg_clock_cache\eeg_set_metadata.csv`：56个`.set`的采样率、通道、事件及外部datfile缓存。
- `E:\26\补\脑电数据\eeg_clock_cache\eeg_source_resolution.csv`：原始`.easy`来源解析；52人标记为validated，4人未解析。
- `E:\26\补\脑电数据\eeg_clock_cache\eeg_trigger_events.csv`：52人、2,340条trigger及时间戳。
- `E:\26\补\脑电数据\eeg_clock_cache\irregular_timestamps\黄劲科_timestamps.csv`：黄劲科逐样本不规则时间戳。

## 一、中文审计结论

### 1. 找到的原始文件、预处理文件、脚本和日志

- 在`E:\26\补\脑电数据`及全部子目录中未发现实际原始设备文件：无`.edf`、`.bdf`或实际`.easy`文件。
- 找到56个EEGLAB `.set`及56个外部`.fdt`，属于participant-level连续EEG数据、元数据、history和ICA结果。证据范围：`E:\26\补\脑电数据\*.set`和`E:\26\补\脑电数据\*.fdt`。
- 56个`.set`的history均记录通过`pop_easy`导入外部`.easy`文件，但这些`.easy`不在当前文件夹。来源记录见`E:\26\补\脑电数据\eeg_clock_cache\eeg_source_resolution.csv`和`E:\26\补\脑电数据\eeg_clock_cache\eeg_recording_clock.csv`。
- 52人的外部`.easy`来源被缓存记录标为validated；万泽恩、吴泽诚、郑世霖和黄柔倩未解析到原始来源。
- `E:\26\补\脑电数据`内未发现MATLAB `.m`脚本或运行日志；但扩展核查在`D:\Lucas\Desktop\More-is-not-always-better\matlab\eeg_bandpower_pipeline\run_eeg_bandpower_pipeline.m`找到实际频谱分析代码，并在`E:\26\补\数据分析结果\teacher_runs\teacher_onset_20260802\eeg_onset_export_stdout_02.log`找到完成56个数据集处理、写出scene-level结果且`validation_status: pass`的成功运行记录。
- 仍未发现独立EEGLAB预处理运行日志、ICLabel结果、bad-channel表、bad-segment表或ICA component rejection表。

两处外部数据依赖文件名不一致：

- `E:\26\补\脑电数据\贺维桢.set`内部指向`贺维祯.fdt`，实际候选文件为`E:\26\补\脑电数据\贺维桢.fdt`。
- `E:\26\补\脑电数据\黎高丞.set`内部指向`黎高丞-预实验.fdt`，实际候选文件为`E:\26\补\脑电数据\黎高丞.fdt`。

两份实际`.fdt`的字节数均与相应样本数和通道数吻合，但内部依赖文件名仍不一致。

### 2. Filtering、notch、re-referencing和ICA能否验证

- **Band-pass filtering：可以验证。** 56/56个`.set`的history均记录`pop_eegfiltnew`，参数为`locutoff=0.5`、`hicutoff=40`。证据：`E:\26\补\脑电数据\*.set`。
- **Notch filtering：可以验证。** 更新后56/56均记录49–51 Hz反向滤波，`revfilt=1`。证据：`E:\26\补\脑电数据\*.set`；最新修订文件为`E:\26\补\脑电数据\李泽豪.set`和`E:\26\补\脑电数据\侯集瀚.set`。
- **滤波执行顺序并不完全统一。** 54人先0.5–40 Hz band-pass、后49–51 Hz band-stop；李泽豪和侯集瀚先band-stop、后band-pass。证据：全部`E:\26\补\脑电数据\*.set`的history。
- **Average re-referencing：可以验证。** 56/56 history记录`pop_reref(EEG,[])`，且`EEG.ref='average'`。证据：`E:\26\补\脑电数据\*.set`。
- **ICA：可以验证。** 56/56 history记录`pop_runica`、`icatype='runica'`、`extended=1`和`pca=7`，并存在`icaweights 7×8`、`icasphere 8×8`及`icawinv 8×7`。证据：`E:\26\补\脑电数据\*.set`。
- **ICA component identification/rejection：不能验证。** 56/56均无`pop_subcomp`、ICLabel或`pop_icflag`记录；`gcompreject`全部为零，其他实际rejection数组为空。证据：`E:\26\补\脑电数据\*.set`。
- **Scene segmentation：可以验证。** MATLAB管线通过marker state machine将事件`7`定义为scene viewing开始、事件`8`定义为结束；participant methods snapshot和实际导出均存在。证据：`D:\Lucas\Desktop\More-is-not-always-better\matlab\eeg_bandpower_pipeline\run_eeg_bandpower_pipeline.m`和`E:\26\补\数据分析结果\teacher_runs\teacher_onset_20260802\00_eeg_raw_export`。
- **PSD及relative power：可以验证。** 实际代码使用MATLAB `pwelch`估计PSD，窗口长度为不超过2 s的可用片段、50% overlap，`nfft`取不小于窗口长度的下一次幂，并用`trapz`在频带内积分。Relative theta、alpha和beta power均以1–45 Hz总Welch功率为分母。证据：`D:\Lucas\Desktop\More-is-not-always-better\matlab\eeg_bandpower_pipeline\run_eeg_bandpower_pipeline.m`、`E:\26\补\数据分析结果\teacher_runs\teacher_onset_20260802\eeg_onset_export_stdout_02.log`及其scene-level输出。

### 3. 可以保留的Methods陈述

- `.easy`格式导入EEGLAB，但必须说明这是由participant dataset history验证，实际原始`.easy`未归档。
- EEGLAB版本2025.1.0。
- 采样率500 Hz。
- 8个通道：F3、F4、P3、Pz、P4、O1、Oz和O2。
- 0.5–40 Hz band-pass filtering。
- 49–51 Hz band-stop filtering，`revfilt=1`。
- Average re-referencing。
- EEGLAB `runica`实现的extended Infomax ICA，`extended=1`、`pca=7`。
- Scene viewing由marker `7`至marker `8`界定。
- Welch PSD频带积分；relative band power以1–45 Hz总Welch功率为分母。

上述证据来自`E:\26\补\脑电数据\*.set`及`E:\26\补\脑电数据\eeg_clock_cache\eeg_set_metadata.csv`。

### 4. 必须删除或降级的Methods陈述

必须删除：artifact-related independent components已识别并删除；bad-channel removal/interpolation；bad-segment rejection；具体ICLabel阈值、artifact类型或被删除component数量。Scene marker 7/8、Welch PSD及1–45 Hz denominator已有代码和运行证据，不再列为Unsupported。

必须修改：

- “notch-filtered at 50 Hz”改为“49–51 Hz band-stop filtering”。
- 如原稿声称所有participant采用完全相同的滤波执行顺序，必须修改。
- 当前Methods中的relative-power denominator 1–30 Hz必须改为1–45 Hz。实际MATLAB代码定义`totalBand40=[1 45]`，并以该`total_1_45`计算所有ROI的relative theta、alpha和beta power；历史运行提交`ce80f1f1694cf7f136b90724321cf1634c8c28ae`包含相同实现。2026-08-02成功运行日志、scene-level输出、2026-08-04正式分析配置及下游输入SHA-256共同验证该口径。代码中虽保留未使用的`totalBand30=[1 30]`定义，但未参与relative-power计算。

### 5. 仍缺少的关键材料

- 实际原始`.easy`文件，特别是万泽恩、吴泽诚、郑世霖和黄柔倩；
- 实际运行的MATLAB/EEGLAB预处理脚本、运行日志及插件版本；
- participant-level bad-channel、插值和bad-segment记录；
- ICA component分类、编号、删除理由和`pop_subcomp`记录；
- ICLabel概率、阈值和版本；
- 独立于代码默认值的实验marker字典或采集协议文件；当前marker 7/8可由代码和运行snapshot验证，但缺少外部实验协议交叉核对；
- 2026-08-18更新后的`李泽豪.set`和`侯集瀚.set`尚未进入2026-08-02频谱导出及2026-08-04正式分析；若最终统计结果必须对应更新后的文件，需要重新运行频谱和下游分析；
- 更强的数值审计可补充逐trial保存的1–45 Hz total-power列或完整PSD谱，但这不影响当前对代码分母的Verified判断；
- 两处`.set`—`.fdt`文件名依赖修正或正式映射记录。

## 二、Methods证据矩阵

| Methods陈述 | 实际证据 | 实际参数 | 证据文件 | 证据等级 | 处理建议 |
|---|---|---|---|---|---|
| Band-pass filtering | 56/56 participant history均有`pop_eegfiltnew` | `locutoff=0.5`, `hicutoff=40` | `E:\26\补\脑电数据\*.set` | Verified | 保留 |
| Notch filtering | 56/56 participant history均有反向滤波 | `locutoff=49`, `hicutoff=51`, `revfilt=1` | `E:\26\补\脑电数据\*.set`；更新文件：`李泽豪.set`、`侯集瀚.set` | Verified | 修改为明确的49–51 Hz band-stop |
| Re-referencing | History命令及participant字段一致 | `pop_reref(EEG,[])`; `EEG.ref='average'` | `E:\26\补\脑电数据\*.set` | Verified | 保留 |
| ICA algorithm | History及实际ICA矩阵均存在 | `runica`; `extended=1`; `pca=7`; weights 7×8 | `E:\26\补\脑电数据\*.set` | Verified | 保留 |
| ICA component rejection | 无`pop_subcomp`、ICLabel或非零rejection标记 | `gcompreject=[0 0 0 0 0 0 0]` | `E:\26\补\脑电数据\*.set` | Unsupported | 删除 |
| Bad-channel handling | 无`pop_select`、`pop_interp`、`eeg_interp`或记录表 | 无可追溯参数 | `E:\26\补\脑电数据\*.set`；检索范围`E:\26\补\脑电数据` | Unsupported | 删除 |
| Bad-segment handling | 无`eeg_eegrej`、`pop_rej`、`clean_windows`或记录表 | 无可追溯参数 | `E:\26\补\脑电数据\*.set`；检索范围`E:\26\补\脑电数据` | Unsupported | 删除 |
| Scene segmentation | 代码、participant snapshot及实际导出一致 | start marker=`7`; end marker=`8` | `D:\Lucas\Desktop\More-is-not-always-better\matlab\eeg_bandpower_pipeline\run_eeg_bandpower_pipeline.m`; `E:\26\补\数据分析结果\teacher_runs\teacher_onset_20260802\00_eeg_raw_export` | Verified | 保留 |
| PSD estimator | 代码实现及成功运行日志可追溯 | MATLAB `pwelch`; ≤2-s window; 50% overlap; next-power-of-two `nfft`; `trapz` integration | 同上代码；`E:\26\补\数据分析结果\teacher_runs\teacher_onset_20260802\eeg_onset_export_stdout_02.log` | Verified | 保留 |
| Relative-power denominator | 运行版本代码以`total_1_45`计算relative power；配置、报告和输入哈希闭环 | denominator=`1–45 Hz`; `band power / total_1_45` | 上述MATLAB代码；`teacher_analysis.parallel.json`; `22_eeg_methods_report.md`; `06_eeg_primary\input_hashes.json` | Verified | 将1–30 Hz修改为1–45 Hz |

## 三、可直接粘贴的英文Methods

适用版本为**版本B（证据不完整的透明版本）**。

> Continuous EEG recordings in `.easy` format were imported into EEGLAB (version 2025.1.0), as documented in the participant-level dataset histories. The archived recordings were sampled at 500 Hz from eight channels (F3, F4, P3, Pz, P4, O1, Oz and O2). All datasets underwent 0.5–40 Hz band-pass filtering and 49–51 Hz band-stop filtering for attenuation of line noise, followed by average re-referencing. The recorded order of the two filtering operations differed across participants: band-pass filtering preceded band-stop filtering in 54 datasets, whereas the reverse order was recorded in two datasets. Independent component decomposition was performed using the EEGLAB `runica` implementation of extended Infomax (`extended = 1`), with the decomposition restricted to seven dimensions (`pca = 7`). Corresponding ICA weight, sphere and inverse-weight matrices were retained in all participant files. However, the archived histories and metadata contained no traceable records of bad-channel handling, bad-segment rejection, independent-component classification or component subtraction; these procedures are therefore not claimed. Scene-viewing segments were delimited by marker 7 at onset and marker 8 at offset. Power spectral density was estimated using MATLAB `pwelch`, with a window length of up to 2 s, 50% overlap and an FFT length set to the next power of two at least as long as the window; band power was obtained by trapezoidal integration of the power spectral density. Relative band power was calculated by dividing band-specific Welch power by total Welch power integrated over 1–45 Hz.

## 四、需要从原稿删除或修改的具体句子

1. **“Raw recordings were band-pass filtered between 0.5 and 40 Hz.” — 修改。**  
   改为：“The imported continuous EEG recordings were band-pass filtered from 0.5 to 40 Hz.”
2. **“The data were notch-filtered at 50 Hz.” — 修改。**  
   改为：“Line noise was attenuated using a 49–51 Hz band-stop filter.”
3. **“The signals were average re-referenced.” — 保留。**  
   规范写法：“The signals were re-referenced to the average of the recorded channels.”
4. **“ICA was performed using extended Infomax.” — 保留并补全参数。**  
   规范写法：“Independent component decomposition was performed using the EEGLAB `runica` implementation of extended Infomax (`extended = 1`), with dimensionality restricted to seven components (`pca = 7`).”
5. **“Artifact-related components were identified and removed.” — 删除。**  
   当前材料无component分类、编号、ICLabel结果或`pop_subcomp`证据。
6. **“Relative power was normalized to total power from 1 to 30 Hz.” — 修改。**  
   改为：“Relative band power was calculated by dividing band-specific Welch power by total Welch power integrated over 1–45 Hz.”

## 五、Limitations文字

> Although participant-level EEGLAB histories and the archived analysis repository documented filtering, average re-referencing, extended Infomax decomposition, scene segmentation and Welch spectral extraction, the materials did not retain the original `.easy` recordings, bad-channel or bad-segment logs, or component-level artifact-classification and subtraction records. In addition, the archived spectral outputs were generated before the 18 August 2026 updates to two participant `.set` files and therefore do not establish whether those updates would alter the reported numerical results.

## 六、最终决定

- Filtering：**保留**
- Notch：**修改**
- Re-referencing：**保留**
- ICA：**保留**
- ICA component rejection：**删除**
- Relative-power denominator：**将1–30 Hz修改为1–45 Hz；1–45 Hz已由代码、运行配置、成功日志和实际输出验证**

## 审计边界

本报告不根据一般EEG处理惯例推断步骤是否执行。Verified仅用于实际participant `.set`字段、内嵌EEGLAB history，或能够通过版本化代码、运行配置、成功日志、实际输出和输入哈希形成可追溯闭环的步骤；Unsupported表示当前归档材料无法追溯，不等同于证明该步骤从未执行。1–45 Hz denominator属于前者。需要注意，2026-08-02至04日的归档分析早于2026-08-18对李泽豪和侯集瀚`.set`的更新。
