"""Make reader-facing reports portable without changing archived evidence."""
import csv, hashlib, io, os, re
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):
    return re.sub(r'/+', '/', s.replace('\\', '/')).rstrip('/')
master = ROOT / '03_清单与核验/CRITICAL_FILE_MANIFEST.csv'
rows = list(csv.DictReader(master.open(encoding='utf-8-sig', newline='')))
mapping = {}
for row in rows:
    src, dst = norm(row['source_file']), norm(row['evidence_file'])
    if dst and Path(dst).is_file():
        mapping[src.casefold()] = Path(dst)
raw_hashes = {p: digest(p) for p in (ROOT/'evidence').rglob('*') if p.is_file()}
root_norm = norm(str(ROOT))
prefixes = [
    (root_norm, ''),
    ('E:/26/补/数据分析结果/teacher_runs/teacher_parallel_20260804', 'teacher_parallel_20260804'),
    ('E:/26/补/数据分析结果/teacher_runs/teacher_onset_20260802', 'teacher_onset_20260802'),
    ('D:/Lucas/Desktop/More-is-not-always-better', '代码仓库'),
    ('E:/26/补/yyd/结果发送', '结果交付包'),
    ('E:/26/补/数据分析结果', '分析结果'),
    ('E:/26/补/yyd', '交付归档'),
]
def portable(s):
    s = norm(s)
    for prefix, label in prefixes:
        if s.casefold().startswith(prefix.casefold()):
            return label + s[len(prefix):]
    return s.rsplit('/', 1)[-1]
def target(s):
    s = norm(unquote(s))
    p = mapping.get(s.casefold())
    if p:
        return p
    if s.casefold().startswith(root_norm.casefold()) and Path(s).exists():
        return Path(s)
    if '/.codex/sessions/' in s:
        return ROOT/'evidence/history_excerpts.json'
    return None
drive = re.compile(r'[A-Za-z]:[\\/][^`\s"<>|；，。)\]]+')
def clean_text(s):
    return drive.sub(lambda m: portable(m.group()), s)

mds = [ROOT/'EEG核查总报告_0906.md', *(ROOT/'01_专题说明').glob('*.md'), *(ROOT/'03_清单与核验').glob('*.md')]
for p in mds:
    s = p.read_text(encoding='utf-8-sig')
    def link(m):
        label, url = m.groups()
        dest = target(url)
        if dest:
            rel = Path(os.path.relpath(dest, p.parent)).as_posix()
            return f'[{label}]({rel})'
        return f'`{label}`（来源标识：{portable(url)}）'
    s = re.sub(r'\[([^\]]+)\]\(([A-Za-z]:[\\/][^\n]*?)\)(?=；|\s|[。，]|$)', link, s)
    s = re.sub(r'；Git：`[^`]*`；mtime UTC：`[^`]*`；SHA-256：`[^`]*`', '', s)
    s = re.sub(r'。交付目录：`[^`]+`。', '。', s)
    s = '\n'.join(line for line in s.split('\n') if not re.match(r'\| (outputs_root|resolved run directory) \|', line))
    s = s.replace('每项来源绝对路径、mtime UTC、SHA-256、证据副本及已知Git版本', '每项来源标识、mtime UTC、SHA-256、包内证据副本及已知Git版本')
    s = re.sub(r'按用户确认，仅以 .*?不预设审阅方描述一定正确。', '已扩展检查两处主要分析结果与交付归档，追查核查问题所述分析对应的实际产物。', s)
    s = re.sub(r'所谓新增18-outcome模型所需的另外5个log10 outcomes.*?写成已运行事实。', '在本次已识别模型表的outcome字段中，尚未找到另外5个log10 absolute outcomes。因此，**目前尚未把核查问题中提及的18个结局、72个模型对应到具体原始输出；这不证明该分析不存在，也不足以判断相关表述有误。** 上表仅列出了已定位的几类产物，不能据此排除另有汇总表、补充分析或生成报告的步骤。', s)
    s = re.sub(r'这不是要求用户继续寻找一个理应存在的文件.*?补历史。', '**该计数有明确的分析结构依据：3个ROI（额、顶、枕）×3个频段（theta、alpha、beta）×2种尺度=18个结局；18×4个窗口=72个模型。** 已有输入含9个relative和9个absolute指标，但输入具备这些字段，不等于18个结局均完成了指定模型和校正。该说法可能依据已有结果或汇总，具体出处仍待对应；两个72项检验族、全部模型收敛及新增alpha校正结论，需以相应输出核实。是否补跑应由最终分析范围和现有输出覆盖情况决定。', s)
    if '## 问题1 实际代码版本' in s:
        s = s.replace('## 问题1 实际代码版本 — PARTIALLY CONFIRMED', '## 问题1 实际代码版本 — PARTIALLY CONFIRMED\n\n最终交付采用固定的最新仓库提交运行并归档；以下版本差异仅说明历史溯源，不再将证明8月4日工作区与5174929完全一致作为最终交付的前提。本报告仍为已有材料核查，尚未执行最新版本重跑。')
        s = s.replace('对论文：软件归档版本可以列5174929，同时说明run manifest记录ce80f1f且执行时含未提交改动；不要声称5174929已经端到端复现8月4日结果。', '对论文：最终软件版本应填写实际生成最终结果的固定提交，并与运行记录一致。5174929仅用于本次历史核查，不能替代尚未完成的最终运行版本记录。')
    s = clean_text(s)
    p.write_text(s, encoding='utf-8')

numeric_checks = 0
for folder in ['02_数据表', '03_清单与核验']:
    for p in (ROOT/folder).glob('*.csv'):
        if p.name == 'DELIVERABLE_MANIFEST.csv':
            continue
        with p.open(encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            fields, records = reader.fieldnames, list(reader)
        original = [dict(r) for r in records]
        for row in records:
            for key, val in row.items():
                if val and re.search(r'[A-Za-z]:[\\/]', val):
                    dest = target(val)
                    row[key] = dest.relative_to(ROOT).as_posix() if dest else clean_text(val)
        for a, b in zip(original, records):
            for key, val in a.items():
                if val and re.fullmatch(r'[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?', val):
                    assert b[key] == val, (p, key)
                    numeric_checks += 1
        with p.open('w', encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader(); w.writerows(records)

for p in mds:
    assert not re.search(r'[A-Za-z]:[\\/]', p.read_text(encoding='utf-8')), p
links = 0
for p in mds:
    for url in re.findall(r'\]\(([^\n]+?)\)', p.read_text(encoding='utf-8')):
        if '://' in url or url.startswith('#'):
            continue
        assert (p.parent/unquote(url.split('#')[0])).exists(), (p, url)
        links += 1
assert all(digest(p) == h for p, h in raw_hashes.items())
qa = ROOT/'03_清单与核验/AUDIT_QA.md'
with qa.open('a', encoding='utf-8') as f:
    f.write(f'\n\n## 交付可移植性更新\n\n- 主报告及专题说明已移除本机绝对路径，证据链接改为包内相对链接。\n- 已验证{links}个文档链接；{numeric_checks}个数字字段保持原字符串精度。\n- {len(raw_hashes)}份原始证据文件SHA-256保持不变；本次未重新运行统计模型。\n- 修正18结局/72模型的措辞：尚未对应具体输出，不据此判断相关表述有误。\n- 数据表和来源清单中的证据路径以交付包根目录为基准；仅有来源标识的条目不表示已附完整原文件。\n')
manifest = ROOT/'03_清单与核验/DELIVERABLE_MANIFEST.csv'
with manifest.open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f); w.writerow(['relative_path','bytes','sha256'])
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p != manifest:
            w.writerow([p.relative_to(ROOT).as_posix(),p.stat().st_size,digest(p)])
print({'markdown_files':len(mds),'valid_links':links,'numeric_fields_unchanged':numeric_checks,'evidence_files_unchanged':len(raw_hashes)})
