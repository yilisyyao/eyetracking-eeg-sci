from pathlib import Path
import json
out=Path('E:/26/补/yyd/0906/evidence');events=[];calls=[]
for day in ['02','03','09']:
 for p in Path('C:/Users/Lucas/.codex/sessions/2026/08',day).glob('*.jsonl'):
  for i,l in enumerate(p.open(encoding='utf-8'),1):
   d=json.loads(l);q=d.get('payload',{});ts=d.get('timestamp','')
   if d.get('type')=='event_msg' and q.get('type')=='patch_apply_end' and q.get('success'):
    for file,change in q.get('changes',{}).items():
     if 'More-is-not-always-better' in file:events.append(dict(source_file=str(p),source_line=i,timestamp=ts,changed_file=file,change=change))
   if d.get('type')=='response_item' and q.get('type') in ['custom_tool_call','function_call']:
    t=q.get('input',q.get('arguments',''))
    if any(x in t for x in ['teacher_analysis.parallel.json','teacher_parallel_20260804','run_eeg_from_raw.py','git diff --','git diff --stat']):calls.append(dict(source_file=str(p),source_line=i,timestamp=ts,tool=q.get('name'),text=t))
(out/'historical_repo_patch_events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'historical_run_tool_calls.json').write_text(json.dumps(calls,ensure_ascii=False,indent=2),encoding='utf-8')
for d in events:
 if '2026-08-04T14:35' < d['timestamp'] < '2026-08-09T09:36:46Z' and any(t in d['changed_file'] for t in ['eeg.py','complete.py','onset','eeg_order','eeg_primary','common.R']): print(d['timestamp'],d['source_line'],d['changed_file'])
print('patch events',len(events),'run tool calls',len(calls))
