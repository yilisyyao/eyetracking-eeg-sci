import pandas as pd, json, zipfile, io, re
from pathlib import Path
OUT=Path('E:/26/补/yyd/0906');EV=OUT/'evidence';DATA=Path('E:/26/补/数据分析结果');RUN=DATA/'teacher_runs/teacher_parallel_20260804';OLD=DATA/'teacher_runs/teacher_onset_20260802';REPO=Path('D:/Lucas/Desktop/More-is-not-always-better')
def save(name,obj):
 (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str),encoding='utf-8')

# Only read existing tables; no model fit, p/q calculation or confidence-interval calculation.
summaries=[];keys=[];temporal=[];conditions=[]
for trim in [0,5,10,15]:
 base=RUN/f'06_eeg_primary/onset_window_models/trim_{trim}s'
 inp=pd.read_csv(base/'eeg_onset_order_model_input.csv',keep_default_na=False)
 mask=inp.PreviousWWR.eq('');first=inp.PositionWithinBlock.eq(1)
 needed=['Participant','WWR','Complexity','ExperienceGroup','Gender','Block','PositionWithinBlockCentered','OrderGroup','PreviousWWR','PreviousComplexity','O_theta_relative','F_theta_relative','O_alpha_relative','O_beta_relative']
 # R read.csv keeps blank character values as valid factor levels, including the C0 reference.
 complete=inp.loc[inp.PositionWithinBlock.gt(1)].dropna(subset=needed)
 k=set(zip(inp.Participant.astype(str),inp.GlobalTrialOrder.astype(str)));keys.append(k)
 summaries.append(dict(onset_trim_s=trim,participants=inp.Participant.nunique(),trials=len(inp),missing_previous_wwr=int(mask.sum()),missing_equals_first_position=bool(mask.equals(first)),missing_round1=int((mask & inp.Block.eq(1)).sum()),missing_round2=int((mask & inp.Block.eq(2)).sum()),complete_participants=complete.Participant.nunique(),complete_trials=len(complete),all_other_predictors_complete=bool(inp.loc[~first,needed].notna().all().all()),source_file=str(base/'eeg_onset_order_model_input.csv')))
 cr=pd.read_csv(base/'eeg_cr2_robust_results.csv',dtype=str)
 selected=cr.loc[cr.model.eq('Model1') & cr.term.isin(['Block','PositionWithinBlockCentered'])].copy()
 for _,row in selected.iterrows():
  temporal.append(dict(scale='relative_power',outcome=row.outcome,temporal_predictor=row.term,onset_trim_s=trim,beta=row['estimate'],CR2_SE=row['std.error'],CI_low='',CI_high='',raw_p=row['p.value'],within_q='',joint_q='',n_participants=inp.Participant.nunique(),n_trials=len(inp),source_file=str(base/'eeg_cr2_robust_results.csv'),model='Model1',source_status='ORIGINAL_0805_CORE_ONLY_NOT_FINAL_18_OUTCOME_TEMPORAL_AUDIT',missing_reason='CR2 source does not export CI or temporal BH q; not recomputed in read-only audit'))
 cond=cr.loc[cr.model.eq('Model1') & cr.term.str.startswith(('WWR','Complexity','ExperienceGroup'))].copy()
 cond['onset_trim_s']=trim;cond['source_file']=str(base/'eeg_cr2_robust_results.csv');conditions.append(cond)
pd.DataFrame(summaries).to_csv(OUT/'PREVIOUS_SCENE_SAMPLE_COUNTS.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(temporal).to_csv(OUT/'TEMPORAL_EEG_SOURCE_OF_TRUTH.csv',index=False,encoding='utf-8-sig')
c=pd.concat(conditions);c.to_csv(OUT/'CORE_144_EXISTING_CR2_COEFFICIENTS.csv',index=False,encoding='utf-8-sig')
prev=pd.read_csv(RUN/'07_reviewer_analysis/Reviewer1_parallel_previous_scene_FDR.csv',dtype=str)
prev.to_csv(OUT/'PREVIOUS_SCENE_EXISTING_48_COEFFICIENTS.csv',index=False,encoding='utf-8-sig')
gee=pd.read_csv(RUN/'00_eeg_onset_statistics/onset_variant_model_results.csv',dtype=str)
g=gee.loc[gee.sample_strategy.eq('parallel_common_qc')]
save('evidence/table_checks.json',dict(samples=summaries,all_four_trial_keys_identical=all(x==keys[0] for x in keys),core_conditions_rows=len(c),core_terms=sorted(c.term.unique()),core_outcomes=sorted(c.outcome.unique()),temporal_extracted=len(temporal),previous_rows=len(prev),previous_per_window=prev.groupby('onset_trim_s').size().to_dict(),gee_common_rows=len(g),gee_model_types=g.model_type.unique().tolist(),gee_terms=g.term.unique().tolist(),gee_n=g[['n_obs','n_subjects']].drop_duplicates().to_dict('records')))
# Inventory actual EEG tables in both deliveries and compare historical ZIP payloads byte-for-byte.
inv=[]; zip_entries={}
for label,path in [('0803',Path('E:/26/补/yyd/数据分析结果包-0803-.zip')),('0805',Path('E:/26/补/yyd/数据分析结果包-0805.zip'))]:
 with zipfile.ZipFile(path) as z:
  zdict={}
  for n in z.namelist():
   if n.endswith('/') :continue
   b=z.read(n);base=Path(n).name; canonical=base.split('__',1)[-1]
   zdict[canonical]={'entry':n,'sha256':__import__('hashlib').sha256(b).hexdigest()}
   if ('eeg' in n.lower() or 'onset' in n.lower()) and n.endswith('.csv'):
    try:
     d=pd.read_csv(io.BytesIO(b));inv.append(dict(package=label,entry=n,rows=len(d),columns=';'.join(d.columns),outcomes=';'.join(map(str,d.outcome.unique())) if 'outcome' in d else '',model_types=';'.join(map(str,d.model_type.unique())) if 'model_type' in d else ''))
    except Exception as e:inv.append(dict(package=label,entry=n,error=str(e)))
  zip_entries[label]=zdict
pd.DataFrame(inv).to_csv(OUT/'evidence/PACKAGE_EEG_TABLE_INVENTORY.csv',index=False,encoding='utf-8-sig')
comparisons=[]
for n,x in zip_entries['0805'].items():
 old=zip_entries['0803'].get(n)
 comparisons.append(dict(canonical_file=n,entry_0805=x['entry'],sha256_0805=x['sha256'],entry_0803=old['entry'] if old else '',sha256_0803=old['sha256'] if old else '',comparison=('IDENTICAL' if old['sha256']==x['sha256'] else 'CHANGED') if old else 'ADDED'))
pd.DataFrame(comparisons).to_csv(OUT/'evidence/PACKAGE_0803_0805_COMPARISON.csv',index=False,encoding='utf-8-sig')
print(json.dumps(json.loads((OUT/'evidence/table_checks.json').read_text(encoding='utf-8')),ensure_ascii=False))
