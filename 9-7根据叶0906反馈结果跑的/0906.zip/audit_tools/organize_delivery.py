"""Reorganize this audit delivery only; never touch source analysis directories."""
from pathlib import Path
import csv,hashlib,json,re,os,datetime

ROOT=Path('E:/26/补/yyd/0906').resolve()
DETAIL=ROOT/'01_专题说明'
TABLES=ROOT/'02_数据表'
INDEX=ROOT/'03_清单与核验'
REPORT=ROOT/'EEG核查总报告_0906.md'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8388608),b''):h.update(b)
 return h.hexdigest()
def within(p):
 p=p.resolve()
 if not p.is_relative_to(ROOT):raise ValueError(f'Outside delivery: {p}')
 return p
if REPORT.exists():raise RuntimeError('Organized report already exists; refusing to overwrite.')
before={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file()}
source={p.name:p.read_text(encoding='utf-8') for p in ROOT.glob('*.md')}
mapping={}
for p in ROOT.iterdir():
 if not p.is_file():continue
 if p.name in ['CRITICAL_FILE_MANIFEST.csv','SCRIPT_OUTPUT_MAP.csv','AUDIT_QA.md','DELIVERABLE_MANIFEST.csv']:
  dest=INDEX/('整理前文件清单.csv' if p.name=='DELIVERABLE_MANIFEST.csv' else p.name)
 elif p.suffix.lower()=='.md':dest=DETAIL/p.name
 elif p.suffix.lower()=='.csv':dest=TABLES/p.name
 else:raise RuntimeError(f'Unclassified top-level file: {p}')
 mapping[p.name]=within(dest)
for d in [DETAIL,TABLES,INDEX]:within(d).mkdir(exist_ok=True)
for name,dest in mapping.items():
 old=within(ROOT/name)
 if dest.exists():raise RuntimeError(f'Destination exists: {dest}')
 old.rename(dest)

def relpath(target,parent):return os.path.relpath(target,parent).replace('\\','/')
def references(text,parent):
 # Update generated report references only; evidence source copies remain untouched.
 for name,dest in sorted(mapping.items(),key=lambda x:-len(x[0])):
  label=name
  link=f'[{label}]({relpath(dest,parent)})'
  text=text.replace('`'+name+'`',link)
  text=text.replace('('+str(ROOT/name).replace('\\','/')+')','('+relpath(dest,parent)+')')
 if parent!=ROOT:
  text=re.sub(r'(?<![\w/\\])evidence/',relpath(ROOT/'evidence',parent)+'/',text)
 return text

main=source['FINAL_TEACHER_PARALLEL_PROVENANCE.md'].split('\n',1)[1]
technical=source['NEW_EEG_TECHNICAL_CHECKS_20260906.md']
technical=technical[technical.index('## Q1 '):]
technical=technical.split('## 对两个主要结果目录的扩展核查')[0]
technical=technical.replace('\n## ','\n### ')
if technical.startswith('## '):technical='#'+technical
intro='''# EEG核查总报告｜2026-09-06

**本报告回答的是：逐题回答哪些事实已确认、证据在哪里，以及这些事实允许3.3和Methods怎样表述。以实际保存的代码与结果为准，核查清单中的说法也接受检验。**

本文件是唯一主阅读入口，汇总原9项溯源问题、增补6项技术问题，并附重写3.3最关键的两项详细证据。专题文件和机器结果表放在附件目录，通常无需逐个打开。

## 文件夹怎么用

| 位置 | 用途 |
| --- | --- |
| 本文件 | 供审阅的完整核查报告 |
| [01_专题说明](01_专题说明) | 单项问题的详细说明、配置对照及上一轮分项报告 |
| [02_数据表](02_数据表) | 144项、324项、48项、temporal系数与样本计数的已有结果摘录 |
| [03_清单与核验](03_清单与核验) | 脚本—输出对应、来源哈希、质量核验与整理后文件总清单 |
| [evidence](evidence) | 原样配置、日志、结果源表、历史记录和指定Git提交的完整代码ZIP |
| [audit_tools](audit_tools) | 本次审计的生成、读取及核验脚本归档；原脚本使用整理前布局，执行前应按当前目录调整路径 |

## 一、原9项代码与分析溯源核查
'''
appendices=[]
for title,name in [('三、重写3.3重点附录A：四窗口决策时间线','EEG_WINDOW_HISTORY.md'),('四、重写3.3重点附录B：144项与324项的含义','ANALYSIS_FAMILY_144_VS_324.md')]:
 body=source[name].split('\n',1)[1].replace('\n## ','\n### ')
 appendices.append('## '+title+'\n'+body)
combined=intro+main+'\n\n## 二、增补6项技术核查\n\n'+technical+'\n\n'+'\n\n'.join(appendices)
combined=references(combined,ROOT)
combined+='\n\n## 五、交付核验\n\n原审计的15项交付检查全部通过；本次仅重组报告与附件路径，没有新增统计计算。目录重组校验与整理后的完整文件哈希见 [核验记录](03_清单与核验/AUDIT_QA.md) 和 [文件总清单](03_清单与核验/DELIVERABLE_MANIFEST.csv)。\n'
REPORT.write_text(combined,encoding='utf-8')
for name,dest in mapping.items():
 if dest.suffix=='.md':
  old=source[name]
  if name=='README_先看这里.md':old='''# 分项材料说明

主阅读入口已合并为 [EEG核查总报告_0906.md](../EEG核查总报告_0906.md)。本目录保留分项说明，供需要核对单个问题时查阅。所有正式结论与状态以总报告为入口。
'''
  dest.write_text(references(old,dest.parent),encoding='utf-8')
# The script-output map is generated metadata, so update only relocated output paths.
p=mapping['SCRIPT_OUTPUT_MAP.csv']
with p.open(encoding='utf-8-sig',newline='') as f:
 reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
for row in rows:
 for k,v in row.items():
  if not isinstance(v,str):continue
  for name,dest in mapping.items():
   for old in [str(ROOT/name),str(ROOT/name).replace('\\','/')]:v=v.replace(old,str(dest))
  row[k]=v
with p.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

preserved=[]
for old,hashvalue in before.items():
 p=ROOT/old
 if old in mapping:p=mapping[old]
 editable=(p.suffix=='.md' and p.parent in [DETAIL,INDEX]) or p.name=='SCRIPT_OUTPUT_MAP.csv'
 if not editable and p.name!='organize_delivery.py':
  if not p.is_file() or sha(p)!=hashvalue:raise RuntimeError(f'Content changed unexpectedly: {p}')
  preserved.append(str(p.relative_to(ROOT)))
# Validate the combined report's local Markdown links, including original external sources.
bad=[];checked=0
for target in re.findall(r'\]\(([^)]+)\)',combined):
 target=target.strip('<>')
 if target.startswith(('https:','http:','#')):continue
 target=re.sub(r':\d+$','',target)
 p=Path(target) if re.match(r'^[A-Za-z]:[/\\]',target) else ROOT/target
 checked+=1
 if not p.exists() and p != INDEX/'DELIVERABLE_MANIFEST.csv':bad.append(target)
if bad:raise RuntimeError(f'Broken report links: {bad}')
top=[p for p in ROOT.iterdir() if p.is_file()]
assert top==[REPORT],top
qa=mapping['AUDIT_QA.md']
with qa.open('a',encoding='utf-8') as f:
 f.write(f'''\n## 目录与报告归并核验

- 顶层仅1份MD总报告：PASS。
- 原9项问题与增补Q1–Q6已并入总报告：PASS。
- 四窗口历史、144/324详细分析已纳入总报告附录：PASS。
- {len(preserved)}个不应改动的文件移动后内容哈希一致，包括全部evidence副本和结果摘录：PASS。
- 总报告{checked}处本地链接均可定位：PASS。
- 原分析目录、代码仓库和统计结果未改动：本次操作仅限0906交付目录。

旧的DELIVERABLE_MANIFEST.csv作为“整理前文件清单.csv”保留；整理后的清单为本目录DELIVERABLE_MANIFEST.csv。审计脚本按执行时版本保留，记录的是整理前文件布局。
''')
record=dict(top_report=REPORT.name,local_links_checked=checked,unchanged_files=len(preserved),moved={name:str(dest.relative_to(ROOT)).replace('\\','/') for name,dest in mapping.items()},timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(INDEX/'目录整理记录.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
entries=[]
manifest=INDEX/'DELIVERABLE_MANIFEST.csv'
for p in sorted(ROOT.rglob('*')):
 if p.is_file() and p!=manifest:entries.append(dict(relative_path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
with manifest.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['relative_path','bytes','sha256']);w.writeheader();w.writerows(entries)
print(json.dumps(dict(report=str(REPORT),top_files=[p.name for p in top],unchanged_files=len(preserved),verified_links=checked,manifest_entries=len(entries)),ensure_ascii=False))
