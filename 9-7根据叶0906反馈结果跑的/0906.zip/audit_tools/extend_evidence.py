from pathlib import Path
import json,hashlib,datetime,shutil,subprocess,re
import pandas as pd
OUT=Path('E:/26/补/yyd/0906');EV=OUT/'evidence';REPO=Path('D:/Lucas/Desktop/More-is-not-always-better');DATA=Path('E:/26/补/数据分析结果');RUN=DATA/'teacher_runs/teacher_parallel_20260804';OLD=DATA/'teacher_runs/teacher_onset_20260802'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
manifest=pd.read_csv(OUT/'CRITICAL_FILE_MANIFEST.csv',keep_default_na=False).to_dict('records')
def add(p,rel,commit='UNRESOLVED'):
 if not p.is_file():return
 s=p.stat();q=EV/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 manifest.append(dict(source_file=str(p.resolve()),bytes=s.st_size,mtime_utc=datetime.datetime.fromtimestamp(s.st_mtime,datetime.timezone.utc).isoformat(),sha256=sha(p),evidence_file=str(q),git_commit=commit))
for p in [DATA/'README_当前有效结果.md',Path('E:/26/补/yyd/结果发送/0805_原始交付/数据来源交接说明-0805.md'),Path('E:/26/补/yyd/结果发送/数据来源交接说明-0809.md')]:add(p,Path('handoff_docs')/p.name)
for s in ['src/paper_analysis/teacher/contracts.py','src/paper_analysis/eeg/pipeline.py','analysis/r/eeg_crossmodal_analysis.R','scripts/portable_rscript.cmd']:
 add(REPO/s,Path('code_HEAD')/s,'185cb077b8a53de7447e562ff754dbd27dc56ad9')
 for rev in ['ce80f1f','5174929']:
  proc=subprocess.run(['git','-C',str(REPO),'show',rev+':'+s],capture_output=True)
  if proc.returncode==0:
   p=EV/('code_'+rev)/s;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(proc.stdout)
for p in (OLD/'00_eeg_trial_qc').glob('*.csv'):add(p,Path('onset_trial_qc')/p.name)
for p in (OLD/'00_eeg_raw_export/summary').glob('*.csv'):add(p,Path('raw_export_summary')/p.name)
source_docs=Path('D:/AAA所有应用/xwechat_files/wxid_265drasbkil222_be9e/temp/RWTemp/2026-09/633d3216d9472b08bb832a6116c9b74f')
for p in source_docs.glob('*'):
 if p.suffix.lower() in ['.md','.txt']:add(p,Path('request_documents')/p.name)
hashchecks=[]
for folder in ['05_eeg_order','06_eeg_primary']:
 for d in json.loads((RUN/folder/'input_hashes.json').read_text(encoding='utf-8-sig')):
  p=Path(d['path']);actual=sha(p) if p.is_file() else ''
  hashchecks.append(dict(manifest=str(RUN/folder/'input_hashes.json'),input_file=str(p),recorded_sha256=d.get('sha256'),current_sha256=actual,matches=actual==d.get('sha256')))
pd.DataFrame(hashchecks).to_csv(EV/'INPUT_HASH_VERIFICATION.csv',index=False,encoding='utf-8-sig')
archive=[]
for name,s in [('27_eeg_primary_analysis.R','analysis/r/eeg_primary_analysis.R'),('28_eeg_robustness_analysis.R','analysis/r/eeg_primary_analysis.R'),('29_eeg_crossmodal_analysis.R','analysis/r/eeg_crossmodal_analysis.R')]:
 p=RUN/'06_eeg_primary'/name
 for rev in ['ce80f1f','5174929']:
  b=subprocess.check_output(['git','-C',str(REPO),'show',rev+':'+s])
  archive.append(dict(run_file=str(p),repo_file=s,commit=rev,run_sha256=sha(p),git_blob_content_sha256=hashlib.sha256(b).hexdigest(),byte_identical=p.read_bytes()==b))
pd.DataFrame(archive).to_csv(EV/'ARCHIVED_R_CODE_COMPARISON.csv',index=False,encoding='utf-8-sig')
hist=json.loads((EV/'current_set_history.json').read_text(encoding='utf-8'));histchecks=[]
for d in hist:
 h=d['history'];p=Path(d['source_file']);flat=re.sub(r'\s+','',h)
 histchecks.append(dict(source_file=str(p),has_bandpass_0_5_40="'locutoff',0.5,'hicutoff',40" in flat,has_notch_49_51="'locutoff',49,'hicutoff',51,'revfilt',1" in flat,has_average_reref='pop_reref(EEG,[])' in flat,has_runica='pop_runica' in flat,has_subcomp='pop_subcomp' in flat,datfile=d.get('datfile'),mtime_after_0804=p.stat().st_mtime>datetime.datetime(2026,8,4,23,59,tzinfo=datetime.timezone.utc).timestamp(),srate=d.get('srate'),nbchan=d.get('nbchan')))
pd.DataFrame(histchecks).to_csv(EV/'CURRENT_SET_HISTORY_CHECKS.csv',index=False,encoding='utf-8-sig')
gee=pd.read_csv(RUN/'00_eeg_onset_statistics/onset_variant_model_results.csv',dtype=str)
terms=gee.term.str.contains(r'C\((WWR|Complexity|ExperienceGroup)\)',regex=True)
sub=gee.loc[gee.sample_strategy.eq('parallel_common_qc') & terms].copy()
sub['source_file']=str(RUN/'00_eeg_onset_statistics/onset_variant_model_results.csv');sub['audit_note']='Existing Gaussian GEE on bare absolute-power aliases; extracted 324 rows inherit 117/468-test q, not recomputed 324-test q and not relative-power CR2 Model1.'
sub.to_csv(OUT/'BROADER_324_EXISTING_GEE_COEFFICIENTS.csv',index=False,encoding='utf-8-sig')
assert len(sub)==324
raw=pd.read_csv(OLD/'00_eeg_trial_qc/eeg_onset_sensitivity_trial_long.csv')
scalechecks={}
for roi in ['F','P','O']:
 for band in ['theta','alpha','beta']:
  base=f'{roi}_{band}';scalechecks[base]=bool(raw[base].equals(raw[base+'_absolute']))
(EV/'ADDITIONAL_CHECKS.json').write_text(json.dumps(dict(input_hashes=hashchecks,history_counts={k:sum(d[k] for d in histchecks) for k in ['has_bandpass_0_5_40','has_notch_49_51','has_average_reref','has_runica','has_subcomp','mtime_after_0804']},raw_bare_equals_absolute=scalechecks,broader_324_rows=len(sub)),ensure_ascii=False,indent=2),encoding='utf-8')
unique={d['source_file']:d for d in manifest}
for i,d in enumerate(unique.values(),1):d['evidence_id']=f'E{i:04}'
pd.DataFrame(unique.values()).to_csv(OUT/'CRITICAL_FILE_MANIFEST.csv',index=False,encoding='utf-8-sig')
print(json.dumps(dict(manifest_files=len(unique),input_hash_matches=[x['matches'] for x in hashchecks],set_history_counts={k:sum(d[k] for d in histchecks) for k in ['has_bandpass_0_5_40','has_notch_49_51','has_average_reref','has_runica','has_subcomp','mtime_after_0804']},bare_absolute=scalechecks),ensure_ascii=False))
