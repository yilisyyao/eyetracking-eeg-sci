from pathlib import Path
import json,hashlib,csv,subprocess,datetime,zipfile
import pandas as pd
OUT=Path('E:/26/补/yyd/0906');EV=OUT/'evidence';REPO=Path('D:/Lucas/Desktop/More-is-not-always-better')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8388608),b''):h.update(b)
 return h.hexdigest()
checks=[]
def check(name,value,detail=''):
 checks.append(dict(check=name,passed=bool(value),detail=detail))
required=['FINAL_TEACHER_PARALLEL_PROVENANCE.md','SCRIPT_OUTPUT_MAP.csv','CRITICAL_FILE_MANIFEST.csv','EEG_WINDOW_HISTORY.md','ANALYSIS_FAMILY_144_VS_324.md','PREVIOUS_SCENE_SAMPLE_CONFIRMATION.md','RELATIVE_POWER_DENOMINATOR_AUDIT.md','NEW_EEG_TECHNICAL_CHECKS_20260906.md','TEMPORAL_EEG_SOURCE_OF_TRUTH.csv','EEG_METHOD_DISCREPANCIES_20260906.md']
check('Two request documents: all 10 requested output files exist',all((OUT/x).is_file() for x in required))
m=pd.read_csv(OUT/'CRITICAL_FILE_MANIFEST.csv',keep_default_na=False).to_dict('records');m=list({d['source_file']:d for d in m}.values())
for p in [Path('E:/26/补/yyd/数据分析结果包-0803-.zip'),Path('E:/26/补/yyd/数据分析结果包-0805.zip')]:
 if not any(d['source_file']==str(p) for d in m):
  st=p.stat();m.append(dict(source_file=str(p),bytes=st.st_size,mtime_utc=datetime.datetime.fromtimestamp(st.st_mtime,datetime.timezone.utc).isoformat(),sha256=sha(p),evidence_file='',git_commit='NOT_APPLICABLE: original delivery ZIP',evidence_id='ZIP_'+('0803' if '0803' in p.name else '0805')))
pd.DataFrame(m).to_csv(OUT/'CRITICAL_FILE_MANIFEST.csv',index=False,encoding='utf-8-sig')
badsource=[];badcopy=[]
for d in m:
 p=Path(d['source_file'])
 if not p.is_file() or sha(p)!=d['sha256']:badsource.append(str(p))
 if d['evidence_file']:
  q=Path(d['evidence_file'])
  if not q.is_file() or sha(q)!=d['sha256']:badcopy.append(str(q))
check('Original critical source hashes unchanged during audit',not badsource,repr(badsource))
check('Evidence copies byte-identical to sources',not badcopy,repr(badcopy))
status=subprocess.check_output(['git','-C',str(REPO),'status','--porcelain=v1'])
(EV/'git_status_after.txt').write_bytes(status)
check('Repository status unchanged and clean',status==(EV/'git_status_before.txt').read_bytes()==b'')
with zipfile.ZipFile(EV/'code_5174929.zip') as z:
 check('5174929 code ZIP CRC integrity',z.testzip() is None)
 archive={n for n in z.namelist() if not n.endswith('/')}
 tracked=set(subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r','--name-only','5174929']).decode('utf-8').splitlines())
 check('Code ZIP contains complete tracked tree at 5174929',archive==tracked,f'ZIP={len(archive)}, Git={len(tracked)}')
temp=pd.read_csv(OUT/'TEMPORAL_EEG_SOURCE_OF_TRUTH.csv',dtype=str,keep_default_na=False)
check('Temporal extraction has 32 original core coefficients, not a fabricated 144-row audit',len(temp)==32 and temp[['outcome','onset_trim_s','temporal_predictor']].drop_duplicates().shape[0]==32)
check('Unavailable CR2 CI and temporal q remain blank',temp[['CI_low','CI_high','within_q','joint_q']].eq('').all().all())
exact=True
for _,r in temp.iterrows():
 src=pd.read_csv(r.source_file,dtype=str,keep_default_na=False);row=src.loc[src.model.eq('Model1') & src.outcome.eq(r.outcome) & src.term.eq(r.temporal_predictor)].iloc[0]
 exact &= all(row[a]==r[b] for a,b in [('estimate','beta'),('std.error','CR2_SE'),('p.value','raw_p')])
check('Every temporal beta/CR2 SE/raw p copied exactly from recorded source',exact)
core=pd.read_csv(OUT/'CORE_144_EXISTING_CR2_COEFFICIENTS.csv',dtype=str)
check('144 core rows have correct 4 x 9 x 4 structure and no newly computed q',len(core)==144 and core.outcome.nunique()==4 and core.term.nunique()==9 and core.onset_trim_s.nunique()==4 and not any('fdr' in c.lower() or 'bh' in c.lower() for c in core.columns))
broader=pd.read_csv(OUT/'BROADER_324_EXISTING_GEE_COEFFICIENTS.csv',dtype=str)
check('324 GEE extraction keeps actual model and scale boundary',len(broader)==324 and broader.model_type.eq('gee_gaussian_participant_clustered_robust').all() and broader.audit_note.str.contains('absolute').all())
prev=pd.read_csv(OUT/'PREVIOUS_SCENE_EXISTING_48_COEFFICIENTS.csv',dtype=str)
original=pd.read_csv(Path('E:/26/补/数据分析结果/teacher_runs/teacher_parallel_20260804/07_reviewer_analysis/Reviewer1_parallel_previous_scene_FDR.csv'),dtype=str)
check('All 48 previous-scene rows preserve original values and both q columns',prev.equals(original))
r=pd.read_csv(EV/'R_READ_SAMPLE_CONFIRMATION.csv');p=pd.read_csv(OUT/'PREVIOUS_SCENE_SAMPLE_COUNTS.csv')
check('Original R read semantics and Python sample audit agree on 42/461 and 42/386',r.complete_trials.eq(386).all() and r.complete_participants.eq(42).all() and p.complete_trials.eq(386).all() and p.missing_previous_wwr.eq(75).all())
scope=json.loads((EV/'RESULT_SCOPE_SUMMARY.json').read_text(encoding='utf-8'))
check('Model-table catalog has no read errors',not scope['read_errors'],f"{scope['model_tables']} model tables; {scope['total_files']} files inventoried")
check('No .set/.fdt waveform source copies in delivery',not any(p.suffix.lower() in ['.set','.fdt'] for p in OUT.rglob('*') if p.is_file()))
pd.DataFrame(checks).to_csv(EV/'AUDIT_QA_CHECKS.csv',index=False,encoding='utf-8-sig')
lines=['# AUDIT_QA','',f'检查时间UTC：{datetime.datetime.now(datetime.timezone.utc).isoformat()}','',f'本轮{len(checks)}项交付完整性/来源校验，通过{sum(d["passed"] for d in checks)}项。这些检查不代表原分析端到端复现。','', '| 检查 | 状态 | 说明 |','| --- | --- | --- |']
for d in checks:lines.append(f"| {d['check']} | {'PASS' if d['passed'] else 'FAIL'} | {d['detail'].replace('|','/')} |")
lines+=['','## 仍未确认的研究事实','','- 144项统一primary BH family及其36/144专属校正输出。','- 核查问题所述18-outcome/72-model最终temporal分析：当前保存产物结构不支持这一已运行描述。','- 两组theta最终q范围及F/P/O relative-alpha跨四窗口最终校正结论。','- 完整运行瞬间代码快照及全部EEG历史输入文件哈希。','','未用新计算填补以上缺口；报告已明确状态。','',f'关键来源清单：{len(m)}项，包含112个未复制的现存.set/.fdt以及2个原始交付ZIP。历史文件的mtime与本次SHA不被当作预注册证据。']
(OUT/'AUDIT_QA.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
entries=[]
for p in OUT.rglob('*'):
 if p.is_file() and p.name!='DELIVERABLE_MANIFEST.csv':entries.append(dict(relative_path=p.relative_to(OUT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
pd.DataFrame(entries).to_csv(OUT/'DELIVERABLE_MANIFEST.csv',index=False,encoding='utf-8-sig')
print(json.dumps(dict(checks=len(checks),passed=sum(d['passed'] for d in checks),failed=[d for d in checks if not d['passed']],critical_sources=len(m),deliverable_files=len(entries)),ensure_ascii=False))
assert all(d['passed'] for d in checks)
