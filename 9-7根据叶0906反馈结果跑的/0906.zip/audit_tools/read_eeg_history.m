root=native2unicode(uint8([69 58 47 50 54 47 232 161 165 47 232 132 145 231 148 181 230 149 176 230 141 174]),'UTF-8');
files=dir(fullfile(root,'*.set'));
rows=cell(numel(files),1);
for k=1:numel(files)
 p=fullfile(files(k).folder,files(k).name);
 s=load(p,'-mat');
 if isfield(s,'EEG'), e=s.EEG; else, e=s; end
 row=struct('source_file',p,'history','','datfile','','srate',NaN,'nbchan',NaN,'pnts',NaN);
 for f={'history','datfile','srate','nbchan','pnts'}
  if isfield(e,f{1}),row.(f{1})=e.(f{1});end
 end
 rows{k}=row;
end
fid=fopen(native2unicode(uint8([69 58 47 50 54 47 232 161 165 47 121 121 100 47 48 57 48 54 47 101 118 105 100 101 110 99 101 47 99 117 114 114 101 110 116 95 115 101 116 95 104 105 115 116 111 114 121 46 106 115 111 110]),'UTF-8'),'w','n','UTF-8');fprintf(fid,'%s',jsonencode(rows));fclose(fid);
fprintf('Read metadata/history for %d sets. No waveform processing.\n',numel(rows));

