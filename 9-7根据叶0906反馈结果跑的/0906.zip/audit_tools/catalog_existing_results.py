from pathlib import Path
import csv,json,hashlib,re,datetime
from collections import Counter
import zipfile,xml.etree.ElementTree as ET,posixpath
OUT=Path('E:/26/补/yyd/0906');roots=[Path('E:/26/补/数据分析结果'),Path('E:/26/补/yyd')]
files=[p for root in roots for p in root.rglob('*') if p.is_file() and '0906' not in p.parts]
def canonical(p):return re.sub(r'^SRC\d+__','',p.name).rsplit('.',1)[0]
csv_peers={(str(p.parent),canonical(p)) for p in files if p.suffix.lower()=='.csv'}
catalog=[];errors=[];inventory=[];cache={}
def workbook_tables(p):
 ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
 with zipfile.ZipFile(p) as z:
  shared=[]
  if 'xl/sharedStrings.xml' in z.namelist():
   for s in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns):shared.append(''.join(t.text or '' for t in s.findall('.//m:t',ns)))
  rels={r.attrib['Id']:r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  book=ET.fromstring(z.read('xl/workbook.xml'))
  for sheet in book.findall('m:sheets/m:sheet',ns):
   rid=sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'];target=rels[rid]
   target=target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/'+target)
   def rows(target=target):
    with z.open(target) as f:
     for _,el in ET.iterparse(f,events=['end']):
      if el.tag!='{'+ns['m']+'}row':continue
      row=[]
      for c in el.findall('m:c',ns):
       letters=re.match(r'[A-Z]+',c.attrib.get('r','A1')).group();idx=0
       for ch in letters:idx=idx*26+ord(ch)-64
       while len(row)<idx:row.append('')
       typ=c.attrib.get('t');v=c.find('m:v',ns);val=v.text if v is not None else ''
       if typ=='s':val=shared[int(val)] if val else ''
       elif typ=='inlineStr':val=''.join(t.text or '' for t in c.findall('.//m:t',ns))
       row[idx-1]=val
      yield row;el.clear()
   yield sheet.attrib['name'],rows()
def summarize(headers,rows):
 headers=[str(x or '') for x in headers]
 if not any(x in headers for x in ['outcome','Outcome','metric','Metric']) or not any(x in headers for x in ['term','Term','temporal_predictor','predictor']):return None
 count=0;values={x:set() for x in ['outcome','Outcome','metric','Metric','term','Term','scale','model','model_type','onset_trim_s','n','n_obs','n_subjects','status'] if x in headers}
 for row in rows:
  count+=1
  for name,s in values.items():
   i=headers.index(name)
   if i<len(row) and row[i] not in [None,'']:s.add(str(row[i]))
 return dict(rows=count,**{k:';'.join(sorted(v)) for k,v in values.items()},columns=';'.join(headers))
for i,p in enumerate(files):
 s=p.stat();inventory.append(dict(path=str(p),bytes=s.st_size,mtime_utc=datetime.datetime.fromtimestamp(s.st_mtime,datetime.timezone.utc).isoformat(),extension=p.suffix.lower()))
 if p.suffix.lower() not in ['.csv','.xlsx']:continue
 if p.suffix.lower()=='.xlsx' and (str(p.parent),canonical(p)) in csv_peers:continue
 try:
  if p.suffix.lower()=='.csv':
   with p.open(encoding='utf-8-sig',newline='') as f:
    reader=csv.reader(f);headers=next(reader,[])
    if not any(x in headers for x in ['outcome','Outcome','metric','Metric']):continue
    info=summarize(headers,reader)
    if info:catalog.append(dict(source_file=str(p),sheet='',**info))
  else:
   digest=hashlib.sha256(p.read_bytes()).hexdigest()
   if digest in cache:found=cache[digest]
   else:
    found=[]
    for title,rows in workbook_tables(p):
     headers=next(rows,[]);info=summarize(headers,rows)
     if info:found.append(dict(sheet=title,**info))
    cache[digest]=found
   for info in found:catalog.append(dict(source_file=str(p),**info))
 except Exception as e:errors.append(dict(source_file=str(p),error=str(e)))
 if i%1000==0:print('inspected entries',i,flush=True)
def writecsv(name,rows):
 fields=list(dict.fromkeys(k for d in rows for k in d))
 with (OUT/'evidence'/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
writecsv('RESULT_SCOPE_INVENTORY.csv',inventory);writecsv('MODEL_TABLE_CATALOG.csv',catalog)
missing5=['log10_F_alpha_absolute','log10_P_theta_absolute','log10_P_alpha_absolute','log10_F_beta_absolute','log10_P_beta_absolute']
matches={x:[d['source_file'] for d in catalog if x in (d.get('outcome','')+';'+d.get('Outcome',''))] for x in missing5}
summary=dict(total_files=len(files),csv_files=sum(p.suffix.lower()=='.csv' for p in files),xlsx_files=sum(p.suffix.lower()=='.xlsx' for p in files),model_tables=len(catalog),standalone_unique_xlsx_scanned=len(cache),xlsx_paired_csv_rule='Same parent and basename after removing SRC id; CSV examined instead',later_than_aug09_model_sources=sorted(set(d['source_file'] for d in catalog if Path(d['source_file']).stat().st_mtime>datetime.datetime(2026,8,10,tzinfo=datetime.timezone.utc).timestamp())),missing5_log10_outcome_matches=matches,read_errors=errors)
(OUT/'evidence/RESULT_SCOPE_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False),flush=True)
