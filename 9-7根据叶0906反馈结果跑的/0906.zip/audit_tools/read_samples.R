args <- commandArgs(trailingOnly=TRUE)
root <- args[[1]]
out <- args[[2]]
rows <- list()
for (trim in c(0,5,10,15)) {
 p <- file.path(root,'06_eeg_primary','onset_window_models',paste0('trim_',trim,'s'),'eeg_onset_order_model_input.csv')
 d <- read.csv(p,check.names=FALSE)
 for (v in c('Participant','WWR','Complexity','OrderGroup','ExperienceGroup','Gender')) d[[v]] <- factor(d[[v]])
 d2 <- d[d$PositionWithinBlock>1,]
 needed <- c('Participant','WWR','Complexity','ExperienceGroup','Gender','Block','PositionWithinBlockCentered','OrderGroup','PreviousWWR','PreviousComplexity','O_theta_relative','F_theta_relative','O_alpha_relative','O_beta_relative')
 cc <- complete.cases(d2[,needed])
 rows[[length(rows)+1]] <- data.frame(onset_trim_s=trim,participants=length(unique(d$Participant)),trials=nrow(d),first_position=sum(d$PositionWithinBlock==1),previous_wwr_blank=sum(d$PreviousWWR==''),previous_wwr_R_NA=sum(is.na(d$PreviousWWR)),round1_first=sum(d$PositionWithinBlock==1 & d$Block==1),round2_first=sum(d$PositionWithinBlock==1 & d$Block==2),complete_trials=sum(cc),complete_participants=length(unique(d2$Participant[cc])),complexity_blank_level=sum(as.character(d$Complexity)==''),previous_complexity_blank_after_first_exclusion=sum(d2$PreviousComplexity==''),source_file=p)
}
write.csv(do.call(rbind,rows),file.path(out,'R_READ_SAMPLE_CONFIRMATION.csv'),row.names=FALSE,fileEncoding='UTF-8')
writeLines(capture.output(sessionInfo()),file.path(out,'R_READ_ONLY_SESSION_INFO.txt'))
print(do.call(rbind,rows)[,1:12])
