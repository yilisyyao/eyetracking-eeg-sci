from pathlib import Path
import json, csv, hashlib, shutil, subprocess, zipfile, datetime
import pandas as pd

OUT=Path('E:/26/补/yyd/0906')
REPO=Path('D:/Lucas/Desktop/More-is-not-always-better')
DATA=Path('E:/26/补/数据分析结果')
RUN=DATA/'teacher_runs/teacher_parallel_20260804'
OLD=DATA/'teacher_runs/teacher_onset_20260802'
EV=OUT/'evidence'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def save(name,obj):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def meta(p):
 s=p.stat();return dict(source_file=str(p.resolve()),bytes=s.st_size,mtime_utc=datetime.datetime.fromtimestamp(s.st_mtime,datetime.timezone.utc).isoformat(),sha256=sha(p))
manifest=[]
def collect(p,rel,commit='UNRESOLVED',copy=True):
 if not p.is_file():return
 d=meta(p);d.update(evidence_file=str(EV/rel) if copy else '',git_commit=commit)
 if copy:
  target=EV/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
  assert sha(target)==d['sha256']
 manifest.append(d)
head=git('rev-parse','HEAD').decode().strip()
for name,args in [('git_status_before.txt',['status','--porcelain=v1']),('git_log.txt',['log','--all','--format=%H %aI %cI %s']),('git_reflog.txt',['reflog','--all','--date=iso']),('ce80f1f_to_5174929.diff',['diff','ce80f1f','5174929']),('5174929_to_HEAD.diff',['diff','5174929','HEAD'])]:
 (EV/name).write_bytes(git(*args))
subprocess.run(['git','-C',str(REPO),'archive','--format=zip','-o',str(EV/'code_5174929.zip'),'5174929'],check=True)
scripts=['scripts/run_teacher_analysis.py','scripts/run_realdata_all.py','scripts/run_eeg_from_raw.py','scripts/run_eeg_onset_sensitivity.py','analysis/r/eeg_order_analysis.R','analysis/r/eeg_primary_analysis.R','analysis/r/common.R','src/paper_analysis/eeg/onset.py','src/paper_analysis/stats/onset_sensitivity.py','src/paper_analysis/teacher/eeg.py','src/paper_analysis/teacher/complete.py','matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m','matlab/run_eeg_bandpower_from_set.m','configs/eeg_analysis.json','configs/teacher_analysis.example.json','requirements.txt','pyproject.toml','analysis/r/renv.lock','analysis/r/environment.yml']
for s in scripts:
 collect(REPO/s,Path('code_HEAD')/s,head)
 for rev in ['ce80f1f','5174929','3d6b001']:
  proc=subprocess.run(['git','-C',str(REPO),'show',rev+':'+s],capture_output=True)
  if proc.returncode==0:
   t=EV/('code_'+rev)/s;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(proc.stdout)
for root,label in [(RUN,'run_parallel'),(OLD,'run_onset')]:
 for p in root.rglob('*'):
  if not p.is_file():continue
  r=p.relative_to(root)
  if any(x in r.parts for x in ['package_previous_20260803','filesource_flat','filesource_flat_old','09_eye_figures']):continue
  select=(len(r.parts)==1 and p.suffix.lower() in ['.json','.log','.csv']) or (r.parts[0] in ['05_eeg_order','06_eeg_primary','07_reviewer_analysis','00_eeg_onset_statistics','99_completion'] and p.suffix.lower() in ['.csv','.json','.r','.py','.txt','.md'])
  if select:collect(p,Path(label)/r)
collect(DATA/'realdata_run_summary.json',Path('realdata_run_summary.json'))
for p in Path('E:/26/补/yyd/EEG上游预处理证据审计_20260818').glob('*'):
 if p.suffix.lower() in ['.md','.xlsx','.csv']:collect(p,Path('prior_preprocessing_audit')/p.name)
for p in Path('E:/26/补/脑电数据').glob('*'):
 if p.suffix.lower() in ['.set','.fdt']:collect(p,Path('not_copied')/p.name,copy=False)
for p in (OLD/'00_eeg_raw_export').rglob('*'):
 if p.is_file() and ('snapshot' in p.name or 'manifest' in p.name or p.suffix.lower() in ['.json','.txt','.log']):collect(p,Path('raw_export_metadata')/p.relative_to(OLD/'00_eeg_raw_export'))
hist=[]
for day in ['02','03','09']:
 for p in Path('C:/Users/Lucas/.codex/sessions/2026/08',day).glob('*.jsonl'):
  for i,line in enumerate(p.open(encoding='utf-8'),1):
   try:d=json.loads(line)
   except:continue
   q=d.get('payload',{})
   if d.get('type')!='response_item':continue
   t='\n'.join(c.get('text','') for c in q.get('content',[]) if isinstance(c,dict)) if q.get('type')=='message' else str(q.get('arguments',''))
   relevant=(q.get('type')=='message' and q.get('role') in ['user','assistant'] and any(x in t for x in ['10 s','10秒','四窗口','四个并行','四个同等','4个并行','teacher_parallel_20260804','144','324'])) or (q.get('type') in ['function_call','custom_tool_call'] and any(x in t for x in ['onset_trim_strategy','teacher_analysis.parallel.json','teacher_parallel_20260804']))
   if relevant and '<environment_context>' not in t:
    hist.append(dict(source_file=str(p),source_line=i,timestamp=d.get('timestamp'),role=q.get('role',q.get('type')),text=t))
  if any(x['source_file']==str(p) for x in hist):collect(p,Path('not_copied')/p.name,copy=False)
save('evidence/history_excerpts.json',hist)
pd.DataFrame(manifest).to_csv(OUT/'CRITICAL_FILE_MANIFEST.csv',index=False,encoding='utf-8-sig')
save('evidence/collection_summary.json',dict(collected=len(manifest),head=head,missing_requested_code_files=[x for x in scripts if not (REPO/x).exists()]))
print(json.dumps({'collected':len(manifest),'history_excerpts':len(hist)},ensure_ascii=False))
