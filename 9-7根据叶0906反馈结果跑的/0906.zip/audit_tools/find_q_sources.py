from pathlib import Path
import csv,json
out=Path('E:/26/补/yyd/0906/evidence')
with (out/'MODEL_TABLE_CATALOG.csv').open(encoding='utf-8-sig') as f: cat=list(csv.DictReader(f))
paths=sorted(set(d['source_file'] for d in cat if d['source_file'].endswith('.csv') and any(x in d.get('outcome','').lower() for x in ['theta','alpha'])))
found=[]
for name in paths:
 with open(name,encoding='utf-8-sig',newline='') as f:
  for i,r in enumerate(csv.DictReader(f),2):
   outcome=r.get('outcome','');term=r.get('term','')
   if 'theta' not in outcome.lower() or not any(s in term.lower() for s in ['block','round']):continue
   for k,v in r.items():
    if v and any(s in k.lower() for s in ['q','fdr','bh','adj']) and (v.startswith('0.00447') or v.startswith('0.00461') or v.startswith('0.02239')):
     found.append(dict(source_file=name,source_line=i,outcome=outcome,term=term,field=k,value=v))
(out/'THETA_Q_VALUE_SOURCE_SEARCH.json').write_text(json.dumps(dict(csv_model_files_scanned=len(paths),matched_rows=found),ensure_ascii=False,indent=2),encoding='utf-8')
print('theta q source scan',len(paths),'files; matches',len(found))
