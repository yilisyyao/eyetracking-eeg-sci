from pathlib import Path
import json,csv,hashlib,datetime,subprocess,shutil
import pandas as pd
OUT=Path('E:/26/补/yyd/0906');EV=OUT/'evidence';REPO=Path('D:/Lucas/Desktop/More-is-not-always-better');DATA=Path('E:/26/补/数据分析结果');RUN=DATA/'teacher_runs/teacher_parallel_20260804';OLD=DATA/'teacher_runs/teacher_onset_20260802'
HEAD='185cb077b8a53de7447e562ff754dbd27dc56ad9';BASE='ce80f1f1694cf7f136b90724321cf1634c8c28ae';PAR='5174929f189fda0f2945488575f04792a41a7ed2'
def write(name,text): (OUT/name).write_text(text.strip()+'\n',encoding='utf-8')
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8388608),b''):h.update(b)
 return h.hexdigest()
manifest=pd.read_csv(OUT/'CRITICAL_FILE_MANIFEST.csv',keep_default_na=False).to_dict('records')
for s in ['configs/analysis_plan.json','docs/ANALYSIS_DECISIONS.md']:
 p=REPO/s;q=EV/'code_HEAD'/s;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);st=p.stat()
 manifest.append(dict(source_file=str(p),bytes=st.st_size,mtime_utc=datetime.datetime.fromtimestamp(st.st_mtime,datetime.timezone.utc).isoformat(),sha256=hashfile(p),evidence_file=str(q),git_commit=HEAD,evidence_id=f'E{len(manifest)+1:04}'))
 for rev in ['ce80f1f','5174929']:
  b=subprocess.check_output(['git','-C',str(REPO),'show',rev+':'+s]);q=EV/('code_'+rev)/s;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
pd.DataFrame(manifest).to_csv(OUT/'CRITICAL_FILE_MANIFEST.csv',index=False,encoding='utf-8-sig')
lookup={str(Path(d['source_file']).resolve()).lower():d for d in manifest}
def cite(p,lines='',commit=''):
 p=Path(p);d=lookup.get(str(p.resolve()).lower())
 if not d:return f'- [{p.name}]({p.as_posix()})；定位：{lines or "整表/整文件"}。'
 git=commit or d['git_commit'];location=f'；定位：{lines}' if lines else ''
 return f'- **{d["evidence_id"]}** [{p.name}]({p.as_posix()}){location}；Git：`{git}`；mtime UTC：`{d["mtime_utc"]}`；SHA-256：`{d["sha256"]}`。'
def table(headers,rows):
 def cell(x):return str(x).replace('|','\\|').replace('\n','<br>')
 return '| '+' | '.join(map(cell,headers))+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(map(cell,r))+' |' for r in rows)
def code(s,line):return cite(REPO/s,line,PAR+'（所引核心代码与HEAD一致；具体运行工作区见问题1）')
samples=json.loads((EV/'table_checks.json').read_text(encoding='utf-8'))
extra=json.loads((EV/'ADDITIONAL_CHECKS.json').read_text(encoding='utf-8'))
hist=json.loads((EV/'history_excerpts.json').read_text(encoding='utf-8'))
h02=Path(next(x['source_file'] for x in hist if '2026-08-02' in x['timestamp']));h03=Path(next(x['source_file'] for x in hist if '2026-08-04' in x['timestamp']));h09=Path(next(x['source_file'] for x in hist if '2026-08-09' in x['timestamp']))
scope='''本次只读取代码、已有CSV/JSON/日志/ZIP、Git历史和EEGLAB `.set` 中的history/元数据，并计算文件哈希、已有表的行数及集合对应关系。未重新拟合模型，未重算p值、BH q值、置信区间或频谱，未修改原工程、0803/0805交付包或论文。R仅用于复核原 `read.csv` 的缺失值语义；MATLAB仅用于读取56份 `.set` 的history。所有新文件都写入本目录。

结论优先依据原始配置、机器结果及执行代码；旧报告和本地任务对话仅用于定位及决策时间溯源。本文所列时间统一明确标注UTC或北京时间。文件mtime及本次SHA-256不能单独证明历史时刻的文件内容。状态 `NOT FOUND/UNRESOLVED` 表示在列明范围内缺少证据，并不等于证明相关分析从未发生。'''
timeline=table(['事件','UTC时间','北京时间（UTC+8）','证据与含义'],[
 ['10秒主分析＋四种截断方案的实施计划','2026-08-02 04:49:47.330','2026-08-02 12:49:47.330','任务记录第350行：10秒主分析，15秒主要稳健性，5秒温和敏感性，0秒历史审计；明确当阶段不跑56人全量数据'],
 ['四种截断实现进入Git：3d6b001','2026-08-02 05:44:11','2026-08-02 13:44:11','配置已含[0,5,10,15]，仍是primary_onset_trim_s=10'],
 ['10秒结果已经出现在本地讨论中','2026-08-03 13:02:43.071','2026-08-03 21:02:43.071','任务记录第128行已解释10/15秒PreviousWWR结果；证明此时已有旧结果被检视，不采用其中旧数字作为当前结果'],
 ['用户提出改为四个并行','2026-08-04 13:18:38.309','2026-08-04 21:18:38.309','原话同时包含“10 s保持为正式主分析，改成4个并行”；单独这句话的地位要求有歧义'],
 ['明确同等并行的修改计划','2026-08-04 13:19:28.774','2026-08-04 21:19:28.774','随后助手计划明确取消10秒主分析地位；第674行用户要求先改代码再跑数据'],
 ['eeg-order阶段完成记录','2026-08-04 13:56:12.816','2026-08-04 21:56:12.816','run_manifest记录ce80f1f，但实际运行了工作区平行改动'],
 ['eeg-primary阶段完成记录','2026-08-04 14:35:45.594','2026-08-04 22:35:45.594','四窗口R输入及结果已归档'],
 ['正式运行提升完成','2026-08-04 14:45:15.488','2026-08-04 22:45:15.488','realdata_run_summary记录promoted=true'],
 ['完成后继续修改结果索引代码','2026-08-04 15:16:23.472','2026-08-04 23:16:23.472','complete.py排除索引文件自身，另有对应测试；说明最终提交并非运行瞬间的整库快照'],
 ['平行改动提交5174929','2026-08-09 09:36:45','2026-08-09 17:36:45','归档提交晚于8月4日运行；不是时区造成的5天差异']])
window=f'''# EEG_WINDOW_HISTORY

**结论：四种截断长度在8月2日的新截断分析实施计划中已共同列出，但“同等地位的最终平行分析”是在已看过10秒结果后，于8月4日调整的。不能写成从研究开始即 prospectively prespecified equal-status analyses。**

{timeline}

## 分别回答问题3

1. 最初已批准的实施方案确实是10秒主分析；更早讨论曾提5秒主方案，但不是最后获批的8月2日实施方案。
2. 0、5、15秒不是到8月4日才临时新增的窗口：8月2日计划和3d6b001已列出四种长度，早于本轮新截断全量结果。能证明的是本轮实现计划的先后，不能升级为实验开始前预注册，也不能证明作者在其他位置从未看过数据。
3. 最终R四窗口模型使用同一公式、四者共同QC交集（42人/461试次），均输出CR2。四窗口PreviousScene合并表使用一致的窗口内12项及联合48项BH规则。**不能把此事实扩张为所有核心条件系数都执行过36/144项BH：那部分校正表未找到。**
4. 已找到查看结果前的“四种长度”计划；没有从一开始就“同等地位”的证据，反而存在明确的10秒主分析历史。

建议3.3采用：

> The 0-, 5-, 10-, and 15-s onset-trim variants were analysed in parallel in the final analysis pipeline, with the 10-s variant retained as a compatibility reference.

这句话描述最终执行方式；若需要分析历史，应另说明四种长度最初用于主分析与敏感性检查，后改为平行报告。不得隐去已检视旧结果这一时间事实，也不据此否定现有估计值。

## 证据

{cite(h02,'第350行实施计划；history_excerpts.json保留原文','非Git任务历史')}
{cite(h03,'第128、658、665、674行；补丁事件记录','非Git任务历史')}
{cite(RUN/'teacher_analysis.parallel.json','eeg.onset_trim_strategy / reference_onset_trim_s / onset_trim_variants_s','运行manifest=ce80f1f；工作区含后续平行改动')}
{code('src/paper_analysis/teacher/eeg.py','205–307，_run_onset_variant_order_models')}
{code('analysis/r/eeg_order_analysis.R','23–48、111–112')}

补充逐事件补丁见 `evidence/historical_repo_patch_events.json`；所有历史记录仅作证据，未执行其中的命令。
'''
write('EEG_WINDOW_HISTORY.md',window)

family=f'''# ANALYSIS_FAMILY_144_VS_324

**结论：四个core outcomes的配置早已存在；但未找到“144项在8月4日被明确规定为统一primary multiplicity family”以及36/144项BH结果的证据。也不能断言它后来必然从核查问题所指324项审计中提取，因为该审计原表/脚本尚未找到。**

## 已查明的三个不同层次

{table(['层次','实际来源与模型','计数','已保存的校正规则'],[
 ['核心相对功率四窗口','onset_window_models/trim_*s/eeg_cr2_robust_results.csv；R lmer Model1 + CR2','4 outcomes × 9条件/经验相关系数 × 4窗口 = 144','源表无BH列；本次仅提取已有β/SE/df/raw p，不生成新q'],
 ['10秒兼容主分析','06_eeg_primary/12_eeg_cr2_results.csv；R核心relative模型；场景QC474试次','并非共同QC461试次下的四窗口144项','eeg_primary_analysis.R按频带×term分组；secondary/supplemental另加家族标签'],
 ['本地可定位的324行GEE子集','00_eeg_onset_statistics/onset_variant_model_results.csv中parallel_common_qc','9个裸绝对功率变量 × 9条件/经验项 × 4窗口 = 324','源表按全部非截距项校正：每窗口117项、跨窗口468项；不是324项重新BH']])}

9个核心条件/经验相关项（注意包含ExperienceGroup主效应，不能仅凭名称把它们都当成实验条件主效应）：

{chr(10).join('- `'+x+'`' for x in samples['core_terms'])}

## 逐题回答问题4

1. **UNRESOLVED（primary-family地位未证实）**。配置中 `core_metrics` 的存在支持“核心指标事先已指定”，不支持“跨四窗口144项作为一个统一BH family事先已指定”。
2. **UNRESOLVED（后续提取历史未证实）**。这次可以直接从四个R/CR2源表提取144条已有系数，不必先有324条表。未找到核查问题中提及的后来审计的生成脚本，不能补写提取时间。
3. **NOT FOUND**。没有找到对上述R/CR2 144项执行联合BH的原脚本。`eeg_order_analysis.R`只写CR2 raw p；`eeg_primary_analysis.R`的BH是另一分组口径；`complete.py`的联合BH处理的是PreviousScene的48项。
4. **NOT FOUND**。每窗口36项及跨窗口144项的专属BH文件未找到。`CORE_144_EXISTING_CR2_COEFFICIENTS.csv`是本次只读整理出的已有系数，不能称为历史BH输出。
5. **PARTIALLY CONFIRMED**。9×9×4=324可在上述GEE输出中精确提取，已保存为 `BROADER_324_EXISTING_GEE_COEFFICIENTS.csv`。但是该管线把 `F_theta` 等裸字段映射到 `eeg_F_theta`，裸字段与 `*_absolute` 数值逐列相同，**不是9个relative outcomes的Model1 CR2审计**。核查问题所指324是否是另一个后续产物仍未确认。
6. **不能说相同**。本地GEE子集继承117/468项校正；144项专属校正无证据；10秒兼容R主分析又采用频带×term校正。这些来源、量纲、模型及family不能混用。

## 对3.3措辞的影响

可写：

> For the four core EEG outcomes, 144 Model 1 condition-related coefficients were examined across the four onset-trim variants.

暂不能写：`The primary multiplicity family comprised 144 coefficients.`

不能把本次“144行提取表”或“324行提取表”称为当时保存的独立family，也不能拿GEE子集的q填进R/CR2结果。若正文要报告144项联合q，需要提供当时已经生成的校正脚本/表；本次不重新计算以替代历史证据。

## 证据

{cite(RUN/'teacher_analysis.parallel.json','eeg.core_metrics / secondary_metrics / supplemental_metrics / primary_measure','manifest=ce80f1f；实际工作区部分可溯源')}
{code('analysis/r/eeg_order_analysis.R','23–48、111–112：Model1及CR2输出，无BH')}
{code('analysis/r/eeg_primary_analysis.R','132–170：band×term correction_family；267：独立bootstrap种子')}
{code('analysis/r/common.R','49–66：CR2；90–95：bh_within_family')}
{code('src/paper_analysis/stats/onset_sensitivity.py','186–200：校正分组；436–441：裸字段映射')}
{code('matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m','331–340：裸字段为absolute，relative另存')}
{cite(RUN/'00_eeg_onset_statistics/onset_variant_model_results.csv','sample_strategy=parallel_common_qc；model_type=gee_gaussian_participant_clustered_robust')}
{cite(REPO/'docs/ANALYSIS_DECISIONS.md','23–25、40–42、57–60：正式R与兼容GEE、核心指标分层',PAR)}
'''
write('ANALYSIS_FAMILY_144_VS_324.md',family)

prev=pd.read_csv(OUT/'PREVIOUS_SCENE_EXISTING_48_COEFFICIENTS.csv',dtype=str)
pv=prev.loc[prev.outcome.eq('O_theta_relative') & prev.term.eq('PreviousWWRWWR75')]
pvtable=table(['窗口/s','β','raw CR2 p','within-window q（12项）','joint q（48项）'],[[r.onset_trim_s,r.estimate,r['p.value'],r.p_fdr_bh_window,r.p_fdr_bh_parallel] for _,r in pv.iterrows()])
sampletable=table(['窗口/s','共同QC参与者/试次','前序未定义','轮1 / 轮2首场景','排除后完整案例'],[[s['onset_trim_s'],f"{s['participants']} / {s['trials']}",s['missing_previous_wwr'],f"{s['missing_round1']} / {s['missing_round2']}",f"{s['complete_participants']} / {s['complete_trials']}"] for s in samples['samples']])
previous=f'''# PREVIOUS_SCENE_SAMPLE_CONFIRMATION

**CONFIRMED：四窗口共同QC输入均为42人/461试次；75条PreviousWWR空记录全部是每轮第一个场景（轮1为37条、轮2为38条）；按原代码PositionWithinBlock > 1筛选后，四窗口均为42人/386个完整案例。**

{sampletable}

这是前序场景在每轮首位置上结构性未定义及其排除后的完整案例建模，不是75条试次读取失败。四窗口Participant×GlobalTrialOrder集合完全相同，保留行的前序模型所需预测量与4个核心结局完整。

但要精确说明读取语义：CSV的字符空值在R `read.csv` 中保留为空字符串；当前Complexity的C0参考类别也被存成空字符串。Python默认读取会把这些字符空值视为NaN，直接dropna会误报大量缺失。已用原R读取方式独立复核，见 `evidence/R_READ_SAMPLE_CONFIRMATION.csv`。75条first-position记录是由显式位置过滤排除；不能描述为R自动 `na.omit(PreviousWWR)` 删除75条。

当前与前序复杂度的空字符串编码属于复现说明应补充的细节；不应把所有PreviousComplexity空值都当成首场景缺失。当前导出的模型表未逐模型保存nobs，386是由实际输入和原筛选/complete-case逻辑确认的可用模型样本，而非本次读取重新拟合的模型对象。

## O_theta_relative × PreviousWWR75

{pvtable}

10秒0.53219、15秒0.11835确为窗口内q；对应联合q分别约0.80719和0.47338。48项=4个核心结局×3个前序系数（WWR45、WWR75、复杂度）×4窗口。所有这些目标行均未达到joint q<0.05。**正文若只写q，必须注明within-variant或joint q。**

## 证据

{cite(RUN/'06_eeg_primary/onset_window_models/trim_10s/eeg_onset_order_model_input.csv','Participant、PositionWithinBlock、PreviousWWR、Block；另三个窗口见清单')}
{code('src/paper_analysis/teacher/contracts.py','221–260：同Participant/Block内shift；首场景置空')}
{code('analysis/r/eeg_order_analysis.R','10–17、33–48：原读取、因子与PositionWithinBlock > 1')}
{code('src/paper_analysis/teacher/complete.py','419–459：_parallel_order_carryover_audit；703–706写出联合表')}
{cite(RUN/'07_reviewer_analysis/Reviewer1_parallel_previous_scene_FDR.csv','48行；p_fdr_bh_window与p_fdr_bh_parallel')}
'''
write('PREVIOUS_SCENE_SAMPLE_CONFIRMATION.md',previous)

denom=f'''# RELATIVE_POWER_DENOMINATOR_AUDIT

**CONFIRMED（算法定义及可追溯导出链）；历史运行瞬间的整个工作区仍为PARTIALLY CONFIRMED。实际分母为1–45 Hz，theta/alpha/beta各ROI均使用同一频率范围的总功率，分别在各自ROI信号上计算。**

{table(['项目','结论','精确定位','可信度'],[
 ['分母范围','1–45 Hz','MATLAB default_bands：totalBand40=[1 45]；名称中的40不代表实际上限40','高：ce80f1f、5174929及当前文件定义一致'],
 ['相对功率计算','bandpower / total_1_45','append_bandpower_columns第328、338–340行','高'],
 ['PSD与积分','pwelch；在f>=band(1)且f<=band(2)的离散频率点trapz积分','bandpower_welch第401–417行','高'],
 ['1–30 Hz定义','存在totalBand30=[1 30]，不用于上述relative字段','default_bands；与实际totalBand40调用区分','高'],
 ['teacher配置分母字段是否控制计算','没有发现relative_power_denominator_hz传入计算函数的路径；它是预处理说明字段','MATLAB apply_config读取bands，未读取这个teacher嵌套描述字段','高'],
 ['可修改实际分母的参数','MATLAB opts.Bands.totalBand40；ConfigPath中的bands可覆盖','addParameter Bands、apply_config merge_struct','高'],
 ['0805输入来源','重用teacher_onset_20260802的eeg_trial_long及四窗口长表','实际teacher_analysis.parallel.json eeg.trial_file与onset_sensitivity_trial_file','高；已记录输入哈希全部匹配'],
 ['上游0.5–40 Hz与积分1–45 Hz是否并存','是。当前56份.set history均记录0.5–40 Hz滤波，而频谱代码积分范围至45 Hz','current_set_history.json；MATLAB代码','高（当前文件）；2份.set后来修改，不能当作8月2日原件'],
 ['是否能证明40–45 Hz完全无功率','不能据滤波上限推断为精确零；本次未计算频谱','仅确认定义和处理链','不作数值推断']])}

**METHODS DEFINITION MISMATCH（针对核查文件所引Methods“1–30 Hz”措辞）**：这与已查明算法不一致，应在定稿时以1–45 Hz描述原结果。尚未收到本轮完整Methods稿，不能声称已逐行核对当前全文。

实际运行配置的 `relative_power_denominator_hz` 写为1–45，但仅改这段文字不会改变MATLAB算法；可重复性说明应同时给出真实计算函数和bands参数，而不能只引用配置注释。

当前56份.set history均有band-pass、49–51 Hz band-stop、average re-reference与runica。未发现pop_subcomp记录；本次不推测ICA成分剔除标准。两份.set的mtime晚于8月4日，既有8月18日审计也记录了更新；当前文件哈希是本次快照，不是8月2日原始输入哈希。

## 证据

{code('matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m','4–7、29、76、309–340、401–417、539–570')}
{code('scripts/run_eeg_from_raw.py','53–62、102–130：ConfigPath与MATLAB调用')}
{cite(RUN/'teacher_analysis.parallel.json','eeg.preprocessing_parameters.relative_power_denominator_hz；输入路径')}
{cite(OLD/'eeg_onset_export_stdout_02.log','56个数据集导出；validation_status: pass',BASE+'（HEAD记录，非完整工作区哈希）')}
{cite(RUN/'06_eeg_primary/input_hashes.json','主trial输入SHA256；本次读回匹配')}

当前.set/.fdt绝对路径、大小、mtime与SHA-256见 `CRITICAL_FILE_MANIFEST.csv`（112项，只记录不复制）；history摘录和逐文件检查见 `evidence/current_set_history.json` 与 `CURRENT_SET_HISTORY_CHECKS.csv`。
'''
write('RELATIVE_POWER_DENOMINATOR_AUDIT.md',denom)

cfg=json.loads((RUN/'teacher_analysis.parallel.json').read_text(encoding='utf-8-sig'));actual=cfg['eeg']
cfgrows=[]
for name in ['onset_trim_strategy','reference_onset_trim_s','onset_trim_variants_s','core_metrics','secondary_metrics','supplemental_metrics','bootstrap_iterations','onset_random_seed','primary_measure','trial_file','onset_sensitivity_trial_file','onset_analysis_dir']:
 cfgrows.append([f'eeg.{name}',json.dumps(actual.get(name),ensure_ascii=False)])
cfgrows.extend([['eeg.preprocessing_parameters.relative_power_denominator_hz',actual['preprocessing_parameters']['relative_power_denominator_hz']],['顶层random_seed','字段不存在；onset_random_seed=20260802'],['R primary bootstrap实际种子','set.seed(20260726)，analysis/r/eeg_primary_analysis.R:267'],['outputs_root',cfg['outputs_root']],['run_id',cfg['run_id']],['resolved run directory',str(RUN)]])
configtext=table(['实际字段','值'],cfgrows)
write('ACTUAL_CONFIG_COMPARISON.md',f'''# 实际运行配置与仓库示例对照

实际配置已找到并原样复制至 `evidence/run_parallel/teacher_analysis.parallel.json`。没有使用示例生成替代配置。

{configtext}

与5174929的 `configs/eeg_analysis.json` 相比：parallel、reference=10、四窗口、5000次及onset种子20260802一致；该通用配置不含core/secondary/supplemental或实际输入路径。与5174929的teacher示例相比：核心/次要/补充指标、relative主度量、parallel窗口配置一致；实际文件还填写了本机输入/输出、已确认预处理标志及运行ID。ce80f1f的两个示例仍使用primary_onset_trim_s=10。

**不能把随机种子笼统写成全管线20260802**：R核心cluster bootstrap实际硬编码20260726；onset等价性流程使用20260802。两者作用于不同过程。

{cite(RUN/'teacher_analysis.parallel.json','完整JSON')}
{code('analysis/r/eeg_primary_analysis.R','267：set.seed(20260726)')}
''')

maps=[
 ['四窗口核心Model1/CR2','scripts/run_teacher_analysis.py','src/paper_analysis/teacher/eeg.py:_run_onset_variant_order_models → analysis/r/eeg_order_analysis.R → common.R:cr2_rows',str(OLD/'00_eeg_trial_qc/eeg_onset_sensitivity_trial_long.csv'),str(RUN/'06_eeg_primary/onset_window_models/trim_{0,5,10,15}s/eeg_cr2_robust_results.csv'),'205–307；R23–48、111–112','CONFIRMED：归档核心R逻辑；工作区整体部分确认'],
 ['144项core coefficients','本次audit_tools/verify_tables.py（仅提取）','原R Model1过滤4个relative outcomes×9项',str(RUN/'06_eeg_primary/onset_window_models/trim_*s/eeg_cr2_robust_results.csv'),str(OUT/'CORE_144_EXISTING_CR2_COEFFICIENTS.csv'),'原表无BH；36/144校正脚本NOT FOUND','PARTIALLY CONFIRMED'],
 ['本地324行broader子集','scripts/run_eeg_onset_sensitivity.py / scripts/run_realdata_all.py','stats/onset_sensitivity.py:run_onset_sensitivity_analysis → fit_variant_model_suite → _apply_parallel_model_fdr',str(OLD/'00_eeg_trial_qc/eeg_onset_sensitivity_trial_long.csv'),str(RUN/'00_eeg_onset_statistics/onset_variant_model_results.csv'),'154–200、436–441；GEE/裸绝对功率；不是relative CR2审计','PARTIALLY CONFIRMED：核查问题所指324原表未找到'],
 ['48项previous-scene','scripts/run_teacher_analysis.py','teacher/complete.py:_parallel_order_carryover_audit → _bh_adjust',str(RUN/'06_eeg_primary/onset_window_models/trim_*s/09_eeg_order_CR2.csv'),str(RUN/'07_reviewer_analysis/Reviewer1_parallel_previous_scene_FDR.csv'),'419–459、703–706','CONFIRMED'],
 ['756行窗口比较','scripts/run_eeg_onset_sensitivity.py','stats/onset_sensitivity.py:descriptive_window_comparisons',str(RUN/'00_eeg_onset_statistics/onset_variant_model_results.csv'),str(RUN/'00_eeg_onset_statistics/onset_window_comparisons.csv'),'368–393；6窗口对×9 outcomes×14 coefficients=756；描述比较，非756项显著性检验','CONFIRMED'],
 ['Block/position（原始核心四窗口）','scripts/run_teacher_analysis.py','analysis/r/eeg_order_analysis.R:Model1；common.R:cr2_rows',str(RUN/'06_eeg_primary/onset_window_models/trim_*s/eeg_onset_order_model_input.csv'),str(RUN/'06_eeg_primary/onset_window_models/trim_*s/eeg_temporal_main_model.csv'),'29–32、69–72；4 relative outcomes','CONFIRMED：仅原始核心管线'],
 ['18-outcome最终temporal audit','NOT FOUND','NOT FOUND','NOT FOUND','NOT FOUND','不能用上述核心管线或GEE替代','NOT FOUND'],
 ['relative/absolute频带功率','scripts/run_eeg_from_raw.py → matlab/run_eeg_bandpower_from_set.m','run_eeg_bandpower_pipeline.m:append_bandpower_columns → bandpower_welch','E:/26/补/脑电数据/*.set + .fdt',str(OLD/'00_eeg_raw_export/summary/all_subjects_scene_level_onset_sensitivity.csv'),'MATLAB309–340、401–417、547','CONFIRMED：算法链；历史原始输入哈希不完整'],
 ['R四窗口common-QC','scripts/run_teacher_analysis.py','teacher/eeg.py:_run_onset_variant_order_models；集合交集',str(OLD/'00_eeg_trial_qc/eeg_onset_sensitivity_trial_long.csv'),str(RUN/'06_eeg_primary/onset_window_models/trim_*s/eeg_onset_order_model_input.csv'),'237–280','CONFIRMED：42/461，键集合一致'],
 ['GEE common-QC','scripts/run_eeg_onset_sensitivity.py','eeg/onset.py:build_common_qc_table；stats/onset_sensitivity.py:run_onset_sensitivity_analysis',str(OLD/'00_eeg_trial_qc/eeg_onset_sensitivity_trial_long.csv'),str(RUN/'00_eeg_onset_statistics/onset_common_qc_parallel.csv'),'onset.py共同QC函数；与R输入路径区分','CONFIRMED']]
pd.DataFrame([dict(zip(['analysis_item','entry_script','core_function_module','input_file','output_file','code_location','status'],r),git_commit=('NOT_APPLICABLE: 2026-09-06 read-only extraction; original R archive 5174929' if r[0]=='144项core coefficients' else (PAR if r[1]!='NOT FOUND' else 'UNRESOLVED')),run_manifest_commit=BASE,archive_note='5174929 is the nearest archived parallel code; not a proven full snapshot of the execution workspace') for r in maps]).to_csv(OUT/'SCRIPT_OUTPUT_MAP.csv',index=False,encoding='utf-8-sig')

temp=pd.read_csv(OUT/'TEMPORAL_EEG_SOURCE_OF_TRUTH.csv',dtype=str,keep_default_na=False)
alpharows=[]
for roi in ['F','P','O']:
 for trim in [0,5,10,15]:
  d=temp.loc[temp.outcome.eq(roi+'_alpha_relative') & temp.onset_trim_s.eq(str(trim)) & temp.temporal_predictor.eq('PositionWithinBlockCentered')]
  if len(d):
   r=d.iloc[0];alpharows.append([roi+'_alpha_relative',trim,r.beta,r.CR2_SE,'未导出',r.raw_p,'NOT FOUND','NOT FOUND','无法判断最终校正标准'])
  else:alpharows.append([roi+'_alpha_relative',trim,'NOT FOUND','NOT FOUND','NOT FOUND','NOT FOUND','NOT FOUND','NOT FOUND','最终temporal audit未找到'])
alphatable=table(['Outcome','窗口/s','β','CR2 SE','95% CR2 CI','raw CR2 p','within q','joint q','状态'],alpharows)
theta=temp.loc[temp.outcome.str.contains('theta_relative') & temp.temporal_predictor.eq('Block')]
thetatab=table(['ROI','窗口/s','β','raw CR2 p','final q','来源'],[[r.outcome,r.onset_trim_s,r.beta,r.raw_p,'UNRESOLVED','原始0805核心CR2表'] for _,r in theta.iterrows()])
outcome9=[f'{roi}_{band}_relative' for roi in ['F','P','O'] for band in ['theta','alpha','beta']]
outcometable=table(['ROI×band','实际配置/原始输入中的relative字段','对应log10 absolute名称的证据边界'],[[v.removesuffix('_relative'),v,('log10_'+v.replace('_relative','_absolute'))+('（核心4指标R日志实际列出）' if v in samples['core_outcomes'] else '（按目标结构期待；最终temporal变量清单未找到）')] for v in outcome9])
technical=f'''# NEW_EEG_TECHNICAL_CHECKS_20260906

**已确认分母、previous-scene q口径与样本；最终18-outcome temporal audit缺失，Q2、Q3及Q5/Q6的最终运行事实无法完全确认。没有重新跑模型填补缺失。**

{scope}

## Q1 Relative-power分母 — CONFIRMED / 历史工作区整体PARTIALLY CONFIRMED

实际1–45 Hz；theta/alpha/beta均以各ROI的该范围总Welch功率为分母。代码路径与精确行见 `RELATIVE_POWER_DENOMINATOR_AUDIT.md`。来源为实际MATLAB导出实现、8月2日成功日志、8月4日运行配置及输入哈希；样本边界为56份导出源、正式共同QC42人/461试次。此项为算法定义，不涉及BH family。

**METHODS DEFINITION MISMATCH**：核查文件所引1–30 Hz与算法不一致，定稿需修正；未拿当前全文反推代码。`relative_power_denominator_hz`只是teacher元数据说明，实际计算由 `opts.Bands.totalBand40` 控制。

## Q2 Position → relative alpha — UNRESOLVED

找到的0805四窗口R模型只覆盖核心4个relative outcomes，因此只有O_alpha_relative的position系数可直接摘录，F/P alpha不在这组四窗口原始R输出中。单独10秒secondary输出不是最终四窗口18-outcome temporal audit。

{alphatable}

数值来源：`06_eeg_primary/onset_window_models/trim_*s/eeg_cr2_robust_results.csv`；脚本 `eeg_order_analysis.R:29–32,111–112`；样本42/461。CR2源表不含CI或temporal BH q，本次不重新计算，也不把普通mixed-model CI伪称CR2 CI。

A. 三个ROI均有校正后证据？**无法确认**。B. 四窗口是否都成立？**无法确认**。C. 最新那句话准确吗？**现有证据不足以支持，不能判定为已核验准确**。D. 应暂缓/收窄的是“within-round presentation position在F/P/O三个ROI的relative alpha均有校正后正向证据”这一扩展；不直接修改正文，不把未找到证据写成效应不存在。

## Q3 Viewing round → theta q范围 — UNRESOLVED

未找到两组范围 `0.00447–0.0224` 与 `0.00461–0.02239` 对应的temporal audit原表及生成脚本。不能判断它们是否同family、同共同QC样本、同temporal predictors，或是否分别为within/joint q。文件日期差一天并不能证明两者相同。

已能摘录的原始核心结果如下，仅作为定位材料，不能当作最终temporal audit：

{thetatab}

**Recommended final q range = UNRESOLVED — source audit and correction-family definition required.**

未把差异归为四舍五入：没有原始未舍入q支持这种判断；本次也没有重新BH以制造一组“唯一数值”。Confidence：对原始β/p摘录为高；对最终q范围无可确认依据。正文最终q范围暂不能锁定。

## Q4 Previous-scene within / joint q — CONFIRMED

{pvtable}

0.53219和0.11835是窗口内12项BH；对应联合48项q完整精度见表。48=4个核心relative outcomes×3个previous系数×4窗口。源表 `Reviewer1_parallel_previous_scene_FDR.csv`，生成模块 `teacher/complete.py:_parallel_order_carryover_audit`；四窗口均42人/386个完整案例，75条首位置试次为结构性前序未定义。样本及字符空值读取细节见 `PREVIOUS_SCENE_SAMPLE_CONFIRMATION.md`。

Confidence：高。**正文若只写q，必须注明within-variant或joint q。**

## Q5 72 models与72-test family — PARTIALLY CONFIRMED（算式；运行事实未确认）

若核查问题所述新temporal audit确实为每个scale 9个outcomes、4窗口、每模型2个temporal coefficients，则结构如下。这是对问题中设计的算术拆解，不是声明本地已找到/重跑这些模型。

{table(['Layer','Outcomes','Variants','Temporal predictors','Models','Tests in BH family'],[['Relative power',9,4,2,36,72],['Log10 absolute power',9,4,2,36,72],['Combined total',18,4,2,72,'144项总计；分成两个72项family，非自动联合144项BH']])}

因此“72 models”是两个scale合计；“72-test family”是每个scale各一组，两者不是同一计数对象。**72个模型是否全部收敛、最终BH是否确实按两个72项family执行：NOT FOUND/UNRESOLVED**。当前未收到完整Results/Methods，不能确认全文是否混淆；报告应分开写清计数与校正单位。

## Q6 9个EEG outcomes — PARTIALLY CONFIRMED

下列9个relative字段可由实际配置的core/secondary/supplemental及原始模型输入锁定；但这不等于已经证明全部进入了最终18-outcome temporal audit。

{outcometable}

实际R日志仅列出4个核心log10 absolute指标：`log10_O_theta_absolute`、`log10_F_theta_absolute`、`log10_O_alpha_absolute`、`log10_O_beta_absolute`。其余5个log10名称在上表明确标为待核的目标对应名，不冒充实际最终变量清单。

Low beta/high beta未进入实际core/secondary/supplemental这9个ROI×band清单；MATLAB确实另外提取它们作为特征。Methods中有频带定义，只能证明这些特征被定义或提取，不能证明进入了这组temporal模型。最终18项变量清单与是否排除low/high beta：仍需原temporal audit脚本/表锁定。

Confidence：对实际配置9个relative字段和日志4个absolute字段为高；对最终temporal18变量表未确认。

## 历史问题状态更新

{table(['问题','状态','简要依据'],[['四窗口从开始即equal-status','Not confirmed；存在相反历史','8月2日10秒主分析；8月4日才改同等并行'],['144项运行前primary multiplicity family','Not confirmed','core指标预先指定，不等于144项联合BH已指定'],['factor-level visual-complexity reanalysis预设时间','Evidence unavailable','原R脚本因子化已存在；未找到核查问题所指后续reanalysis计划/脚本'],['0805工作区完整等于5174929','Not confirmed','存在ce80f1f上的未提交改动，运行后又改过索引；部分R脚本逐字节一致'],['上游预处理记录','Confirmed for current .set history; historical input snapshot incomplete','56份history可读，2份后来修改；不据此补推ICA成分删除']])}

## 数值表使用说明与证据

`TEMPORAL_EEG_SOURCE_OF_TRUTH.csv`包含**32条已找到的原始核心temporal系数**（4 outcomes×4窗口×2 predictors）；其source_status明确标记“ORIGINAL_0805_CORE_ONLY_NOT_FINAL_18_OUTCOME_TEMPORAL_AUDIT”。CI/within_q/joint_q留空并注明原因。它是本次能证实的来源摘录，**不是已完成的144项最终temporal审计表**。

{cite(RUN/'06_eeg_primary/onset_window_models/trim_10s/eeg_cr2_robust_results.csv','Model1、Block、PositionWithinBlockCentered')}
{cite(RUN/'06_eeg_primary/26_eeg_analysis_log.txt','core/secondary/supplemental relative与4个log10 absolute列表')}
{cite(RUN/'07_reviewer_analysis/Reviewer1_parallel_previous_scene_FDR.csv','完整48行，within/joint两列')}
{code('analysis/r/common.R','49–66：仅导出CR2 estimate、SE、df、p，无CI')}

本轮完成标准检查：分母有代码证据=通过；position逐ROI/窗口最终校正证据=缺失；theta最终q唯一来源=缺失；previous-scene两种q区分=通过；72的算术含义=通过、实际运行=缺失；最终temporal18个变量名单=缺失。因此这是**已完成现有材料核查、仍有外部证据缺口**的审计交付，不能宣称全部六项完成或端到端复现。
'''
write('NEW_EEG_TECHNICAL_CHECKS_20260906.md',technical)

q1=f'''## 问题1 实际代码版本 — PARTIALLY CONFIRMED

1. **确认使用ce80f1f基础上的未提交平行代码**：运行manifest记ce80f1f；8月4日本地工具补丁记录和实际配置/四窗口结果表证明运行包含尚未进入该提交的修改。8月9日实施计划也记录尚未提交的0805平行改动。
2. 5174929在8月9日归档该批平行功能：确认；但“所有字节与8月4日实际工作区完全相同”：未确认。
3. 运行后至提交前代码确有修改。8月4日14:40:30 UTC为报告来源映射增加48项FDR文件；15:16:23 UTC（正式完成后）修改 `_all_files_index`，排除索引文件自身。后者及对应测试有完整补丁事件，不能说运行后代码完全没变。这些已查明修改属于来源索引/报告支持，不据此推断模型被重新拟合。
4. `27_eeg_primary_analysis.R`、`28_eeg_robustness_analysis.R`（实际为同一primary脚本副本）、`29_eeg_crossmodal_analysis.R`分别与ce80f1f及5174929对应源码逐字节匹配（6次比较全部相同）。但没有完整运行工作区快照/hash清单覆盖全部Python与R文件。

**无法确认5174929与8月4日实际工作区完全一致；5174929是目前最接近的已归档平行分析代码版本。**

已保存Git log/reflog、两个版本diff、完整5174929代码ZIP、相关本地任务消息与成功补丁事件。默认VS Code/Cursor History路径未发现可用历史，未把它们作为证据。当前Git工作区干净。

对论文：软件归档版本可以列5174929，同时说明run manifest记录ce80f1f且执行时含未提交改动；不要声称5174929已经端到端复现8月4日结果。

{cite(RUN/'06_eeg_primary/run_manifest.json','git_commit、created_at_utc、config_path',BASE+'（运行记录）')}
{cite(RUN/'99_completion/run_manifest.json','2026-08-04T14:45:15.566013Z；status=complete',BASE+'（运行记录）')}
{cite(h03,'第1820、2428行成功补丁；historical_repo_patch_events.json','非Git任务历史')}
{cite(h09,'第703行记录未提交0805改动','非Git任务历史')}
{cite(RUN/'06_eeg_primary/27_eeg_primary_analysis.R','完整归档脚本；ARCHIVED_R_CODE_COMPARISON.csv',BASE+'及'+PAR+'逐字节相同')}
'''
q2=f'''## 问题2 实际运行配置 — CONFIRMED

已找到 `{RUN/'teacher_analysis.parallel.json'}`，原样副本在 `evidence/run_parallel/teacher_analysis.parallel.json`，哈希与源文件一致。字段详表和与两个仓库示例的比较见 `ACTUAL_CONFIG_COMPARISON.md`。

{configtext}

对Methods：要分别报告onset seed=20260802与R主分析cluster-bootstrap seed=20260726，不可统称同一个种子。实际配置与示例已分开归档，没有重建或冒充运行配置。

{cite(RUN/'teacher_analysis.parallel.json','完整文件；各字段如表')}
{code('analysis/r/eeg_primary_analysis.R','267：bootstrap随机种子')}
'''
q3='''## 问题3 四窗口何时确定 — CONFIRMED（历史时间线）；prospective equal-status不成立

四种长度8月2日已共同列入新截断实施方案，当时10秒为主分析。8月3日已有10秒/15秒结果讨论；8月4日21:19北京时间才形成明确同等并行计划，并在当晚完成平行管线。Git于8月9日归档。详见 `EEG_WINDOW_HISTORY.md`，其中附原文、时间、来源行、哈希与代码证据。

对3.3：可以描述最终平行分析，不能把最终地位写成从一开始就预先规定的同等分析。四种长度本身不是在8月4日才新增。共同QC/模型一致已验证；144项统一BH尚未证实。
'''+cite(h02,'第350行', '非Git任务历史')+'\n'+cite(h03,'第128、665行','非Git任务历史')
q4='''## 问题4 144项与324项 — PARTIALLY CONFIRMED / primary-family地位UNRESOLVED

4个核心relative outcomes确为早先配置定义，四个R/CR2 Model1文件可提取144项已有系数；未找到其36/144项BH脚本或输出。不能据此称144为当时primary multiplicity family，也不能断言其一定是在后来从核查问题所指324项中提取。

本地能够定位并提取的324行来自9个裸absolute-power outcomes的Gaussian GEE，继承117/468项校正，而非relative-power CR2。核查问题是否指另一份后续324项审计，尚未找到原表确认。六个子问的逐项答案见 `ANALYSIS_FAMILY_144_VS_324.md`。

对3.3：仅客观描述核心4指标跨4窗口考察144项Model1系数；不称预先定义primary family，不混用GEE的q。
'''+code('analysis/r/eeg_primary_analysis.R','132–170')+'\n'+code('src/paper_analysis/stats/onset_sensitivity.py','186–200、436–441')
q5='''## 问题5 脚本—输出映射 — PARTIALLY CONFIRMED

详见 `SCRIPT_OUTPUT_MAP.csv`，覆盖全部指定分析项；找不到的最终temporal audit及144项专属BH明确标为NOT FOUND。

- `eeg_cr2_robust_results.csv`：`analysis/r/eeg_order_analysis.R`第112行；CR2计算在common.R。
- `Reviewer1_parallel_previous_scene_FDR.csv`：`src/paper_analysis/teacher/complete.py`的 `_parallel_order_carryover_audit` 合并，各窗口12项BH及联合48项BH，703–706行写出。
- `onset_window_comparisons.csv`：`src/paper_analysis/stats/onset_sensitivity.py`的 `descriptive_window_comparisons`；6个窗口对×9 outcomes×14个系数（含截距）=756行。

**756是描述性系数比较行数，不是756项正式显著性检验。** 代码明确写 `parallel_descriptive_pairwise`，其差值区间用两SE平方和，不包含跨窗口配对协方差；不应把它们当成正式配对窗口差异证据。本次不改代码或重算区间。

对Methods：明确R/CR2主路径与GEE兼容/补充路径；分别列窗口、样本、尺度、校正范围。
'''+code('analysis/r/eeg_order_analysis.R','111–112')+'\n'+code('src/paper_analysis/teacher/complete.py','419–459、703–706')+'\n'+code('src/paper_analysis/stats/onset_sensitivity.py','368–393')
q6='''## 问题6 Previous-scene实际样本 — CONFIRMED

四窗口均为42/461，前序未定义75条全部是首位置，轮1/轮2分别37/38；筛选后42/386。原R读取方式与Python保留空字符串读取得到一致结果；并非默认Python dropna的结果。详表及数值见 `PREVIOUS_SCENE_SAMPLE_CONFIRMATION.md` 与 `evidence/R_READ_SAMPLE_CONFIRMATION.csv`。

对Methods：写明“首位置前序条件结构性未定义，按PositionWithinBlock>1排除”，其余模型完整案例386；不要写成75条数据读入失败或自动na.omit。当前复杂度C0的字符空值编码也应记录，以便复现。
'''+code('analysis/r/eeg_order_analysis.R','42')+'\n'+cite(RUN/'06_eeg_primary/onset_window_models/trim_10s/eeg_onset_order_model_input.csv','461行；PreviousWWR/PositionWithinBlock/Block')
q7='''## 问题7 Relative power分母 — CONFIRMED（算法）

实际1–45 Hz；由MATLAB `append_bandpower_columns`调用 `bandpower_welch`，默认 `totalBand40=[1 45]`。teacher配置中的文字字段不是实际传参入口。0.5–40 Hz上游滤波与1–45 Hz积分范围同时存在，本次未改变或重算结果。详见 `RELATIVE_POWER_DENOMINATOR_AUDIT.md`。

对Methods：核查文件所引1–30 Hz定义需修正为原算法1–45 Hz，并说明源数据已有上游滤波；不能把积分上限静默改成40 Hz。
'''+code('matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m','328、338–340、401–417、547、554–570')+'\n'+cite(OLD/'eeg_onset_export_stdout_02.log','成功导出及validation_status: pass',BASE)
q8=f'''## 问题8 0803与0805的版本关系 — CONFIRMED（正式入口）；全部文件无错误不作保证

1. 0803交付对应teacher_onset_20260802及10秒主方案；0805交付说明明确对应teacher_parallel_20260804及四窗口最终并行。
2. 当前根目录README和realdata_run_summary均把parallel运行标为正式，promoted=true；因此论文EEG结果应以0805所对应正式parallel源表为基准，不再与0803旧结果混选。
3. 已直接读取两个原始ZIP逐文件比较：按去除SourceID后的同名路径比较，0805中219项与0803逐字节相同、179项改变、13项新增；这是整个ZIP文件比较，不把它与408个数据源文件计数混淆。眼动Stage2/3合计98个文件全部相同（46+52），支持统一阅读0805而非拼接两个版本。
4. 0803的10秒主结果、旧样本窗口结果以及10/15等价性材料保留为历史/兼容参考。原onset运行中被实际配置引用的频带功率输入仍是有效上游来源，不能因为目录较旧就视为废弃。
5. 0805仍保留10秒兼容R主分析（42/474）和四窗口共同QC（42/461），以及GEE兼容输出；不能把所有同名文件等同。当前知道的风险包括：144项BH未找到、最终18-outcome temporal audit未找到、756行只是描述比较、历史工作区不完整归档、两份当前.set曾后改。未发现理由要求推翻已核对的48项previous结果，但未承诺0805每个文件都无错误。
6. 同名结果值不同应按正式parallel的具体source path、模型、样本与尺度取值；**不能机械地按文件名或日期选最新**。原始EEG四窗口结果优先0805，而后续temporal新审计若要替代某些值，需先提供其源表与版本说明。

对论文：明确用0805正式管线和具体表；不要在Results里混用474与461样本，或混用relative CR2与absolute GEE。

{cite(DATA/'README_当前有效结果.md','当前正式运行')}
{cite(DATA/'realdata_run_summary.json','run_id、promoted、completed_at_utc')}
{cite(Path('E:/26/补/yyd/结果发送/0805_原始交付/数据来源交接说明-0805.md'),'正式运行批次与四窗口口径')}

逐文件比较：`evidence/PACKAGE_0803_0805_COMPARISON.csv`；两个ZIP的读取清单：`evidence/PACKAGE_EEG_TABLE_INVENTORY.csv`。
'''
q9=f'''## 问题9 EEG输入边界 — PARTIALLY CONFIRMED

1. MATLAB直接 `pop_loadset` 读取已预处理 `.set`及关联`.fdt`，下游teacher分析直接读取其频带功率CSV。实际teacher配置复用了onset运行的 `00_eeg_trial_qc/eeg_trial_long.csv` 和 `eeg_onset_sensitivity_trial_long.csv`。
2. exporter源码没有再次执行filtering、notch、re-reference或ICA的调用；它做marker7→8分段、起始剔除、Welch功率和QC特征提取。
3. 56份.set及56份.fdt的本次路径/大小/mtime/SHA均已登记（未复制大文件）；原导出subject methods snapshots及summary CSV已复制。原下游input_hashes中已记录的5项依赖全部与现存文件哈希匹配。
4. **没有找到覆盖56份.set/.fdt在8月2日输入时状态的完整历史哈希清单**。本次当前原件哈希不能冒充当时输入哈希。当前两份.set mtime在8月4日之后，既有8月18日审计也记载了更新；无法把它们直接视为当时输入原件。
5. `.set`内history可归档读到上游0.5–40、49–51、平均参考和runica记录；但这些是当前文件状态，不是全部旧输入的独立快照。未找到pop_subcomp历史，不替作者推测ICA成分剔除标准。
6. 预处理到功率CSV：`scripts/run_eeg_from_raw.py` → `matlab/run_eeg_bandpower_from_set.m` → `matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m`；随后Python EEG/QC生成teacher输入。

对Methods：区分作者EEGLAB预处理、MATLAB功率导出、Python QC/编排与R统计。可报告有证据的算法和输入；不能声称当前全部输入已与原运行按哈希锁定，也不能声称端到端复现。

{code('matlab/eeg_bandpower_pipeline/run_eeg_bandpower_pipeline.m','4–7、76、254、286、309–340')}
{code('scripts/run_eeg_from_raw.py','53–62、102–130')}
{cite(RUN/'teacher_analysis.parallel.json','eeg.trial_file及onset_sensitivity_trial_file')}
{cite(RUN/'06_eeg_primary/input_hashes.json','历史下游输入哈希')}
'''
final=f'''# FINAL_TEACHER_PARALLEL_PROVENANCE

审计日期：2026-09-06。交付目录：`E:\\26\\补\\yyd\\0906`。

**最影响3.3的结论：四种窗口长度8月2日已共同列出，但同等平行地位于已检视10秒结果后的8月4日调整；144条核心系数可定位，144项统一primary BH family未获证实，不能把它与本地324条absolute GEE子集混为一谈。**

**本次状态：现有材料的只读核查已完成；核查问题所指最终18-outcome temporal audit、两组theta q原表及144项专属BH仍未找到，相关结论未锁定。**

{scope}

## 证据与阅读入口

- `EEG_WINDOW_HISTORY.md`：问题3的时间线与可用措辞。
- `ANALYSIS_FAMILY_144_VS_324.md`：问题4六个子问及模型/尺度/family区别。
- `NEW_EEG_TECHNICAL_CHECKS_20260906.md`：增补Q1–Q6逐项结果与缺口。
- `CRITICAL_FILE_MANIFEST.csv`：每项来源绝对路径、mtime UTC、SHA-256、证据副本及已知Git版本。历史CSV若没有独立代码归档，其Git字段保留UNRESOLVED，不以manifest的HEAD冒充完整工作区。
- `evidence/code_5174929.zip`：指定提交的完整代码；`code_ce80f1f`、`code_5174929`、`code_HEAD`为关键脚本/配置副本。

{q1}

{q2}

{q3}

{q4}

{q5}

{q6}

{q7}

{q8}

{q9}

## 检索范围与尚缺证据

主要完整核查：本Git仓库、两个指定结果根目录、teacher_onset/teacher_parallel运行目录、0803/0805 ZIP及0805交付副本、相关8月2/3/9日本地任务记录、56份现存EEGLAB元数据。另对D盘、E盘及用户目录进行了目标文件名检索；部分系统/临时目录拒绝访问，错误日志已保存，不宣称全盘无遗漏。后续内容检索只针对代码、配置、分析日志与结果，未把无关相近数字当作q值来源。

未找到：最终18-outcome temporal audit脚本/完整输出、260905 Results完整稿、两组theta q的未舍入原表、36/144专属BH脚本与输出、完整的运行时工作区快照及56份历史EEG输入哈希。

最小补证材料是：产生144项q及18-outcome temporal audit的原脚本、实际配置、机器可读结果表和生成时间记录。无需为了填本审计而重新运行模型；缺少原件时维持UNRESOLVED。
'''
write('FINAL_TEACHER_PARALLEL_PROVENANCE.md',final)

discrepancies=f'''# EEG_METHOD_DISCREPANCIES_20260906

仅列本次已确认的方法/报告口径差异；不检查旧Title、Introduction、Discussion、Conclusion。

{table(['项目','已确认事实','需如何说明','证据'],[
 ['METHODS DEFINITION MISMATCH：relative分母','核查文件所引1–30 Hz与运行算法1–45 Hz不一致','按原算法说明1–45 Hz；完整当前稿未提供，不声称已定位全文段落','MATLAB328、338–340、547；RELATIVE_POWER_DENOMINATOR_AUDIT.md'],
 ['previous-scene q标签歧义','10秒0.5321856016及15秒0.1183456393是within；joint为0.8071868111及0.4733825573','给q明确加within-window或joint four-window标签','原48行FDR表'],
 ['运行manifest与工作区版本不等价','manifest记录ce80f1f，但运行用了未提交parallel改动，8月9日才归档5174929','区分HEAD记录、工作区修改及后来归档提交','Git+任务补丁+run_manifest'],
 ['分母配置文字不是算法控制项','relative_power_denominator_hz未直接传入计算；实际使用opts.Bands.totalBand40','复现说明给出实际计算参数及函数；不能只引用teacher描述字段','MATLAB apply_config、append_bandpower_columns'],
 ['随机种子有不同作用范围','onset为20260802；R core bootstrap为20260726','按各自分析过程分别报告，避免统称全流程同一种子','teacher配置；eeg_primary_analysis.R267'],
 ['字符空值读取差异','R把当前C0空字符串当参考因子；Python默认读为NaN','说明编码和原读取方式；75条首位置由显式位置过滤排除','R_READ_SAMPLE_CONFIRMATION.csv；contracts.py221–260'],
 ['756行不是756项正式假设检验','inference_role=parallel_descriptive_pairwise，含截距，6×9×14行','称描述性跨窗口比较；不把其CI当正式配对推断','onset_sensitivity.py368–393'],
 ['不可将本地144/324直接作同一结果集比较','144为核心relative R/CR2；本地可定位324为absolute GEE子集','报告中同时注明模型、尺度、family；核查问题中另一324原件仍待核','ANALYSIS_FAMILY_144_VS_324.md'],
 ['当前原始输入与历史快照不同','当前2份.set的mtime晚于原运行，既有审计记录更新','不得将当前112文件哈希当作8月2日输入锁定证据','CURRENT_SET_HISTORY_CHECKS.csv；原审计材料']])}

不列为“已确认错误”的项目：position→relative alpha是否显著、theta两组q哪组正确、72模型是否确实全部收敛、144项是否后来另有正式校正、最终18个temporal变量名单。这些属于证据缺口，详见增补报告。72模型和每scale 72项检验的计数含义已拆清，但未收到完整当前稿，不能断言稿中已混淆。
'''
write('EEG_METHOD_DISCREPANCIES_20260906.md',discrepancies)
write('README_先看这里.md',f'''# 0906 EEG只读溯源交付

先看 `FINAL_TEACHER_PARALLEL_PROVENANCE.md`；重写3.3最需要的是 `EEG_WINDOW_HISTORY.md` 和 `ANALYSIS_FAMILY_144_VS_324.md`。

1. 四种窗口长度8月2日已计划，但同等平行地位在看过旧10秒结果后于8月4日调整。
2. 四个核心指标预先配置，不等于144项统一BH family预先配置；36/144的原BH输出未找到。
3. 本地可定位324项属于absolute GEE；不能冒充relative CR2144项的全集。
4. 分母为1–45 Hz；previous-scene的两种q和42/386样本已核实。
5. 最终18-outcome temporal audit未找到，新增alpha及theta最终q不能据现有表下结论。

共交付两份指令要求的10个文件，以及配置对照、已有系数提取、样本核对、来源副本、指定提交代码ZIP和审计脚本。`TEMPORAL_EEG_SOURCE_OF_TRUTH.csv`只包含32条原0805核心temporal系数，缺失q/CR2 CI明确留空，不能当作最终18-outcome审计表。

大体积.set/.fdt未复制，112个文件的当前哈希已登记；其他证据副本保留原内容。文件哈希与交付检查见 `AUDIT_QA.md`、`DELIVERABLE_MANIFEST.csv`。没有重新拟合模型、计算新p/q/CI/频谱，也未修改论文或原工程。
''')
print('Reports written:',len(list(OUT.glob('*.md'))))

# Follow the actual saved analyses rather than treating the teacher's premise as fact.
scope_summary=json.loads((EV/'RESULT_SCOPE_SUMMARY.json').read_text(encoding='utf-8'))
native=f'''## 对两个主要结果目录的扩展核查

按用户确认，仅以 `E:\\26\\补\\数据分析结果` 与 `E:\\26\\补\\yyd` 内保存的实际产物裁定审阅方清单中的说法，不预设审阅方描述一定正确。排除本次0906交付目录后，共登记{scope_summary['total_files']}个文件，包括{scope_summary['csv_files']}个CSV、{scope_summary['xlsx_files']}个XLSX；识别{scope_summary['model_tables']}张模型表（含不同版本/副本，不是独立分析次数），对有配套CSV的工作簿检查CSV，其余工作簿按内容去重检查了{scope_summary['standalone_unique_xlsx_scanned']}份。没有读取错误。模型表均无晚于8月9日的mtime；mtime只作辅助，不据此排除另处分析。

实际保存的结构是：

| 实际产物 | 结局/窗口/模型结构 | 来源 |
| --- | --- | --- |
| 四窗口核心R Model1 | 4个relative outcomes×4窗口=16个Model1；另有Model0/PreviousScene/Block1，不能混算为新temporal模型 | onset_window_models下四个eeg_temporal_main_model.csv |
| 10秒R主分析及敏感性诊断 | 9个relative outcomes＋4个核心log10 absolute outcomes=13个已保存诊断；n=474 | 18_eeg_model_diagnostics.csv |
| 四窗口共同QC GEE | 9个裸absolute outcomes×4窗口=36个模型；n=461；不是18-outcome relative/log10重分析 | onset_variant_model_results.csv |

所谓新增18-outcome模型所需的另外5个log10 outcomes，在本次已识别模型表的outcome字段中均无命中。因此，**“18个结局、72个模型的最终temporal reanalysis已经是这套保存结果的一部分”这一前提未获证实，并与上述可核对结构不吻合**。不能以该前提把两个72-test families或新增F/P/O relative-alpha显著结论写成已运行事实。

这不是要求用户继续寻找一个理应存在的文件，也不证明作者从未在其他环境分析过；对当前两目录中的论文依据，按已保存分析处理。若审阅方的文字只是拟议方案或对结果结构的误读，应撤回相应已运行表述，不能为迎合文字重新跑模型补历史。

逐表检索清单：`evidence/MODEL_TABLE_CATALOG.csv`；全文件范围：`evidence/RESULT_SCOPE_INVENTORY.csv`；汇总：`evidence/RESULT_SCOPE_SUMMARY.json`。
'''
for name in ['FINAL_TEACHER_PARALLEL_PROVENANCE.md','NEW_EEG_TECHNICAL_CHECKS_20260906.md','README_先看这里.md']:
 p=OUT/name;p.write_text(p.read_text(encoding='utf-8')+'\n'+native,encoding='utf-8')
# The exporter itself did not save a dedicated Git HEAD; avoid assigning its later run manifest to it.
for p in OUT.glob('*.md'):
 t=p.read_text(encoding='utf-8')
 t=t.replace(BASE+'（HEAD记录，非完整工作区哈希）','3d6b001 / ce80f1f（导出函数定义一致；导出瞬间HEAD未单独记录）')
 p.write_text(t,encoding='utf-8')
qsearch=json.loads((EV/'THETA_Q_VALUE_SOURCE_SEARCH.json').read_text(encoding='utf-8'))
p=OUT/'NEW_EEG_TECHNICAL_CHECKS_20260906.md'
p.write_text(p.read_text(encoding='utf-8')+f"\n针对theta×Block/round校正值，进一步扫描{qsearch['csv_model_files_scanned']}份包含theta/alpha结局的CSV模型表，未在对应q/BH/FDR/adjusted字段找到0.00447、0.00461或0.02239前缀的目标值。这里只是来源核查，不重新计算q；记录见 `evidence/THETA_Q_VALUE_SOURCE_SEARCH.json`。\n",encoding='utf-8')
